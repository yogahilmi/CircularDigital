SELECT wu_id, wu_name, rc_number, destroy_schedule,
    COUNT(doc_id) AS total_doc
FROM
    working_unit
LEFT JOIN
    document_detail
    ON (document_detail.working_unit_id = working_unit.wu_id)
WHERE
    ( documentstatus_id = 3
        OR ( documentstatus_id = 4 ) 
        )
AND 
    destroy_schedule <= 2020
GROUP BY
    working_unit.wu_id, document_detail.working_unit_id, document_detail.destroy_schedule;