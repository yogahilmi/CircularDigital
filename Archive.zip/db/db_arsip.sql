-- MySQL dump 10.13  Distrib 8.0.19, for macos10.15 (x86_64)
--
-- Host: localhost    Database: db_arsip
-- ------------------------------------------------------
-- Server version	5.7.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `document_classification`
--

DROP TABLE IF EXISTS `document_classification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `document_classification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `classification_code` varchar(10) DEFAULT NULL,
  `classification_name` varchar(45) DEFAULT NULL,
  `creator_id` int(11) DEFAULT NULL,
  `modifier_id` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `is_active` int(1) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document_classification`
--

LOCK TABLES `document_classification` WRITE;
/*!40000 ALTER TABLE `document_classification` DISABLE KEYS */;
INSERT INTO `document_classification` VALUES (1,'KA','Keuangan dan Akuntansi',NULL,NULL,NULL,NULL,1),(3,'RM','Record Management System',1,1,'2020-06-11 23:02:09','2020-06-13 00:34:19',1),(4,'KR','Perkreditan',1,NULL,'2020-07-08 18:11:41',NULL,1),(5,'DJ','Pengerahan Dana dan Jasa',1,1,'2020-07-08 18:11:58','2020-07-08 18:12:27',1),(6,'EI','Ekspor dan Impor',1,NULL,'2020-07-08 18:12:22',NULL,1),(7,'PM','Pasar Uang dan Modal',1,NULL,'2020-07-08 18:12:50',NULL,1),(8,'TI','Teknologi Informasi',1,NULL,'2020-07-08 18:13:23',NULL,1);
/*!40000 ALTER TABLE `document_classification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `document_ddum_status`
--

DROP TABLE IF EXISTS `document_ddum_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `document_ddum_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document_ddum_status`
--

LOCK TABLES `document_ddum_status` WRITE;
/*!40000 ALTER TABLE `document_ddum_status` DISABLE KEYS */;
INSERT INTO `document_ddum_status` VALUES (0,'Tidak'),(1,'Ya');
/*!40000 ALTER TABLE `document_ddum_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `document_destroy`
--

DROP TABLE IF EXISTS `document_destroy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `document_destroy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `destroy_number` varchar(45) DEFAULT NULL,
  `destroyed_number` varchar(45) DEFAULT NULL,
  `working_unit_id` int(11) DEFAULT NULL,
  `creator_id` int(11) DEFAULT NULL,
  `modifier_id` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document_destroy`
--

LOCK TABLES `document_destroy` WRITE;
/*!40000 ALTER TABLE `document_destroy` DISABLE KEYS */;
INSERT INTO `document_destroy` VALUES (4,'No.DDUM.2020.001','No.DDM.2020.001',2,1,NULL,'2020-06-26 14:13:57',NULL),(9,'No.DDUM.2020.002','No.DDM.2020.002',3,1,NULL,'2020-06-26 23:09:28',NULL);
/*!40000 ALTER TABLE `document_destroy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `document_detail`
--

DROP TABLE IF EXISTS `document_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `document_detail` (
  `doc_id` varchar(20) NOT NULL,
  `recordcenter_id` int(3) DEFAULT NULL,
  `feeding_id` int(11) DEFAULT NULL,
  `working_unit_id` int(11) DEFAULT NULL,
  `pic_id` int(11) DEFAULT NULL,
  `classification_id` int(11) DEFAULT NULL,
  `retention_id` int(11) DEFAULT NULL,
  `retention_name` varchar(128) DEFAULT NULL,
  `document_desc` varchar(255) DEFAULT NULL,
  `begin_period` date DEFAULT NULL,
  `end_period` date DEFAULT NULL,
  `start_retention` varchar(4) DEFAULT NULL,
  `retention_schedule` varchar(2) DEFAULT NULL,
  `destroy_schedule` varchar(4) DEFAULT NULL,
  `destroy_id` int(11) DEFAULT NULL,
  `total_folder` int(11) DEFAULT NULL,
  `total_map` int(11) DEFAULT NULL,
  `total_bundle` int(11) DEFAULT NULL,
  `total_other` int(11) DEFAULT NULL,
  `box_number` varchar(10) DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `feeding_date` datetime DEFAULT NULL,
  `schedule_period` varchar(4) DEFAULT NULL,
  `destroy_period` varchar(4) DEFAULT NULL,
  `destroy_date` datetime DEFAULT NULL,
  `file_memo` varchar(128) DEFAULT NULL,
  `creator_id` int(11) DEFAULT NULL,
  `modifier_id` int(11) DEFAULT NULL,
  `documentstatus_id` int(11) DEFAULT NULL,
  `destroy_ddum` int(1) DEFAULT NULL,
  `pending_period` int(11) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`doc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document_detail`
--

LOCK TABLES `document_detail` WRITE;
/*!40000 ALTER TABLE `document_detail` DISABLE KEYS */;
INSERT INTO `document_detail` VALUES ('001-202007-0000001',1,6,1,1,8,0,'Arsip Aplikasi','sadasdas','2020-07-01','2020-07-18','2020','13','2034',NULL,0,12,12,0,'2020-00015',NULL,'2020-07-18 16:14:09',NULL,NULL,NULL,NULL,1,NULL,1,NULL,NULL,NULL),('001-202007-0000016',5,4,1,1,3,2,'Bilyet Saldo Kliring Bank-bank','BGUYGUASGIUAHSIhisahdiasd','2020-06-01','2020-06-01','2020','10','2020',NULL,12,12,44,32,'2020-00001',NULL,'2020-06-15 21:08:11',NULL,NULL,NULL,NULL,1,NULL,1,1,NULL,NULL),('001-202007-0000017',5,4,1,1,3,2,'Coba Lagi Edit','asdsad','2020-06-01','2020-06-15','2020','10','2030',NULL,12,12,1,22,'2020-00002',NULL,'2020-06-15 21:10:32',NULL,NULL,NULL,NULL,1,NULL,1,1,NULL,NULL),('001-202007-0000018',1,1,1,1,3,5,'Data Digital Aplikasi','Test 5 tahun','2020-06-01','2020-06-01','2020','10','2030',NULL,12,0,0,0,'2020-00003',NULL,'2020-06-15 21:29:08',NULL,NULL,NULL,NULL,1,NULL,1,1,NULL,NULL),('001-202007-0000021',1,1,1,1,3,5,'Data Digital Aplikasi','Test 5 tahun','2020-06-01','2020-06-01','2020','10','2030',NULL,12,0,0,0,'2020-00004',NULL,'2020-06-15 21:29:08',NULL,NULL,NULL,NULL,1,NULL,1,1,NULL,NULL),('001-202007-0000022',1,1,1,1,3,5,'Data Digital Aplikasi','Test 5 tahun','2020-06-01','2020-06-01','2020','10','2030',NULL,12,0,0,0,'2020-00005',NULL,'2020-06-15 21:29:08',NULL,NULL,NULL,NULL,1,NULL,1,1,NULL,NULL),('001-202007-0000023',1,1,1,1,3,5,'Data Digital Aplikasi','Test 5 tahun','2020-06-01','2020-06-01','2020','10','2030',NULL,12,0,0,0,'2020-00006',NULL,'2020-06-15 21:29:08',NULL,NULL,NULL,NULL,1,NULL,1,1,NULL,NULL),('001-202007-0000026',2,5,2,1,1,2,'Hukum Compliance','Hukum Pidana','2020-06-01','2020-06-16','2020','10','2020',NULL,12,2,11,9,'2020-00001',NULL,'2020-06-16 12:19:32',NULL,NULL,NULL,NULL,1,NULL,3,1,NULL,NULL),('001-202007-0000027',2,5,2,1,1,7,'Hukum Compliance','Test Destroy','2020-05-04','2020-06-16','2020','10','2020',NULL,12,0,0,0,'2020-00002',NULL,'2020-06-16 12:52:49',NULL,NULL,NULL,NULL,1,NULL,4,1,NULL,NULL),('001-202007-0000028',2,5,2,1,1,1,'Coba LBBBBBB','Test Schedule Destroy','2020-06-01','2020-06-01','2020','10','2030',NULL,12,0,0,0,'2020-00003',NULL,'2020-06-16 13:37:42',NULL,NULL,NULL,NULL,1,NULL,1,1,NULL,NULL),('001-202007-0000029',2,5,2,1,1,8,'Hukum','Testesfd','2020-06-01','2020-06-01','2020','10','2030',NULL,12,0,0,0,'2020-00004',NULL,'2020-06-16 14:49:05',NULL,NULL,NULL,NULL,1,NULL,1,1,NULL,NULL),('001-202007-0000030',2,5,2,1,3,5,'Coba Lagi Edit','Test input data','2020-06-01','2020-06-16','2020','10','2030',NULL,0,12,0,0,'2020-00005',NULL,'2020-06-16 17:38:02',NULL,NULL,NULL,NULL,1,NULL,1,1,NULL,NULL),('001-202007-0000031',2,5,2,1,1,1,'Bilyet Saldo Kliring Bank-bank','Test in place','2020-06-01','2020-06-16','2020','10','2030',NULL,0,0,0,12,'2020-00006',NULL,'2020-06-16 17:40:43',NULL,NULL,NULL,NULL,1,NULL,1,1,NULL,NULL),('001-202007-0000032',2,5,2,1,3,7,'BBBBBBB','sfklskdhjkh213h12dwadad','2015-06-16','2015-08-16','2011','10','2030',NULL,0,20,0,0,'2020-00007',NULL,'2020-06-16 17:44:17',NULL,NULL,NULL,NULL,1,NULL,1,1,NULL,NULL),('001-202007-0000033',2,5,2,1,1,1,'BBBBBBB','Coba lagi destroy','2011-01-16','2011-08-16','2011','10','2030',NULL,0,0,22,0,'2020-00008',NULL,'2020-06-16 17:45:52',NULL,NULL,NULL,NULL,1,NULL,1,1,NULL,NULL),('001-202007-0000034',1,6,1,1,3,5,'BBBBBBB','Coba coba aja','2020-06-01','2020-06-16','2020','10','2030',NULL,0,0,20,0,'2020-00009',NULL,'2020-06-16 19:52:52',NULL,NULL,NULL,NULL,1,NULL,1,1,NULL,NULL),('001-202007-0000035',2,5,2,1,1,1,'Bilyet Saldo Kliring Bank-bank','Test Hari Rabu','2020-06-01','2020-06-17','2020','10','2030',NULL,0,20,0,0,'2020-00009',NULL,'2020-06-17 11:08:24',NULL,NULL,NULL,NULL,1,NULL,1,1,NULL,NULL),('001-202007-0000036',2,5,2,1,1,4,'BBBBBBB','Test apa lagi','2015-01-01','2015-03-27','2015','10','2030',NULL,12,22,30,0,'2020-00010',NULL,'2020-06-17 11:09:41',NULL,NULL,NULL,NULL,1,NULL,1,1,NULL,NULL),('001-202007-0000037',2,5,2,1,3,5,'Bilyet Saldo Kliring Bank-bank','Apa deh aja','2011-01-18','2011-04-12','2011','10','2030',NULL,20,10,0,0,'2020-00011',NULL,'2020-06-17 11:10:44',NULL,NULL,NULL,NULL,1,NULL,1,1,NULL,NULL),('001-202007-0000038',2,5,2,1,3,5,'Data Digital Aplikasi','Harusnya sih tambah 1','2015-02-02','2015-06-17','2015','10','2030',NULL,12,22,0,12,'2020-00012',NULL,'2020-06-17 11:11:35',NULL,NULL,NULL,NULL,1,NULL,1,1,NULL,NULL),('001-202007-0000039',1,6,1,1,3,5,'Hukum Compliance','Record management','2020-06-01','2020-06-17','2020','10','2031',NULL,12,12,12,0,'2020-00010',NULL,'2020-06-17 12:17:06',NULL,NULL,NULL,NULL,1,NULL,1,1,NULL,NULL),('001-202007-0000040',1,2,2,1,3,5,'Coba Lagi Edit','IT DPDI Nomor 03','2020-06-01','2020-06-17','2020','10','2020',4,12,12,0,12,'2020-00013',3455,'2020-06-17 12:22:25',NULL,'2020','2020-06-26 17:40:07','MAYBANK_Resume Yoga-min.pdf',1,3,2,1,NULL,'2020-06-19 02:58:57'),('001-202007-0000041',1,2,2,1,3,4,'Data Digital Aplikasi','Pastikan dia tidak salah masuk','2020-06-01','2020-06-17','2020','10','2019',4,22,0,0,0,'2020-00014',541,'2020-06-17 12:22:51',NULL,'2020','2020-06-26 17:40:07','MAYBANK_Resume Yoga-min.pdf',1,3,2,1,NULL,'2020-06-19 02:52:09'),('001-202007-0000042',2,3,1,1,3,8,'Coba LBBBBBB','Coba input data','2020-06-01','2020-06-17','2020','10','2031',NULL,12,21,12,0,'2020-00011',NULL,'2020-06-17 17:37:43',NULL,NULL,NULL,NULL,1,NULL,1,1,NULL,NULL),('001-202007-0000043',1,12,3,10,3,1,'Data Digital Aplikasi','Coba test FAD','2020-06-01','2020-06-17','2020','10','2018',9,12,12,12,0,'2020-00007',10554467,'2020-06-17 17:42:41',NULL,'2020','2020-06-26 23:09:39','SKK Wardah Goes To Indomaret.docx.pdf',10,NULL,2,1,NULL,NULL),('001-202007-0000044',1,13,3,10,1,5,'Ini adalah dokumen','Apa aja deh','2020-06-01','2020-06-18','2020','10','2017',9,12,22,12,0,'2020-00008',230099,'2020-06-18 10:18:48',NULL,'2020','2020-06-26 23:09:39','SKK Wardah Goes To Indomaret.docx.pdf',10,3,2,1,NULL,'2020-06-25 00:19:32'),('001-202007-0000045',1,13,3,10,3,1,'Bilyet Saldo Kliring Bank-bank','Tambahin dokumen','2020-06-01','2020-06-17','2020','10','2021',8,0,12,22,0,'2020-00009',230100,'2020-06-18 19:27:18',NULL,NULL,NULL,NULL,10,3,4,0,1,'2020-06-25 00:19:38'),('001-202007-0000048',1,4,1,1,1,1,'Bilyet Saldo Kliring Bank-bank','Asal asalan','2020-06-01','2020-06-20','2020','10','2019',NULL,12,12,12,0,'2020-00012',NULL,'2020-06-20 14:43:19',NULL,NULL,NULL,NULL,1,NULL,1,1,NULL,NULL),('001-202007-0000049',1,14,5,14,1,2,'Bilyet Saldo Kliring Bank-bank','CRA Dok','2020-06-01','2020-06-20','2020','10','2020',NULL,0,12,0,0,'2020-00001',1,'2020-06-20 15:03:17',NULL,NULL,NULL,NULL,14,3,3,1,NULL,'2020-06-21 13:24:37'),('001-202007-0000050',1,14,5,14,1,1,'Ini adalah dokumen','Coba cba','2006-02-01','2006-02-24','2006','10','2017',NULL,20,45,10,0,'2020-00002',123,'2020-06-21 13:19:41',NULL,NULL,NULL,NULL,14,3,3,1,NULL,'2020-06-21 13:24:42'),('001-202007-0000051',1,14,5,14,1,5,'Hukum Compliance','Compliance','2007-02-01','2007-02-28','2007','10','2018',NULL,0,26,0,0,'2020-00003',541,'2020-06-21 13:20:08',NULL,NULL,NULL,NULL,14,3,3,1,NULL,'2020-06-21 13:24:46'),('001-202007-0000052',1,14,5,14,3,7,'Data Digital Aplikasi','Compliance Digital','2008-02-01','2008-02-23','2008','10','2019',NULL,0,0,6,0,'2020-00004',123,'2020-06-21 13:20:37',NULL,NULL,NULL,NULL,14,3,3,1,NULL,'2020-06-21 13:24:50'),('001-202007-0000053',1,14,5,14,3,3,'Coba Lagi Edit','test lagi dehhhhh','2005-04-07','2005-08-31','2005','10','2016',NULL,0,15,0,0,'2020-00005',1234,'2020-06-21 13:21:15',NULL,NULL,NULL,NULL,14,3,3,1,NULL,'2020-06-21 13:24:55'),('001-202007-0000054',1,1,1,1,1,3,'Ini adalah dokumen','Test otomatis box number','2009-04-01','2009-05-14','2009','10','2020',NULL,27,0,0,0,'2020-00007',NULL,'2020-06-24 16:27:39',NULL,NULL,NULL,NULL,1,NULL,1,NULL,NULL,NULL),('001-202007-0000055',1,15,3,10,1,1,'Bilyet Saldo Kliring Bank-bank','Keuangann apa aja','2007-02-01','2007-03-02','2007','10','2018',NULL,20,0,0,0,'2020-00001',NULL,'2020-06-24 16:31:13',NULL,NULL,NULL,NULL,10,NULL,1,NULL,NULL,NULL),('001-202007-0000059',1,15,3,10,1,1,'Bilyet Saldo Kliring Bank-bank','Bilyet FAD banyak','2005-04-07','2005-04-07','2005','10','2016',NULL,0,29,0,0,'2020-00002',NULL,'2020-06-24 16:43:05',NULL,NULL,NULL,NULL,10,NULL,1,NULL,NULL,NULL),('001-202007-0000060',1,15,3,10,1,1,'Ini adalah dokumen','Pokoknya punya FAD 2007 ya','2007-02-01','2007-02-28','2007','10','2018',NULL,0,45,0,0,'2020-00003',NULL,'2020-06-24 16:54:33',NULL,NULL,NULL,NULL,10,NULL,1,NULL,NULL,NULL),('001-202007-0000063',1,16,3,10,1,1,'Coba apa yaaaa','Dokumen arsip FAD tahun 2005 nih','2005-04-07','2005-04-07','2005','10','2016',NULL,0,15,0,0,'2020-00004',5433,'2020-06-24 17:31:51',NULL,NULL,NULL,NULL,10,3,1,NULL,NULL,'2020-07-02 14:40:24'),('001-202007-0000064',1,16,3,10,1,2,'Coba Lagi Edit','FAD lah','2005-04-15','2006-02-24','2006','10','2017',NULL,20,0,0,0,'2020-00005',5432,'2020-06-24 17:32:14',NULL,NULL,NULL,NULL,10,3,1,NULL,NULL,'2020-07-02 14:40:28'),('001-202007-0000065',1,17,3,10,3,5,'Dokumen Penting Deh','FAD 2006','2006-02-01','2006-02-01','2006','10','2017',NULL,0,0,22,0,'2020-00006',NULL,'2020-06-24 17:32:50',NULL,NULL,NULL,NULL,10,NULL,1,NULL,NULL,NULL),('001-202007-0000066',1,4,1,1,1,2,'Coba Lagi Edit','Corsec nih','2020-06-03','2020-06-27','2020','10','2031',NULL,31,0,0,0,'2020-00008',NULL,'2020-06-24 17:33:45',NULL,NULL,NULL,NULL,1,NULL,1,NULL,NULL,NULL),('001-202007-0000067',1,18,5,14,3,5,'Ini adalah dokumen','Test Punya CRA','2005-04-07','2005-04-07','2005','10','2016',NULL,20,0,0,0,'2020-00006',12121,'2020-06-24 17:49:32',NULL,NULL,NULL,NULL,14,3,3,1,NULL,'2020-06-25 00:17:40'),('001-202007-0000068',1,18,5,14,1,1,'Hukum Compliance','Compliance 2005','2005-04-07','2005-04-07','2005','10','2016',NULL,0,29,0,0,'2020-00007',212122,'2020-06-24 17:50:03',NULL,NULL,NULL,NULL,14,3,4,1,NULL,'2020-06-25 00:17:44'),('001-202007-0000069',1,15,3,1,1,1,'Arsip Aplikasi','Coba input tanpa modal','2020-07-01','2020-07-10','2020','10','2031',NULL,12,20,0,0,'2020-00010',NULL,'2020-07-10 22:59:17',NULL,NULL,NULL,NULL,1,NULL,1,NULL,NULL,NULL),('001-202007-0000070',1,1,1,1,1,1,'Coba apa yaaaa','Input tanda modal deh','2020-07-01','2020-07-10','2020','10','2031',NULL,0,20,0,0,'2020-00013',NULL,'2020-07-10 23:02:36',NULL,NULL,NULL,NULL,1,NULL,1,NULL,NULL,NULL),('001-202007-0000071',1,15,3,1,1,0,'Ini adalah dokumen','Coba dropdown nya nih','2020-07-01','2020-07-10','2020','10','2031',NULL,0,32,0,0,'2020-00011',NULL,'2020-07-11 01:46:36',NULL,NULL,NULL,NULL,1,NULL,1,NULL,NULL,NULL),('001-202007-0000072',1,15,3,1,8,0,'Arsip Aplikasi','Coba Klasifikasi IT Chain Dropdown','2020-07-01','2020-07-10','2020','10','2031',NULL,11,27,24,0,'2020-00012',NULL,'2020-07-11 01:53:40',NULL,NULL,NULL,NULL,1,NULL,1,NULL,NULL,NULL),('001-202007-0000073',1,6,1,1,1,0,'Ini adalah dokumen','Coba lagi Chain Dropdown Corsec','2020-07-01','2020-07-10','2020','10','2031',NULL,0,28,11,0,'2020-00014',NULL,'2020-07-11 01:56:29',NULL,NULL,NULL,NULL,1,NULL,1,NULL,NULL,NULL),('001-202007-0000074',1,15,3,1,1,0,'Bilyet Saldo Kliring Bank-bank','sdsdfsd','2020-07-01','2020-07-10','2020','10','2031',NULL,12,0,0,0,'2020-00013',NULL,'2020-07-11 03:22:24',NULL,NULL,NULL,NULL,1,NULL,1,NULL,NULL,NULL),('001-202007-0000075',1,15,3,1,8,0,'Arsip Aplikasi','sadqwdsadas','2020-07-01','2020-07-10','2020','13','2034',NULL,43,0,0,0,'2020-00014',NULL,'2020-07-11 03:38:10',NULL,NULL,NULL,NULL,1,NULL,1,NULL,NULL,NULL),('001-202007-0000076',1,20,5,14,1,0,'Bilyet Saldo Kliring Bank-bank','Test ','2020-07-01','2020-07-11','2020','10','2031',NULL,12,0,12,0,'2020-00008',12345678,'2020-07-17 17:10:46',NULL,NULL,NULL,NULL,14,17,1,1,NULL,'2020-07-17 17:44:20'),('001-202007-0000077',1,20,5,14,3,0,'Data Digital Aplikasi','Deskripsi dokumen','2020-07-01','2020-07-18','2020','5','2026',NULL,0,25,0,0,'2020-00009',12345679,'2020-07-17 17:11:12',NULL,NULL,NULL,NULL,14,17,1,1,NULL,'2020-07-17 17:44:27'),('001-202007-0000078',1,1,1,1,1,0,'AAAAAAAA','rerasdsa','2020-07-01','2020-07-18','2020','14','2035',NULL,0,26,0,0,'2020-00016',NULL,'2020-07-18 16:29:26',NULL,NULL,NULL,NULL,1,NULL,1,NULL,NULL,NULL),('001-202007-0000079',1,1,1,1,8,0,'Arsip Aplikasi','asdasdas','2005-04-07','2006-02-24','2006','13','2020',NULL,20,0,34,0,'2020-00017',NULL,'2020-07-18 16:30:04',NULL,NULL,NULL,NULL,1,NULL,1,NULL,NULL,NULL),('001-202007-0000080',1,1,1,1,1,0,'Bilyet Saldo Kliring Bank-bank','asa','2020-07-01','2020-07-18','2020','10','2031',NULL,0,12,0,0,'2020-00018',NULL,'2020-07-18 17:10:12',NULL,NULL,NULL,NULL,1,NULL,1,NULL,NULL,NULL);
/*!40000 ALTER TABLE `document_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `document_feeding`
--

DROP TABLE IF EXISTS `document_feeding`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `document_feeding` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `feeding_number` varchar(16) DEFAULT NULL,
  `feeding_desc` varchar(128) DEFAULT NULL,
  `working_unit_id` varchar(128) DEFAULT NULL,
  `recordcenter_id` int(11) DEFAULT NULL,
  `note` varchar(128) DEFAULT NULL,
  `attachment` varchar(128) DEFAULT NULL,
  `is_active` int(11) DEFAULT NULL,
  `creator_id` int(11) DEFAULT NULL,
  `approver_id` int(11) DEFAULT NULL,
  `modifier_id` int(11) DEFAULT NULL,
  `feeding_date` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `date_expired` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document_feeding`
--

LOCK TABLES `document_feeding` WRITE;
/*!40000 ALTER TABLE `document_feeding` DISABLE KEYS */;
INSERT INTO `document_feeding` VALUES (1,'No.DPDI.2020.001','Test input pemindahan','1',1,NULL,NULL,1,1,NULL,1,'2020-06-14 21:41:17','2020-06-16 01:12:15',NULL),(2,'No.DPDI.2020.002','IT Asset Management Arsip','2',3,'Baru setengah bro',NULL,10,1,1,3,'2020-06-14 21:46:36','2020-06-19 03:14:13',NULL),(3,'No.DPDI.2020.003','Dokumen Corporate Secretary 2010','1',2,NULL,NULL,1,1,NULL,1,'2020-06-14 21:51:52','2020-06-16 01:12:01',NULL),(4,'No.DPDI.2020.004','Pemindahan','1',1,NULL,NULL,1,1,NULL,1,'2020-06-14 22:06:46','2020-06-16 01:10:31',NULL),(5,'No.DPDI.2020.005','Operator Test DPDI','2',2,NULL,NULL,6,10,1,3,'2020-06-14 22:08:13','2020-07-14 21:40:17',NULL),(6,'No.DPDI.2020.006','Test Senin','1',1,NULL,NULL,1,1,NULL,NULL,'2020-06-15 09:54:27',NULL,NULL),(12,'No.DPDI.2020.007','Pemindahan dokumen inaktif FAD','3',1,'OK Jalankan',NULL,8,10,1,3,'2020-06-17 17:41:22','2020-06-19 03:15:21',NULL),(13,'No.DPDI.2020.008','Dokumen FAD lagi','3',1,NULL,NULL,5,1,1,3,'2020-06-18 10:15:16','2020-06-25 00:19:43',NULL),(14,'No.DPDI.2020.009','Dokumen Arsip CRA 2010','5',1,NULL,NULL,7,14,1,3,'2020-06-20 15:02:53','2020-06-21 13:24:59',NULL),(15,'No.DPDI.2020.010','Dokumen FAD Keuangan Tahun 2007 ','3',1,NULL,NULL,1,10,NULL,NULL,'2020-06-24 16:30:40',NULL,NULL),(16,'No.DPDI.2020.011','Dokumen Arsip FAD Tahun 2005','3',1,'Lokasi simpan edit',NULL,6,10,13,3,'2020-06-24 17:28:49','2020-07-15 17:26:22',NULL),(17,'No.DPDI.2020.012','FAD Tahun 2006','3',1,NULL,NULL,3,10,NULL,10,'2020-06-24 17:32:29','2020-07-02 14:32:31',NULL),(18,'No.DPDI.2020.013','CRA Arsip Inaktif 2005','5',1,'Tolong Dokumen nya dikirim',NULL,7,14,15,3,'2020-06-24 17:48:41','2020-06-25 00:18:03',NULL),(20,'No.DPDI.2020.014','Pemindahan dokumen CRA 2020','5',1,'Dokumen telah selesai direview dan sudah diatur lokasi penyimpanan. Mohon segera dikirim',NULL,8,14,1,17,'2020-07-17 17:10:14','2020-07-17 17:44:31',NULL);
/*!40000 ALTER TABLE `document_feeding` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `document_feeding_status`
--

DROP TABLE IF EXISTS `document_feeding_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `document_feeding_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document_feeding_status`
--

LOCK TABLES `document_feeding_status` WRITE;
/*!40000 ALTER TABLE `document_feeding_status` DISABLE KEYS */;
INSERT INTO `document_feeding_status` VALUES (1,'Tidak lengkap'),(2,'Revisi - UK / Cabang'),(3,'Menunggu persetujuan atasan - UK / Cabang'),(4,'Review Corporate Secretary'),(5,'Persetujuan Corporate Secretary'),(6,'Menunggu lokasi simpan - RC'),(7,'Verifikasi Corporate Secretary'),(8,'Menunggu persetujuan FPDI - UK / Cabang'),(9,'Menunggu pengiriman - UK / Cabang'),(10,'Dokumen diterima sebagian - RC'),(11,'Proses pengiriman selesai');
/*!40000 ALTER TABLE `document_feeding_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `document_location`
--

DROP TABLE IF EXISTS `document_location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `document_location` (
  `id` varchar(20) NOT NULL,
  `record_center_code` int(11) DEFAULT NULL,
  `doc_storage_code` int(11) DEFAULT NULL,
  `doc_location_number` int(11) DEFAULT NULL,
  `doc_location_coloumn` int(11) DEFAULT NULL,
  `doc_location_capacity` int(11) DEFAULT NULL,
  `doc_location_status` varchar(10) DEFAULT '1',
  `is_active` int(1) DEFAULT '1',
  `creator_id` int(11) DEFAULT NULL,
  `modifier_id` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document_location`
--

LOCK TABLES `document_location` WRITE;
/*!40000 ALTER TABLE `document_location` DISABLE KEYS */;
INSERT INTO `document_location` VALUES ('01-A010101',1,1,1,1,72,'1',1,NULL,NULL,NULL,NULL),('01-A010102',1,1,1,2,48,'1',1,NULL,NULL,NULL,NULL),('01-A010103',1,1,1,3,48,'1',1,NULL,NULL,NULL,NULL),('01-B010102',1,1,1,1,120,'1',1,1,1,'2020-06-12 01:13:01','2020-06-12 10:09:17'),('01-B010104',1,4,3,2,45,'1',1,1,1,'2020-06-11 22:33:37','2020-06-13 00:36:49');
/*!40000 ALTER TABLE `document_location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `document_location_status`
--

DROP TABLE IF EXISTS `document_location_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `document_location_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dl_status` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document_location_status`
--

LOCK TABLES `document_location_status` WRITE;
/*!40000 ALTER TABLE `document_location_status` DISABLE KEYS */;
INSERT INTO `document_location_status` VALUES (1,'Available'),(2,'Full');
/*!40000 ALTER TABLE `document_location_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `document_reference`
--

DROP TABLE IF EXISTS `document_reference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `document_reference` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `classification_id` int(11) DEFAULT NULL,
  `dr_code` varchar(45) DEFAULT NULL,
  `dr_name` varchar(45) DEFAULT NULL,
  `active_retention` int(11) DEFAULT NULL,
  `inactive_retention` int(11) DEFAULT NULL,
  `total_retention` int(11) DEFAULT NULL,
  `is_active` int(1) DEFAULT '1',
  `creator_id` int(11) DEFAULT NULL,
  `modifier_id` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `classification_id_idx` (`classification_id`),
  CONSTRAINT `classification_id` FOREIGN KEY (`classification_id`) REFERENCES `document_classification` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document_reference`
--

LOCK TABLES `document_reference` WRITE;
/*!40000 ALTER TABLE `document_reference` DISABLE KEYS */;
INSERT INTO `document_reference` VALUES (1,1,'KA.01.A','Bilyet Saldo Kliring Bank-bank',3,7,10,1,NULL,NULL,NULL,NULL),(2,1,'KA.01.B','Coba Lagi Edit',2,8,10,1,1,1,'2020-06-12 16:31:38','2020-06-13 00:40:12'),(3,1,'KA.01.B','Ini adalah dokumen',2,8,10,1,1,1,'2020-06-12 16:31:38','2020-06-18 01:28:03'),(4,1,'KA.01.B','Coba apa yaaaa',2,8,10,1,1,1,'2020-06-12 16:31:38','2020-06-18 01:28:18'),(5,3,'DA.03.RM','Data Digital Aplikasi',3,7,5,1,1,NULL,'2020-06-13 02:07:45',NULL),(6,1,'KA.01.A','AAAAAAAA',7,7,14,1,NULL,1,NULL,'2020-06-16 11:02:12'),(7,3,'HK.11.D','Hukum',5,7,12,1,1,1,'2020-06-16 10:58:59','2020-06-16 11:01:46'),(8,3,'HK.11.A','Hukum Compliance',10,1,11,1,1,1,'2020-06-16 11:00:08','2020-06-16 11:01:37'),(9,3,'DJ.13.A1','Dokumen Penting Deh',5,7,12,1,1,1,'2020-06-18 01:25:03','2020-07-08 18:16:19'),(10,8,'TI.01.A','Arsip Aplikasi',10,3,13,1,1,NULL,'2020-07-08 18:15:58',NULL);
/*!40000 ALTER TABLE `document_reference` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `document_status`
--

DROP TABLE IF EXISTS `document_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `document_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status_name` varchar(45) DEFAULT NULL,
  `creator_id` int(11) DEFAULT NULL,
  `modifier_id` int(11) DEFAULT NULL,
  `is_active` int(1) DEFAULT '1',
  `date_created` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document_status`
--

LOCK TABLES `document_status` WRITE;
/*!40000 ALTER TABLE `document_status` DISABLE KEYS */;
INSERT INTO `document_status` VALUES (1,'In Place',1,NULL,1,NULL,NULL),(2,'Destroyed',1,NULL,1,'2020-06-11 10:00:00',NULL),(3,'Schedule Destroy',1,NULL,1,'2020-06-11 10:00:00',NULL),(4,'Pending Destroy',1,1,1,'2020-06-11 10:00:00',NULL),(5,'Borrowed',1,NULL,1,'2020-06-11 10:00:00','2020-06-13 00:38:15');
/*!40000 ALTER TABLE `document_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `document_storage`
--

DROP TABLE IF EXISTS `document_storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `document_storage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ds_code` varchar(10) DEFAULT NULL,
  `ds_name` varchar(45) DEFAULT NULL,
  `storage_type_id` int(11) DEFAULT NULL,
  `record_center_code` int(11) DEFAULT NULL,
  `is_active` int(1) DEFAULT '1',
  `creator_id` int(11) DEFAULT NULL,
  `modifier_id` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document_storage`
--

LOCK TABLES `document_storage` WRITE;
/*!40000 ALTER TABLE `document_storage` DISABLE KEYS */;
INSERT INTO `document_storage` VALUES (1,'01-A','Building A',1,1,1,NULL,NULL,NULL,NULL),(2,'01-B','Building B',1,1,1,NULL,NULL,NULL,NULL),(3,'01-C','Building C',1,1,1,NULL,NULL,NULL,NULL),(4,'01-D','Building D',1,1,1,NULL,1,NULL,'2020-06-13 00:37:51');
/*!40000 ALTER TABLE `document_storage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `record_center`
--

DROP TABLE IF EXISTS `record_center`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `record_center` (
  `id` int(3) NOT NULL,
  `rc_name` varchar(45) DEFAULT NULL,
  `rc_address` varchar(256) DEFAULT NULL,
  `rc_city` varchar(45) DEFAULT NULL,
  `rc_phone` varchar(24) DEFAULT NULL,
  `creator_id` int(11) DEFAULT NULL,
  `modifier_id` int(11) DEFAULT NULL,
  `is_active` int(1) DEFAULT '1',
  `date_created` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `record_center`
--

LOCK TABLES `record_center` WRITE;
/*!40000 ALTER TABLE `record_center` DISABLE KEYS */;
INSERT INTO `record_center` VALUES (1,'Cikupa','Jl. Markisa','Tangerang','021-55961631',1,NULL,1,'2020-06-11 12:02:55',NULL),(2,'Magelang','Jl. Magelang Raya','Magelang','0000000',1,2,1,'2020-06-11 12:02:55','2020-06-11 12:14:13'),(3,'Khasanah SS3','Jl. Asia Afrika No. 8','Jakarta','0000000',1,2,1,'2020-06-11 12:02:55','2020-06-11 12:14:07'),(4,'Records Center Bali','Jalan Bypass Ngurah Rai','Denpasar','02417788662',1,1,1,'2020-06-11 12:02:55','2020-06-11 16:05:31'),(5,'Jakarta Record Center ','Jalan Gatot Subroto','Jakarta Pusat','02122729899',1,1,1,'2020-06-12 01:17:01','2020-06-13 00:38:29');
/*!40000 ALTER TABLE `record_center` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `storage_type`
--

DROP TABLE IF EXISTS `storage_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `storage_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `storage_type_name` varchar(45) DEFAULT NULL,
  `is_active` int(1) DEFAULT '1',
  `creator_id` int(11) DEFAULT NULL,
  `modifier_id` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `storage_type`
--

LOCK TABLES `storage_type` WRITE;
/*!40000 ALTER TABLE `storage_type` DISABLE KEYS */;
INSERT INTO `storage_type` VALUES (1,'Racking System',1,1,NULL,'2020-06-11 12:31:02',NULL),(2,'Mobile Files',1,1,1,'2020-06-11 12:31:02','2020-06-13 00:38:04');
/*!40000 ALTER TABLE `storage_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `image` varchar(45) DEFAULT NULL,
  `password` varchar(256) DEFAULT NULL,
  `working_unit_id` varchar(24) NOT NULL,
  `role_id` int(11) NOT NULL,
  `is_active` int(1) DEFAULT NULL,
  `creator_id` int(11) DEFAULT NULL,
  `modifier_id` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'Yoga Hilmi Tasanah','yogahilmi@gmail.com','yoga.jpeg','$2y$10$SB3S5Ok9GbJIhaAdmQPrcetY93PInXD54t05fhHtNh34TPI7AQDT6','1',1,1,NULL,NULL,'2020-06-06 08:42:10',NULL),(2,'Anggilia Dwi Astika','anggiliadwi24@gmail.com','image8_ed.jpeg','$2y$10$8CEd0SfJI4S9YwNJ/7/t7OHQjbkVRagUSUJCq74pmwbm72slQ3xdm','1',2,1,NULL,1,'2020-06-07 01:42:10','2020-06-12 01:50:54'),(3,'Ferdiansyah','ferdiansyah@budiluhur.ac.id','default.png','$2y$10$LiN8ulZUfxa3zora81SYbu.UiB07vQhMeeR2R0ymwFrcElZJFrmAy','2',4,1,NULL,NULL,'2020-06-09 10:11:10',NULL),(5,'Agung Prasetyo','agung.ulit@gmail.com','default.png','$2y$10$.c/oNNvFjLf6s0EChk/FEejtHMfFbLSDcv5b7ExjuGYXR1EqEFaeu','2',5,1,NULL,NULL,'2020-06-06 01:42:10',NULL),(6,'Arino','arino@maybank.co.id','default.png','$2y$10$Tj9FLgVX5SSDBITPJnj7G.7EaOUCs7EZBCoegocyvVCdCrj17GkMm','1',3,1,NULL,NULL,'2020-06-12 01:42:10',NULL),(10,'Operator','operator@mail.com','default.png','$2y$10$bzHC1sO6DnERv3yh546d1uftPad.j4.He5NJuWDNeuNywp.oMrXzG','3',6,1,1,NULL,'2020-06-12 20:28:03',NULL),(12,'Test Edit','test@mail.com','default.png','$2y$10$m3iZMyHnHk43Tjk.u1iHZ.3gzIMkkA7t7Uy5woMOnuYqxGCu7C4H2','2',6,1,1,1,'2020-06-13 00:07:46','2020-06-13 00:29:20'),(13,'Approver','approver@mail.com','default.png','$2y$10$Z2v9OfHbDw3/lkJBsyL0KOcR9cRjPm/MR.F.vL/VFnlLozqAr1NBm','3',5,1,1,NULL,'2020-06-18 09:08:03',NULL),(14,'Nadia','nadia@mail.com','default.png','$2y$10$Rto3grss7o2/crn0QYtpp.0r0gsVtaax3dyG6hNmED0Ar3.1IMRyW','5',6,1,1,NULL,'2020-06-20 15:02:21',NULL),(15,'Dedi','dedi@mail.com','default.png','$2y$10$dIcIL1EfDMTPNV8EhvOd3.6i8Z.ryW0XfU0WFFhzT1JHD6hhbvJTi','5',5,1,1,NULL,'2020-06-25 00:01:27',NULL),(16,'Operator Corsec','checker@mail.com','default.png','$2y$10$GILQUanrW51cqPu9pWth6eURh6CVUuv.S/fMiIBzM6C3rg9bsv2.K','1',7,1,1,NULL,'2020-07-14 18:00:15',NULL),(17,'Record Center Cikupa','rc@mail.com','default.png','$2y$10$ViwYKpbjNxpfxnDlKT6EPuhJirvsmmZgO0Ck4Y0zrvzN8GQ2mLiFW','1',4,1,1,NULL,'2020-07-17 17:43:02',NULL);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_access_menu`
--

DROP TABLE IF EXISTS `user_access_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_access_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) DEFAULT NULL,
  `menu_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=78 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_access_menu`
--

LOCK TABLES `user_access_menu` WRITE;
/*!40000 ALTER TABLE `user_access_menu` DISABLE KEYS */;
INSERT INTO `user_access_menu` VALUES (9,1,1),(10,2,2),(17,1,2),(21,1,3),(22,1,5),(23,1,6),(26,1,9),(27,1,7),(28,2,1),(33,1,4),(34,2,4),(35,3,1),(36,3,2),(38,4,1),(39,4,2),(41,5,1),(42,5,2),(44,1,10),(45,2,10),(46,1,11),(47,2,11),(56,3,11),(57,3,4),(59,8,2),(60,8,10),(61,8,1),(62,4,11),(63,5,10),(68,2,6),(69,3,10),(70,6,1),(71,6,2),(72,6,10),(73,7,1),(74,7,2),(75,7,4),(76,7,10),(77,7,11);
/*!40000 ALTER TABLE `user_access_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_menu`
--

DROP TABLE IF EXISTS `user_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menu` varchar(45) DEFAULT NULL,
  `position` int(2) DEFAULT NULL,
  `creator_id` int(11) DEFAULT NULL,
  `modifier_id` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_menu`
--

LOCK TABLES `user_menu` WRITE;
/*!40000 ALTER TABLE `user_menu` DISABLE KEYS */;
INSERT INTO `user_menu` VALUES (1,'Dashboard',1,NULL,NULL,NULL,NULL),(2,'User',4,NULL,NULL,NULL,NULL),(3,'Menu',6,NULL,NULL,NULL,NULL),(4,'Data',3,NULL,1,NULL,'2020-06-12 13:50:48'),(6,'Admin',5,NULL,NULL,NULL,NULL),(10,'Dokumen',2,NULL,1,NULL,'2020-06-14 18:34:18'),(11,'Master',7,NULL,1,NULL,'2020-06-13 00:34:00');
/*!40000 ALTER TABLE `user_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_role`
--

DROP TABLE IF EXISTS `user_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role` varchar(128) DEFAULT NULL,
  `creator_id` int(11) DEFAULT NULL,
  `modifier_id` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_role`
--

LOCK TABLES `user_role` WRITE;
/*!40000 ALTER TABLE `user_role` DISABLE KEYS */;
INSERT INTO `user_role` VALUES (1,'Administrator',NULL,NULL,NULL,NULL),(2,'Admin-RMS',NULL,NULL,NULL,NULL),(3,'RMS-Corsec',NULL,1,NULL,'2020-06-12 19:51:27'),(4,'RMS-RecordCenter',NULL,1,NULL,'2020-06-12 19:51:05'),(5,'RMS-Approver',NULL,1,NULL,'2020-06-12 19:51:39'),(6,'RMS-Operator',1,1,'2020-06-12 19:51:53','2020-06-13 00:22:49'),(7,'RMS-Corsec_OPT',1,1,'2020-07-14 17:59:13','2020-07-14 18:15:16');
/*!40000 ALTER TABLE `user_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_status`
--

DROP TABLE IF EXISTS `user_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_status` (
  `id` int(1) NOT NULL AUTO_INCREMENT,
  `status` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_status`
--

LOCK TABLES `user_status` WRITE;
/*!40000 ALTER TABLE `user_status` DISABLE KEYS */;
INSERT INTO `user_status` VALUES (0,'Inactive'),(1,'Active');
/*!40000 ALTER TABLE `user_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_sub_menu`
--

DROP TABLE IF EXISTS `user_sub_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_sub_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menu_id` int(11) DEFAULT NULL,
  `title` varchar(45) DEFAULT NULL,
  `url` varchar(45) DEFAULT NULL,
  `icon` varchar(45) DEFAULT NULL,
  `sub_menu_desc` varchar(128) DEFAULT NULL,
  `is_active` int(1) DEFAULT NULL,
  `creator_id` int(11) DEFAULT NULL,
  `modifier_id` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_sub_menu`
--

LOCK TABLES `user_sub_menu` WRITE;
/*!40000 ALTER TABLE `user_sub_menu` DISABLE KEYS */;
INSERT INTO `user_sub_menu` VALUES (1,1,'Dashboard','dashboard','fas fa-fw fa-tachometer-alt','',1,NULL,1,NULL,'2020-06-12 19:06:15'),(2,2,'My Profile','user/profile','fas fa-fw fa-user',NULL,1,NULL,1,NULL,'2020-06-12 16:49:11'),(3,2,'Edit Profile','user/edit','fas fa-fw fa-user-edit',NULL,1,NULL,NULL,NULL,NULL),(4,3,'Menu Management','menu','fas fa-fw fa-folder',NULL,1,NULL,NULL,NULL,NULL),(5,3,'Submenu Management','menu/submenu','fas fa-fw fa-folder-open',NULL,1,NULL,NULL,NULL,NULL),(9,2,'Change Password','user/changepassword','fas fa-fw fa-key',NULL,1,NULL,NULL,NULL,NULL),(10,6,'Role Management','admin/role','fas fa-fw fa-user-tag',NULL,1,NULL,NULL,NULL,NULL),(11,10,'Pemindahan','dokumen/pemindahan','fas fa-fw fa-file-medical','Pemindahan dokumen dari unit kerja atau cabang ke Records Center.',1,NULL,1,NULL,'2020-06-14 18:32:44'),(13,6,'User Management','admin/userman','fas fa-fw fa-user-tie',NULL,1,NULL,NULL,NULL,NULL),(14,4,'Pemusnahan','data/pemusnahan','fas fa-fw fa-file-excel','Pemusnahan Dokumen inaktif yang telah memasuki retensi.',1,NULL,1,NULL,'2020-06-12 22:23:13'),(15,4,'Data Arsip','data/arsip','fas fa-fw fa-file-alt',NULL,1,NULL,NULL,NULL,NULL),(16,10,'Peminjaman','dokumen/peminjaman','fas fa-fw fa-file-import','Peminjaman dokumen inaktif yang telah disimpan pada Records Center.',0,NULL,1,NULL,'2020-06-12 18:42:55'),(17,10,'Pengembalian','dokumen/pengembalian','fas fa-fw fa-file-download',NULL,0,NULL,1,NULL,'2020-06-12 17:20:44'),(18,1,'Data Referensi','dashboard/referensi','fas fa-fw fa-file-alt','',1,NULL,1,NULL,'2020-06-12 21:17:32'),(20,11,'Klasifikasi','master/klasifikasi','fas fa-fw fa-stream',NULL,1,NULL,NULL,NULL,NULL),(21,11,'Lokasi Simpan','master/lokasi','fas fa-fw fa-boxes',NULL,1,NULL,NULL,NULL,NULL),(22,11,'Tempat Penyimpanan','master/storage','fas fa-fw fa-box-open',NULL,1,NULL,NULL,NULL,NULL),(23,11,'Tipe Penyimpanan','master/tipe','fas fa-fw fa-memory',NULL,1,NULL,NULL,NULL,NULL),(24,11,'Status Dokumen','master/status','fas fa-fw fa-info-circle',NULL,1,NULL,NULL,NULL,NULL),(25,6,'Working Unit','admin/workingunit','fas fa-fw fa-users',NULL,1,NULL,1,NULL,'2020-06-12 10:29:00'),(26,11,'Records Center','master/recordcenter','fas fa-fw fa-building','',1,NULL,1,NULL,'2020-06-13 00:22:29'),(30,11,'Nomor Box','master/box','fas fa-fw fa-box','',0,1,1,'2020-06-16 16:16:48','2020-06-24 17:02:36'),(31,4,'Persetujuan Pemindahan','data/pemindahan','fas fa-fw fa-calendar-check','',1,1,1,'2020-06-19 08:54:09','2020-07-14 17:14:04'),(32,4,'Verifikasi DPDI','data/verify','fas fa-fw fa-calendar-check',NULL,1,1,NULL,'2020-07-14 17:12:19',NULL),(33,4,'Daftar Dokumen Musnah','data/ddm','fas fa-fw fa-file-excel',NULL,1,1,NULL,'2020-06-26 14:37:12',NULL);
/*!40000 ALTER TABLE `user_sub_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `working_unit`
--

DROP TABLE IF EXISTS `working_unit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `working_unit` (
  `wu_id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` varchar(45) DEFAULT NULL,
  `directorate_id` int(11) DEFAULT NULL,
  `wu_name` varchar(128) DEFAULT NULL,
  `rc_number` int(11) DEFAULT NULL,
  `address` varchar(128) DEFAULT NULL,
  `city` varchar(128) DEFAULT NULL,
  `is_active` int(1) DEFAULT NULL,
  `creator_id` int(11) DEFAULT NULL,
  `modifier_id` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`wu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `working_unit`
--

LOCK TABLES `working_unit` WRITE;
/*!40000 ALTER TABLE `working_unit` DISABLE KEYS */;
INSERT INTO `working_unit` VALUES (1,'1',1,'Corporate Secretary',932,'Sentral Senayan III','Jakarta Pusat',1,NULL,1,NULL,'2020-06-12 12:42:46'),(2,'1',1,'Information Technology (IT)',845,'Sentral Senayan III Building','Jakarta Pusat',1,1,1,'2020-06-12 11:02:42','2020-06-13 00:32:12'),(3,'2',1,'Finance Accounting',800,'Jalan Asia Afrika No. 8','Jakarta Pusat',1,1,1,'2020-06-13 00:32:51','2020-06-13 00:33:40'),(5,'1',1,'Compliance Regulatory',935,'Sentral Senayan 3','Jakarta Pusat',1,1,NULL,'2020-06-20 15:01:52',NULL),(6,'1',1,'FCC AMLA',921,'Sentral Senayan 3','Jakarta Pusat',1,1,NULL,'2020-06-20 18:34:16',NULL);
/*!40000 ALTER TABLE `working_unit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `working_unit_box`
--

DROP TABLE IF EXISTS `working_unit_box`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `working_unit_box` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `wu_id` int(11) DEFAULT NULL,
  `box_number` varchar(10) DEFAULT NULL,
  `creator_id` int(11) DEFAULT NULL,
  `modifier_id` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `working_unit_box`
--

LOCK TABLES `working_unit_box` WRITE;
/*!40000 ALTER TABLE `working_unit_box` DISABLE KEYS */;
INSERT INTO `working_unit_box` VALUES (1,1,'2020-100',NULL,1,NULL,'2020-06-16 17:14:18'),(3,5,'2020-200',1,1,'2020-06-16 16:40:20','2020-06-21 01:32:29'),(4,2,'2020-120',1,1,'2020-06-16 16:44:42','2020-06-16 17:14:39');
/*!40000 ALTER TABLE `working_unit_box` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'db_arsip'
--

--
-- Dumping routines for database 'db_arsip'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-07-21 16:57:57
