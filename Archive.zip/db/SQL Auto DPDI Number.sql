SELECT box_number, id, document_feeding.working_unit_id
FROM
    document_detail
LEFT JOIN
    document_feeding ON document_feeding.id = document_detail.feeding_id
WHERE
    box_number
LIKE
 '%2020%'
AND
    document_detail.working_unit_id = 3
ORDER BY
    box_number DESC
limit 1

