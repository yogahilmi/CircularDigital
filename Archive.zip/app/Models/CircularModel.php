<?php

namespace App\Models;

use CodeIgniter\Model;

class CircularModel extends Model
{
    public function getBodCircular()
    {
        $db = db_connect();
        $builder = $db->table('tb_circular');
        $builder->select('tb_circular.id, number, subject, description, category_id, circular_date, attachment, workingunit_name, pic_name');
        $builder->join('tb_category', 'tb_category.id = tb_circular.category_id');
        $builder->where('category_id = 3');
        $query = $builder->get();

        return $query;
    }

    public function getBocCircular()
    {
        $db = db_connect();
        $builder = $db->table('tb_circular');
        $builder->select('tb_circular.id, number, subject, description, category_id, circular_date, attachment, workingunit_name, pic_name');
        $builder->join('tb_category', 'tb_category.id = tb_circular.category_id');
        $builder->where('category_id = 4');
        $query = $builder->get();

        return $query;
    }

    public function getComCircular()
    {
        $db = db_connect();
        $builder = $db->table('tb_circular');
        $builder->select('tb_circular.id, number, subject, description, category_id, committee_id, committee, circular_date, attachment, workingunit_name, pic_name');
        $builder->join('tb_category', 'tb_category.id = tb_circular.category_id');
        $builder->join('tb_committee', 'tb_committee.id = tb_circular.committee_id');
        $builder->where('category_id = 5');
        $query = $builder->get();

        return $query;
    }

    public function getDetail($id)
    {
        $db = db_connect();
        $builder = $db->table('tb_circular');
        $builder->select('tb_circular.id, number, subject, description, category_id, category, committee_id, committee, circular_date, attachment, workingunit_name, pic_name');
        $builder->join('tb_category', 'tb_category.id = tb_circular.category_id', 'left');
        $builder->join('tb_committee', 'tb_committee.id = tb_circular.committee_id', 'left');
        $builder->where('tb_circular.id', $id);
        $query = $builder->get();

        return $query;
    }

    public function getCircular()
    {
        $db = db_connect();
        $builder = $db->table('tb_circular');
        $builder->select('*');
        $query = $builder;

        return $query;
    }

    public function getCommittee()
    {
        $db = db_connect();
        $builder = $db->table('tb_committee');
        $builder->select('*');
        $query = $builder->get();

        return $query;
    }
}
