<?php

namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
    protected $table         = 'user';
    protected $primaryKey    = 'id';
    protected $allowedFields = ['name', 'email', 'image', 'password', 'role_id', 'workingunit_name', 'is_active', 'creator_id', 'modifier_id', 'date_created', 'date_modified', 'wu_name'];
    protected $beforeInsert  = ['beforeInsert'];
    protected $beforeUpdate  = ['beforeUpdate'];

    protected function beforeInsert(array $data)
    {
        $data = $this->passwordHash($data);

        return $data;
    }

    protected function beforeUpdate(array $data)
    {
        $data = $this->passwordHash($data);

        return $data;
    }

    protected function passwordHash(array $data)
    {
        if (isset($data['data']['password'])) {
            $data['data']['password'] = password_hash($data['data']['password'], PASSWORD_DEFAULT);
        }

        return $data;
    }

    public function searchUser()
    {
        $request = \Config\Services::request();
        $db = db_connect();
        $pencarian = $request->getVar('pencarian');
        $builder = $db->table('user')->select('*');
        $builder->join('user_role', 'user_role.id = user.role_id');
        $builder->join('user_status', 'user_status.id = user.is_active');
        $builder->like('name', $pencarian);
        $builder->orLike('email', $pencarian);
        $builder->orLike('wu_name', $pencarian);
        $builder->orLike('role', $pencarian);
        $query = $builder->get()->getResultArray();

        return $query;
    }

    public function getUser()
    {
        $db = db_connect();
        $builder = $db->table('user');
        $builder->select('user.id, name, email, workingunit_name, image, status, role, role_id, user.date_created');
        $builder->join('user_role', 'user_role.id = user.role_id', 'left');
        $builder->join('user_status', 'user_status.id = user.is_active', 'left');
        $builder->where('email', ['email' => session()->get('email')]);
        $query = $builder->get();

        return $query;
    }

    public function getUserRole()
    {
        $db = db_connect();
        $builder = $db->table('user');
        $builder->select('user.id, name, email, status, role, workingunit_name');
        $builder->join('user_role', 'user_role.id = user.role_id', 'left');
        $builder->join('user_status', 'user_status.id = user.is_active', 'left');
        $query = $builder->get();

        return $query;
    }

    public function getUserStatus($id)
    {
        $db = db_connect();
        $builder = $db->table('user');
        $builder->select('user.id, name, email, workingunit_name, image, status, role, user.date_created');
        $builder->join('user_role', 'user_role.id = user.role_id', 'left');
        $builder->join('user_status', 'user_status.id = user.is_active', 'left');
        $builder->where('user.id', $id);
        $query = $builder->get();

        return $query;
    }
}
