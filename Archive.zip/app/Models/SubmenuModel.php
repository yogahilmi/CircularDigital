<?php

namespace App\Models;

use CodeIgniter\Model;

class SubmenuModel extends Model
{
    protected $table         = 'user_sub_menu';
    protected $primaryKey    = 'id';
    protected $allowedFields = ['menu_id', 'title', 'url', 'icon', 'sub_menu_desc', 'is_active', 'creator_id', 'modifier_id', 'date_created', 'date_modified'];
    protected $beforeInsert  = ['beforeInsert'];
    protected $beforeUpdate  = ['beforeUpdate'];

    protected function beforeInsert(array $data)
    {
        $data = $this->passwordHash($data);

        return $data;
    }

    protected function beforeUpdate(array $data)
    {
        $data = $this->passwordHash($data);

        return $data;
    }

    protected function passwordHash(array $data)
    {
        if (isset($data['data']['password'])) {
            $data['data']['password'] = password_hash($data['data']['password'], PASSWORD_DEFAULT);
        }

        return $data;
    }

    public function getSubMenu()
    {
        $db = db_connect();
        $builder = $db->table('user_sub_menu');
        $builder->select('user_sub_menu.id, title, url, icon, sub_menu_desc, status, menu');
        $builder->join('user_menu', 'user_menu.id = user_sub_menu.menu_id', 'left');
        $builder->join('user_status', 'user_status.id = user_sub_menu.is_active', 'left');
        $query = $builder->get();

        return $query;
    }

    public function getDetailSubmenu($id)
    {
        $db = db_connect();
        $builder = $db->table('user_sub_menu');
        $builder->select('user_sub_menu.id, title, url, icon, sub_menu_desc, status, menu');
        $builder->join('user_menu', 'user_menu.id = user_sub_menu.menu_id', 'left');
        $builder->join('user_status', 'user_status.id = user_sub_menu.is_active', 'left');
        $builder->where('user_sub_menu.id', $id);
        $query = $builder->get();

        return $query;
    }

    public function getData()
    {
        $db = db_connect();
        $builder = $db->table('user_sub_menu');
        $builder->select('*', 'user_menu' . 'menu');
        $query = $builder->get()->getResultArray();

        return $query;
    }
}
