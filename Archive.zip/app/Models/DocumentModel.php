<?php

namespace App\Models;

use CodeIgniter\Model;

class DocumentModel extends Model
{
    public function getPemindahan()
    {
        $db = db_connect();
        $builder = $db->table('document_feeding');
        $builder->select('document_feeding.id, feeding_desc, feeding_date, wu_name, working_unit_id, document_feeding.is_active,
                          document_feeding.creator_id, document_feeding.modifier_id, document_feeding.date_modified, feeding_number');
        $builder->join('working_unit', 'working_unit.wu_id = document_feeding.working_unit_id', 'left');
        $builder->join('document_feeding_status', 'document_feeding_status.id = document_feeding.is_active', 'left');
        $query = $builder;

        return $query;
    }

    public function getClassification()
    {
        $db = db_connect();
        $builder = $db->table('document_classification');
        $builder->select('*');

        return $builder;
    }

    public function getClassificationCode($code)
    {
        $db = db_connect();
        $builder = $db->table('document_reference')
            ->select('dr_code')
            ->groupBy('dr_code')
            ->where('classification_id', $code);
        $query = $builder;
        return $query;
    }

    public function getClassificationName($name)
    {
        $db = db_connect();
        $builder = $db->table('document_reference')
            ->select('dr_name')
            ->where('dr_code', $name);
        $query = $builder;
        return $query;
    }

    public function getClassificationSchedule($total)
    {
        $db = db_connect();
        $builder = $db->table('document_reference')
            ->select('total_retention')
            ->where('dr_name', $total);
        $query = $builder;
        return $query;
    }

    public function getListPemindahan()
    {
        $db = db_connect();
        $builder = $db->table('document_feeding');
        $builder->select('document_feeding.id, feeding_desc, feeding_date, wu_name, working_unit_id, document_feeding.is_active,
                          document_feeding.creator_id, document_feeding.modifier_id, document_feeding.date_modified, status, feeding_number');
        $builder->join('working_unit', 'working_unit.wu_id = document_feeding.working_unit_id', 'left');
        $builder->join('document_feeding_status', 'document_feeding_status.id = document_feeding.is_active', 'left');
        $builder->where('document_feeding.is_active <= 8');
        $builder->orderBy('feeding_date', 'DESC');
        $query = $builder;

        return $query;
    }

    public function getPemindahanId($id)
    {
        $db = db_connect();
        $builder = $db->table('document_feeding, document_reference');
        $builder->select('document_feeding.id, document_feeding.is_active, feeding_desc, feeding_date, wu_name, working_unit_id, rc_number, total_retention, feeding_number,
                          document_feeding.creator_id, document_feeding.modifier_id, document_feeding.date_modified, status, recordcenter_id, rc_name, feeding_number, note, date_expired');
        $builder->join('working_unit', 'working_unit.wu_id = document_feeding.working_unit_id', 'left');
        $builder->join('document_feeding_status', 'document_feeding_status.id = document_feeding.is_active', 'left');
        $builder->join('record_center', 'record_center.id = document_feeding.recordcenter_id', 'left');
        $builder->where('document_feeding.id', $id);
        $query = $builder->get();

        return $query;
    }

    public function getPemindahanLokasi()
    {
        $db = db_connect();
        $builder = $db->table('document_feeding');
        $builder->select('document_feeding.id, feeding_desc, feeding_date, wu_name, working_unit_id, document_feeding.is_active,
                          document_feeding.creator_id, document_feeding.modifier_id, document_feeding.date_modified, status, feeding_number');
        $builder->join('working_unit', 'working_unit.wu_id = document_feeding.working_unit_id', 'left');
        $builder->join('document_feeding_status', 'document_feeding_status.id = document_feeding.is_active', 'left');
        $builder->where('document_feeding.is_active = 6');
        $query = $builder;

        return $query;
    }

    public function getApprovalCorsec()
    {
        $db = db_connect();
        $builder = $db->table('document_feeding');
        $builder->select('document_feeding.id, feeding_desc, feeding_date, wu_name, working_unit_id, document_feeding.is_active,
                          document_feeding.creator_id, document_feeding.modifier_id, document_feeding.date_modified, status, feeding_number');
        $builder->join('working_unit', 'working_unit.wu_id = document_feeding.working_unit_id', 'left');
        $builder->join('document_feeding_status', 'document_feeding_status.id = document_feeding.is_active', 'left');
        $builder->groupStart()
            ->where('document_feeding.is_active = 4')
            ->orGroupStart()
            ->where('document_feeding.is_active = 5')
            ->groupEnd()
            ->groupEnd();
        $query = $builder;

        return $query;
    }

    public function getApprovalCorsec2()
    {
        $db = db_connect();
        $builder = $db->table('document_feeding');
        $builder->select('document_feeding.id, feeding_desc, feeding_date, wu_name, working_unit_id, document_feeding.is_active,
                          document_feeding.creator_id, document_feeding.modifier_id, document_feeding.date_modified, status, feeding_number');
        $builder->join('working_unit', 'working_unit.wu_id = document_feeding.working_unit_id', 'left');
        $builder->join('document_feeding_status', 'document_feeding_status.id = document_feeding.is_active', 'left');
        $query = $builder;

        return $query;
    }

    public function getVerifyCorsec()
    {
        $db = db_connect();
        $builder = $db->table('document_feeding');
        $builder->select('document_feeding.id, feeding_desc, feeding_date, wu_name, working_unit_id, document_feeding.is_active,
                          document_feeding.creator_id, document_feeding.modifier_id, document_feeding.date_modified, status, feeding_number');
        $builder->join('working_unit', 'working_unit.wu_id = document_feeding.working_unit_id', 'left');
        $builder->join('document_feeding_status', 'document_feeding_status.id = document_feeding.is_active', 'left');
        $builder->where('document_feeding.is_active = 7');
        $query = $builder;

        return $query;
    }

    public function getdpdi($id)
    {
        $db = db_connect();
        $builder = $db->table('document_feeding, document_detail, record_center');
        $builder->select('document_feeding.id, feeding_desc, document_feeding.feeding_date, wu_name, document_feeding.working_unit_id, rc_number,
                          document_feeding.creator_id, document_feeding.modifier_id, document_feeding.date_modified, status, document_desc');
        $builder->join('working_unit', 'working_unit.wu_id = document_feeding.working_unit_id', 'left');
        $builder->join('document_feeding_status', 'document_feeding_status.id = document_feeding.is_active', 'left');
        $builder->join('document_classification', 'document_classification.id = document_detail.classification_id', 'left');
        $builder->join('document_reference', 'document_reference.id = document_detail.retention_id', 'left');
        $builder->where('document_feeding.id', $id);
        $query = $builder->get();

        return $query;
    }

    public function getPersetujuan()
    {
        $db = db_connect();
        $builder = $db->table('document_feeding');
        $builder->select('document_feeding.id, feeding_desc, feeding_date, wu_name, working_unit_id, document_feeding.is_active,
                          document_feeding.creator_id, document_feeding.modifier_id, document_feeding.date_modified, status, feeding_number');
        $builder->join('working_unit', 'working_unit.wu_id = document_feeding.working_unit_id', 'left');
        $builder->join('document_feeding_status', 'document_feeding_status.id = document_feeding.is_active', 'left');
        $builder->where('document_feeding.is_active = 3');
        $query = $builder;

        return $query;
    }

    public function documentDetail()
    {
        $db = db_connect();
        $builder = $db->table('document_detail');
        $builder->select('*');
        $builder->join('working_unit', 'working_unit.wu_id = document_feeding.working_unit_id', 'left');
        $builder->join('document_feeding_status', 'document_feeding_status.id = document_feeding.is_active', 'left');
        $builder->join('document_classification', 'document_classification.id = document_detail.classification_id', 'left');
        $builder->join('document_reference', 'document_reference.id = document_detail.retention_id', 'left');
        $query = $builder->get();

        return $query;
    }

    public function updateDocument($id)
    {
        $db = db_connect();
        $builder = $db->table('document_detail');
        $builder->select('*');
        $builder->join('document_feeding', 'document_feeding.id = document_detail.feeding_id', 'left');
        $builder->where('doc_id', $id);
        $query = $builder->get();

        return $query;
    }

    public function updatePemindahan($id)
    {
        $db = db_connect();
        $builder = $db->table('document_feeding');
        $builder->select('*');
        $builder->where('id', $id);
        $query = $builder;

        return $query;
    }

    public function deletePemindahan()
    {
        $db = db_connect();
        $builder = $db->table('document_feeding');
        $builder->select('*');
        $query = $builder;

        return $query;
    }

    // Untuk GET Dokumen dalam DPDI
    public function getDocumentDetail($id)
    {
        $db = db_connect();
        $builder = $db->table('document_detail');
        $builder->select('*');
        $builder->where('feeding_id', $id);
        $query = $builder;

        return $query;
    }

    // Untuk GET Dokumen berdasarkan ID
    public function getDocumentById($id)
    {
        $db = db_connect();
        $builder = $db->table('document_detail');
        $builder->select('*');
        $builder->where('doc_id', $id);
        $query = $builder;

        return $query;
    }

    // Untuk GET DPDI
    public function insertDocument()
    {
        $db = db_connect();
        $builder = $db->table('document_detail');
        $builder->select('*');
        $query = $builder;

        return $query;
    }

    // Untuk DELETE DPDI
    public function deleteDpdi()
    {
        $db = db_connect();
        $builder = $db->table('document_detail');
        $builder->select('*');
        $query = $builder;

        return $query;
    }

    public function getRecordCenter()
    {
        $db = db_connect();
        $builder = $db->table('record_center');
        $builder->select('*');
        $query = $builder->get();

        return $query;
    }

    public function searchReference()
    {
        $request = \Config\Services::request();
        $db = db_connect();
        $pencarian = $request->getVar('pencarian');
        $queryReference = $db->table('document_reference')
            ->select('*')
            ->join('document_classification', 'document_classification.id = document_reference.classification_id', 'left')
            ->like('dr_name', $pencarian)
            ->orLike('dr_code', $pencarian)
            ->orLike('classification_name', $pencarian);
        $query = $queryReference->get()->getResultArray();

        return $query;
    }

    public function searchDetailDpdi($id)
    {
        $request = \Config\Services::request();
        $db = db_connect();
        $pencarian = $request->getVar('pencarian');
        $builder = $db->table('document_detail')->select('*')
            ->like('document_desc', $pencarian)
            ->where('feeding_id', $id);
        $query = $builder;

        return $query;
    }

    public function getMusnah()
    {
        $db = db_connect();
        $builder = $db->table('working_unit');
        $builder->select('wu_id, wu_name, rc_number');
        $builder->selectCount('doc_id');
        $builder->join('document_detail', 'document_detail.working_unit_id = working_unit.wu_id');
        $builder->groupStart()
            ->where('documentstatus_id = 3')
            ->orGroupStart()
            ->where('documentstatus_id = 4')
            ->groupEnd()
            ->groupEnd()
            ->where('destroy_schedule <=', date('Y'));
        $builder->groupBy('working_unit.wu_id, document_detail.working_unit_id');
        $query = $builder;

        return $query;
    }

    public function searchMusnah()
    {
        $request = \Config\Services::request();
        $pencarian = $request->getVar('pencarian');
        $db = db_connect();
        $builder = $db->table('working_unit');
        $builder->select('wu_id, wu_name, rc_number');
        $builder->selectCount('doc_id');
        $builder->join('document_detail', 'document_detail.working_unit_id = working_unit.wu_id');
        $builder->groupStart()
            ->where('documentstatus_id = 3')
            ->orGroupStart()
            ->where('documentstatus_id = 4')
            ->groupEnd()
            ->groupEnd()
            ->where('destroy_schedule <=', date('Y'))
            ->like('wu_name', $pencarian);
        $builder->groupBy('working_unit.wu_id, document_detail.working_unit_id');
        $query = $builder;

        return $query;
    }

    public function getDocumentMusnah($id)
    {
        $db = db_connect();
        $builder = $db->table('working_unit');
        $builder->select('wu_id, wu_name, rc_number, destroy_schedule, doc_id, retention_name, document_desc, begin_period, end_period,
                        total_folder, total_map, total_bundle, total_other, destroy_ddum, document_ddum_status.status');
        $builder->join('document_detail', 'document_detail.working_unit_id = working_unit.wu_id', 'left');
        $builder->join('document_ddum_status', 'document_ddum_status.id = document_detail.destroy_ddum', 'left');
        $builder->groupStart()
            ->where('documentstatus_id = 3')
            ->orGroupStart()
            ->where('documentstatus_id = 4')
            ->groupEnd()
            ->groupEnd()
            ->where('destroy_schedule <=', date('Y'))
            ->where('wu_id', $id);
        $query = $builder;

        return $query;
    }

    public function searchDetailDdum($id)
    {
        $request = \Config\Services::request();
        $db = db_connect();
        $pencarian = $request->getVar('pencarian');
        $builder = $db->table('document_detail')->select('*');
        $builder->join('document_ddum_status', 'document_ddum_status.id = document_detail.destroy_ddum', 'left');
        $builder->groupStart()
            ->where('documentstatus_id = 3')
            ->orGroupStart()
            ->where('documentstatus_id = 4')
            ->groupEnd()
            ->groupEnd()
            ->where('working_unit_id', $id);
        $builder->like('document_desc', $pencarian)
            ->orLike('begin_period', $pencarian)
            ->orLike('end_period', $pencarian);
        $query = $builder;

        return $query;
    }

    public function getMusnahById($id)
    {
        $db = db_connect();
        $builder = $db->table('working_unit');
        $builder->select('wu_id, wu_name, rc_number, rc_name, destroy_number, document_destroy.id');
        $builder->selectCount('doc_id');
        $builder->join('document_detail', 'document_detail.working_unit_id = working_unit.wu_id');
        $builder->join('record_center', 'record_center.id = document_detail.recordcenter_id');
        $builder->join('document_destroy', 'document_destroy.working_unit_id = working_unit.wu_id', 'left');
        $builder->groupStart()
            ->where('documentstatus_id = 3')
            ->orGroupStart()
            ->where('documentstatus_id = 4')
            ->groupEnd()
            ->groupEnd()
            ->where('wu_id', $id);
        $builder->groupBy('working_unit.wu_id, document_detail.working_unit_id, record_center.rc_name, document_destroy.destroy_number, document_destroy.id');
        $query = $builder;

        return $query;
    }

    public function getPenerimaan()
    {
        $db = db_connect();
        $builder = $db->table('document_feeding');
        $builder->select('document_feeding.id, feeding_desc, feeding_date, wu_name, working_unit_id, document_feeding.is_active,
                          document_feeding.creator_id, document_feeding.modifier_id, document_feeding.date_modified, status, feeding_number');
        $builder->join('working_unit', 'working_unit.wu_id = document_feeding.working_unit_id', 'left');
        $builder->join('document_feeding_status', 'document_feeding_status.id = document_feeding.is_active', 'left');
        $builder->groupStart()
            ->where('document_feeding.is_active = 9')
            ->orGroupStart()
            ->where('document_feeding.is_active = 10')
            ->groupEnd()
            ->groupEnd();
        $query = $builder;

        return $query;
    }

    public function prosesMusnah($id)
    {
        $db = db_connect();
        $builder = $db->table('document_detail');
        $builder->select('*');
        $builder->join('working_unit', 'working_unit.wu_id = document_detail.working_unit_id', 'left');
        $builder->groupStart()
            ->where('documentstatus_id = 3')
            ->orGroupStart()
            ->where('documentstatus_id = 4')
            ->groupEnd()
            ->groupEnd()
            ->where('destroy_ddum = 1')
            ->where('working_unit_id', $id);
        $query = $builder;

        return $query;
    }

    public function getBoxNumberMax($prefix)
    {
        $db = db_connect();
        $builder = $db->table('document_detail');
        $builder->select('box_number');
        $builder->join('document_feeding', 'document_feeding.id = document_detail.feeding_id');
        $builder->like('box_number', $prefix, 'after');
        // $builder->where('id', $id);
        $builder->orderBy('box_number', 'desc');
        $builder->limit(1);
        $query = $builder;

        return $query;
    }

    public function getDocumentIdMax($prefixId)
    {
        $db = db_connect();
        $builder = $db->table('document_detail');
        $builder->select('doc_id');
        $builder->like('doc_id', $prefixId, 'after');
        $builder->orderBy('doc_id', 'desc');
        $builder->limit(1);
        $query = $builder;

        return $query;
    }

    public function getFeedingNumberMax($prefix)
    {
        $db = db_connect();
        $builder = $db->table('document_feeding');
        $builder->select('feeding_number');
        // $builder->join('document_feeding', 'document_feeding.id = document_detail.feeding_id');
        $builder->like('feeding_number', $prefix, 'after');
        // $builder->where('id', $id);
        $builder->orderBy('feeding_number', 'desc');
        $builder->limit(1);
        $query = $builder;

        return $query;
    }

    public function getDestroyNumberMax($prefix)
    {
        $db = db_connect();
        $builder = $db->table('document_destroy');
        $builder->select('destroy_number');
        $builder->like('destroy_number', $prefix, 'after');
        $builder->orderBy('destroy_number', 'desc');
        $builder->limit(1);
        $query = $builder;

        return $query;
    }

    public function getDDMNumberMax($prefix)
    {
        $db = db_connect();
        $builder = $db->table('document_destroy');
        $builder->select('destroyed_number');
        $builder->like('destroyed_number', $prefix, 'after');
        $builder->orderBy('destroyed_number', 'desc');
        $builder->limit(1);
        $query = $builder;

        return $query;
    }

    public function searchDDM()
    {
        $request = \Config\Services::request();
        $pencarian = $request->getVar('pencarian');
        $db = db_connect();
        $builder = $db->table('working_unit');
        $builder->select('wu_id, wu_name, rc_number, destroy_period, destroy_id');
        $builder->selectCount('doc_id');
        $builder->join('document_detail', 'document_detail.working_unit_id = working_unit.wu_id');
        $builder->groupStart()
            ->where('documentstatus_id = 2')
            ->groupEnd();
        $builder->like('wu_name', $pencarian);
        $builder->groupBy('working_unit.wu_id, document_detail.working_unit_id, document_detail.destroy_period, document_detail.destroy_id');
        $builder->orderBy('destroy_period', 'DESC');
        $query = $builder;

        return $query;
    }

    public function getDestroyed()
    {
        $db = db_connect();
        $builder = $db->table('working_unit');
        $builder->select('wu_id, wu_name, rc_number, destroy_period, destroy_id');
        $builder->selectCount('doc_id');
        $builder->join('document_detail', 'document_detail.working_unit_id = working_unit.wu_id');
        $builder->groupStart()
            ->where('documentstatus_id = 2')
            ->groupEnd();
        $builder->groupBy('working_unit.wu_id, document_detail.working_unit_id, document_detail.destroy_period, document_detail.destroy_id');
        $builder->orderBy('destroy_period', 'DESC');
        $query = $builder;

        return $query;
    }

    public function getDestroyedById($id)
    {
        $db = db_connect();
        $builder = $db->table('working_unit');
        $builder->select('wu_id, wu_name, rc_number, rc_name, destroyed_number, destroy_period');
        $builder->selectCount('doc_id');
        $builder->join('document_detail', 'document_detail.working_unit_id = working_unit.wu_id');
        $builder->join('record_center', 'record_center.id = document_detail.recordcenter_id');
        $builder->join('document_destroy', 'document_destroy.working_unit_id = working_unit.wu_id', 'left');
        $builder->groupStart()
            ->where('documentstatus_id = 2')
            ->groupEnd()
            ->where('destroy_id', $id);
        $builder->groupBy('working_unit.wu_id, document_detail.working_unit_id, record_center.rc_name, document_destroy.destroyed_number, document_detail.destroy_period');
        $query = $builder;

        return $query;
    }

    public function getDestroyedData($id)
    {
        $db = db_connect();
        $builder = $db->table('working_unit');
        $builder->select('wu_id, wu_name, rc_number, destroy_schedule, doc_id, retention_name, document_desc, begin_period, end_period, schedule_period,
                        total_folder, total_map, total_bundle, total_other, destroy_ddum, document_ddum_status.status');
        $builder->join('document_detail', 'document_detail.working_unit_id = working_unit.wu_id', 'left');
        $builder->join('document_ddum_status', 'document_ddum_status.id = document_detail.destroy_ddum', 'left');
        $builder->groupStart()
            ->where('documentstatus_id = 2')
            ->groupEnd()
            ->where('destroy_id', $id);
        $query = $builder;

        return $query;
    }

    public function searchDestroyedData($id)
    {
        $request = \Config\Services::request();
        $pencarian = $request->getVar('pencarian');
        $db = db_connect();
        $builder = $db->table('working_unit');
        $builder->select('wu_id, wu_name, rc_number, destroy_schedule, doc_id, retention_name, document_desc, begin_period, end_period, schedule_period,
                        total_folder, total_map, total_bundle, total_other, destroy_ddum, document_ddum_status.status');
        $builder->join('document_detail', 'document_detail.working_unit_id = working_unit.wu_id', 'left');
        $builder->join('document_ddum_status', 'document_ddum_status.id = document_detail.destroy_ddum', 'left');
        $builder->groupStart()
            ->where('documentstatus_id = 2')
            ->groupEnd()
            ->where('destroy_id', $id);
        $builder->like('document_desc', $pencarian);
        $query = $builder;

        return $query;
    }
}
