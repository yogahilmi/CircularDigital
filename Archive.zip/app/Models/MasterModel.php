<?php

namespace App\Models;

use CodeIgniter\Model;

class MasterModel extends Model
{
    protected $table         = 'tb_committee';
    protected $primaryKey    = 'id';
    protected $allowedFields = ['committee', 'desc', 'creator_id', 'modifier_id', 'date_created', 'date_modified'];

    public function getWorkingUnit()
    {
        $db = db_connect();
        $builder = $db->table('working_unit');
        $builder->select('working_unit.wu_id, wu_name, parent_id, directorate_id, rc_number, address, city, is_active, status');
        $builder->join('user_status', 'user_status.id = working_unit.is_active', 'left');
        $query = $builder->get();

        return $query;
    }
}
