<?php

namespace App\Models;

use CodeIgniter\Model;

class MeetingModel extends Model
{
    protected $table         = 'tb_meeting';
    protected $primaryKey    = 'id';

    public function getBodMeeting()
    {
        $db = db_connect();
        $builder = $db->table('tb_meeting');
        $builder->select('tb_meeting.id, number, agenda, year, category_id, meeting_date, attachment');
        $builder->join('tb_category', 'tb_category.id = tb_meeting.category_id');
        $builder->where('category_id = 1');
        // $builder->limit(10);
        $query = $builder;

        return $query;
    }

    public function getBocMeeting()
    {
        $db = db_connect();
        $builder = $db->table('tb_meeting');
        $builder->select('tb_meeting.id, number, agenda, category_id, meeting_date, attachment');
        $builder->join('tb_category', 'tb_category.id = tb_meeting.category_id');
        $builder->where('category_id = 2');
        $query = $builder;

        return $query;
    }

    public function getDetail($id)
    {
        $db = db_connect();
        $builder = $db->table('tb_meeting');
        $builder->select('tb_meeting.id, number, agenda, category, category_id, meeting_date, attachment');
        $builder->join('tb_category', 'tb_category.id = tb_meeting.category_id');
        $builder->where('tb_meeting.id', $id);
        $query = $builder->get();

        return $query;
    }

    public function getMeeting()
    {
        $db = db_connect();
        $builder = $db->table('tb_meeting');
        $builder->select('*');
        $query = $builder;

        return $query;
    }

    public function getYearBod()
    {
        $db = db_connect();
        $builder = $db->table('tb_meeting');
        $builder->select('year')->distinct();
        $builder->where('category_id = 1');
        $builder->orderBy('year', 'DESC');
        $query = $builder;

        return $query;
    }

    public function getYearBoc()
    {
        $db = db_connect();
        $builder = $db->table('tb_meeting');
        $builder->select('year')->distinct();
        $builder->where('category_id = 2');
        $builder->orderBy('year', 'DESC');
        $query = $builder;

        return $query;
    }
}
