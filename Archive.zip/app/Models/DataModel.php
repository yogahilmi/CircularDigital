<?php

namespace App\Models;

use CodeIgniter\Model;

class DataModel extends Model
{
    // Untuk Ambil Semua Dokumen
    public function getDocumentDetail()
    {
        $db = db_connect();
        $builder = $db->table('document_detail');
        $builder->select('*');
        $builder->join('document_status', 'document_status.id = document_detail.documentstatus_id', 'left');
        $builder->limit(20);
        $query = $builder;

        return $query;
    }

    // Untuk Detail dari Dokumen
    public function getDetail($id)
    {
        $db = db_connect();
        $builder = $db->table('document_detail');
        $builder->select('retention_name, document_desc, begin_period, end_period, start_retention, destroy_schedule, total_map, total_folder, total_bundle, total_other,
                        box_number, location_id, document_detail.feeding_date, rc_name, document_feeding.id, wu_name, status_name');
        $builder->join('record_center', 'record_center.id = document_detail.recordcenter_id', 'left');
        $builder->join('document_feeding', 'document_feeding.id = document_detail.feeding_id', 'left');
        $builder->join('working_unit', 'working_unit.wu_id = document_detail.working_unit_id', 'left');
        $builder->join('document_status', 'document_status.id = document_detail.documentstatus_id', 'left');
        $builder->where('doc_id', $id);
        $query = $builder;

        return $query;
    }

    public function searchDocumentDetail()
    {
        $request = \Config\Services::request();
        $db = db_connect();
        $pencarian = $request->getVar('pencarian');
        $queryReference = $db->table('document_detail')
            ->select('*')
            ->join('working_unit', 'working_unit.wu_id = document_detail.working_unit_id')
            ->like('document_desc', $pencarian)
            ->orLike('retention_name', $pencarian)
            ->orLike('wu_name', $pencarian);
        $query = $queryReference->get()->getResultArray();

        return $query;
    }

    public function searchDocumentByRetention()
    {
        $request = \Config\Services::request();
        $db = db_connect();
        $retensi = $request->getVar('retensi');
        $queryReference = $db->table('document_detail')
            ->select('*')
            ->like('start_retention', $retensi);
        $query = $queryReference->get()->getResultArray();

        return $query;
    }

    public function searchDocumentByDestroy()
    {
        $request = \Config\Services::request();
        $db = db_connect();
        $destroy = $request->getVar('destroy');
        $queryReference = $db->table('document_detail')
            ->select('*')
            ->like('destroy_schedule', $destroy);
        $query = $queryReference->get()->getResultArray();

        return $query;
    }
}
