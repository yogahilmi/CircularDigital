<?php

namespace App\Models;

use CodeIgniter\Model;

class MenuModel extends Model
{
    protected $table         = 'user_menu';
    protected $primaryKey    = 'id';
    protected $allowedFields = ['menu', 'position', 'creator_id', 'modifier_id', 'date_created', 'date_modified'];
    protected $beforeInsert  = ['beforeInsert'];
    protected $beforeUpdate  = ['beforeUpdate'];

    protected function beforeInsert(array $data)
    {
        $data = $this->passwordHash($data);

        return $data;
    }

    protected function beforeUpdate(array $data)
    {
        $data = $this->passwordHash($data);

        return $data;
    }

    protected function passwordHash(array $data)
    {
        if (isset($data['data']['password'])) {
            $data['data']['password'] = password_hash($data['data']['password'], PASSWORD_DEFAULT);
        }

        return $data;
    }

    public function getAllMenu()
    {
        $db = db_connect();
        $builder = $db->table('user_menu');
        $builder->select('menu');
        $query = $builder->get()->getResultArray();

        return $query;
    }

    public function getMenu()
    {
        $db = db_connect();
        $builder = $db->table('user_sub_menu');
        $builder->select('*');
        $builder->join('user_menu', 'user_menu.id = user_sub_menu.menu_id', 'left');
        $query = $builder->get()->getResultArray();

        return $query;
    }
}
