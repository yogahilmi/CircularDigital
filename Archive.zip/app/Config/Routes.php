<?php

namespace Config;

// Create a new instance of our RouteCollection class.
$routes = Services::routes();

// Load the system's routing file first, so that the app and ENVIRONMENT
// can override as needed.
if (file_exists(SYSTEMPATH . 'Config/Routes.php')) {
	require SYSTEMPATH . 'Config/Routes.php';
}

/**
 * --------------------------------------------------------------------
 * Router Setup
 * --------------------------------------------------------------------
 */
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Auth');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
$routes->setAutoRoute(true);

/**
 * --------------------------------------------------------------------
 * Route Definitions
 * --------------------------------------------------------------------
 */

// We get a performance increase by specifying the default
// route since we don't have to scan directories.
$routes->get('/', 'Auth::index', ['filter' => 'noauth']);

// $routes->group('', ['filter' => 'login'], function ($routes) {
// 	$routes->get('home', 'Home::home');
// });

$routes->get('logout', 'Auth::logout');
$routes->match(['get', 'post'], 'login', 'Auth::login', ['filter' => 'noauth']);
$routes->match(['get', 'post'], 'registration', 'Auth::registration', ['filter' => 'noauth']);
$routes->get('user', 'User::index', ['filter' => 'auth']);
$routes->get('admin', 'Admin::index', ['filter' => 'auth']);
$routes->get('menu', 'Menu::index', ['filter' => 'auth']);
$routes->get('master', 'Master::index', ['filter' => 'auth']);
$routes->get('data', 'Data::arsip', ['filter' => 'auth']);
$routes->get('dashboard', 'Dashboard::index', ['filter' => 'auth']);
$routes->get('dokumen', 'Dokumen::pemindahan', ['filter' => 'auth']);
$routes->get('dokumen/$1', 'Dokumen::$1', ['filter' => 'auth']);
// $routes->match(['get', 'post'], 'index', 'User::index', ['filter' => 'auth']);

/**
 * --------------------------------------------------------------------
 * Additional Routing
 * --------------------------------------------------------------------
 *
 * There will often be times that you need additional routing and you
 * need to it be able to override any defaults in this file. Environment
 * based routes is one such time. require() additional route files here
 * to make that happen.
 *
 * You will have access to the $routes object within that file without
 * needing to reload it.
 */
if (file_exists(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php')) {
	require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}
