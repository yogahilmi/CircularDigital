<?php

namespace App\Controllers;

class Admin extends BaseController
{
    public function index()
    {
        $role_id = session()->get('role_id');
        $menu =  $this->request->uri->getSegment(1);

        // QUERY TABLE USER_MENU
        $queryMenu = $this->menuModel->where(['menu' => $menu])->get()->getRowArray();
        $menu_id = $queryMenu['id'];

        // QUERY TABLE USER_ACCESS_MENU
        $userAccess = $this->accessModel->where(['role_id' => $role_id, 'menu_id' => $menu_id])->get()->getRowArray();

        if ($userAccess == null) {
            return redirect()->to(site_url('auth/error'));
        }

        $data = $this->userModel->getUser()->getRowArray();
        $data['title'] = 'Dashboard';

        echo view('templates/header', $data);
        echo view('templates/sidebar', $data);
        echo view('templates/topbar', $data);
        echo view('dashboard/admin/index', $data);
        echo view('templates/footer');
    }

    public function dashboard()
    {
        $data = $this->userModel->getUser()->getRowArray();
        $data['title'] = 'Dashboard';

        echo view('templates/header', $data);
        echo view('templates/sidebar', $data);
        echo view('templates/topbar', $data);
        echo view('dashboard/admin/index', $data);
        echo view('templates/footer');
    }

    public function role()
    {
        $data = $this->userModel->getUser()->getRowArray();
        $data['role'] = $this->roleModel->get()->getResultArray();
        // $data['role'] = $this->roleModel->paginate(2);
        // $data['pager'] = $this->roleModel->pager;
        $data['title'] = 'Role Management';
        // var_dump($data);
        // die;

        if ($this->request->getMethod() == 'post') {
            $rules = [
                'role' => 'required|trim|max_length[24]'
            ];

            if (!$this->validate($rules)) {
                $data['validation'] = $this->validator;
            } else {
                $roleData = [
                    'role' => $this->request->getVar('role'),
                    'creator_id'   => $data['id'],
                    'date_created' => date('Y-m-d H:i:s')
                ];
                $this->roleModel->save($roleData);
                $session = session();
                $session->setFlashdata('success', 'New role added!');
                return redirect()->to('role');
            }
        }

        echo view('templates/header', $data);
        echo view('templates/sidebar', $data);
        echo view('templates/topbar', $data);
        echo view('admin/role', $data);
        echo view('templates/footer');
    }

    public function updaterole($id)
    {
        $data = $this->userModel->getUser()->getRowArray();
        $data['role'] = $this->roleModel->where(['id' => $id])->get()->getRowArray();
        $data['title'] = 'User Role';

        if ($this->request->getMethod() == 'post') {
            $rules = [
                'role'      => 'required|trim|max_length[24]'
            ];

            if (!$this->validate($rules)) {
                $data['validation'] = $this->validator;
            } else {
                $role = [
                    'role' => $this->request->getVar('role'),
                    'modifier_id'   => $data['id'],
                    'date_modified' => date('Y-m-d H:i:s')
                ];

                $this->roleModel->set($role)->where(['id' => $id])->update();
                session()->setFlashdata('success', 'Role name has been changed!');
                return redirect()->to(base_url('admin/role'));
            }
        }
        echo view('templates/header', $data);
        echo view('templates/sidebar', $data);
        echo view('templates/topbar', $data);
        echo view('admin/updaterole', $data);
        echo view('templates/footer');
    }


    public function deleterole($id)
    {
        $this->roleModel->delete($id);
        session()->setFlashdata('success', 'Delete role success!');
        return redirect()->to(base_url('admin/role'));
    }

    public function roleAccess($role_id)
    {
        $data = $this->userModel->getUser()->getRowArray();
        $data['role'] = $this->roleModel->where(['id' => $role_id])->get()->getRowArray();
        $data['menu'] = $this->menuModel->get()->getResultArray();
        $data['title'] = 'User Role';


        echo view('templates/header', $data);
        echo view('templates/sidebar', $data);
        echo view('templates/topbar', $data);
        echo view('admin/role-access', $data);
        echo view('templates/footer');
    }

    public function changeAccess()
    {
        $menu_id = $this->request->getVar('menuId');
        $role_id = $this->request->getVar('roleId');

        $data = [
            'role_id' => $role_id,
            'menu_id' => $menu_id
        ];

        $db      = \Config\Database::connect();
        $builder = $db->table('user_access_menu');
        $userAccess = $builder->where($data)->get();

        if ($userAccess->getRowArray() < 1) {
            $builder->insert($data);
        } else {
            $builder->delete($data);
        }
        session()->setFlashdata('success', 'Access changed!');
    }

    public function userMan()
    {
        $data = $this->userModel->getUser()->getRowArray();
        $data['user'] = $this->userModel->getUserRole()->getResultArray();
        if ($this->request->getVar('pencarian')) {
            $data['user'] = $this->userModel->searchUser();
        }
        $data['role'] = $this->roleModel->get()->getResultArray();
        $data['title'] = 'User Management';

        if ($this->request->getMethod() == 'post') {
            $rules = [
                'name'      => 'required|trim|max_length[24]',
                'email'     => 'required|trim|is_unique[user.email]',
                'role'      => 'required',
                'password1' => 'required|trim|min_length[3]|matches[password2]',
                'password2' => 'required|min_length[3]matches[password1]',
                'workingunit' => 'required'
            ];

            if (!$this->validate($rules)) {
                $data['validation'] = $this->validator;
            } else {
                $newUser = [
                    'name'      => $this->request->getVar('name'),
                    'email'     => $this->request->getVar('email'),
                    'role_id'   => $this->request->getVar('role'),
                    'workingunit_name' => $this->request->getVar('workingunit'),
                    'password'  => $this->request->getVar('password1'),
                    'image'     => 'default.png',
                    'is_active' => '1',
                    'creator_id'   => $data['id'],
                    'date_created' => date('Y-m-d H:i:s')
                ];
                $this->userModel->save($newUser);
                $session = session();
                $session->setFlashdata('success', 'New user added!');
                return redirect()->to(base_url('admin/userman'));
            }
        }
        echo view('templates/header', $data);
        echo view('templates/sidebar', $data);
        echo view('templates/topbar', $data);
        echo view('admin/usermanage', $data);
        echo view('templates/footer');
    }

    public function detailUser($id)
    {
        $data = $this->userModel->getUser()->getRowArray();
        $data['user'] = $this->userModel->getUserStatus($id)->getRowArray();
        $data['title'] = 'Detail User';

        echo view('templates/header', $data);
        echo view('templates/sidebar', $data);
        echo view('templates/topbar', $data);
        echo view('admin/userdetail', $data);
        echo view('templates/footer');
    }

    public function updateUser($id)
    {
        $data = $this->userModel->getUser()->getRowArray();
        $data['user'] = $this->userModel->where(['id' => $id])->get()->getRowArray();
        $data['role'] = $this->roleModel->get()->getResultArray();
        $data['title'] = 'Edit User';

        if ($this->request->getMethod() == 'post') {
            $rules = [
                'name'   => 'required|trim|max_length[50]',
                'email'  => 'required|trim|max_length[50]',
                'status' => 'required',
                'role' => 'required'
            ];

            if (!$this->validate($rules)) {
                $data['validation'] = $this->validator;
            } else {
                $dataUser = [
                    'name'      => $this->request->getVar('name'),
                    'email'     => $this->request->getVar('email'),
                    'role_id'   => $this->request->getVar('role'),
                    'is_active' => $this->request->getVar('status'),
                    'modifier_id'   => $data['id'],
                    'date_modified' => date('Y-m-d H:i:s')
                ];
                $this->userModel->set($dataUser)->where(['id' => $id])->update();
                session()->setFlashdata('success', 'User profile has been changed!');
                return redirect()->to(site_url('admin/userman'));
            }
        }
        echo view('templates/header', $data);
        echo view('templates/sidebar', $data);
        echo view('templates/topbar', $data);
        echo view('admin/userupdate', $data);
        echo view('templates/footer');
    }

    public function deleteUser($id)
    {
        $this->userModel->delete($id);
        session()->setFlashdata('success', 'Delete success!');
        return redirect()->to(site_url('admin/userman'));
    }
}
