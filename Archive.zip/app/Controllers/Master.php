<?php

namespace App\Controllers;

class Master extends BaseController
{
    public function committee()
    {
        $data = $this->userModel->getUser()->getRowArray();
        $data['committee'] = $this->masterModel->get()->getResultArray();
        $data['title'] = 'Daftar Komite';

        if ($this->request->getMethod() == 'post') {
            $rules = [
                'committee' => 'required|trim|is_unique[tb_committee.committee]',
                'desc'      => 'required|trim'
            ];

            if (!$this->validate($rules)) {
                $data['validation'] = $this->validator;
            } else {
                $newData = [
                    'committee'    => $this->request->getVar('committee'),
                    'desc'         => $this->request->getVar('desc'),
                    'creator_id'   => $data['id'],
                    'date_created' => date('Y-m-d H:i:s')
                ];
                $this->masterModel->save($newData);
                $session = session();
                $session->setFlashdata('success', 'Data berhasil ditambahkan!');
                return redirect()->to('committee');
            }
        }
        echo view('templates/header', $data);
        echo view('templates/sidebar', $data);
        echo view('templates/topbar', $data);
        echo view('committee/index', $data);
        echo view('templates/footer');
    }

    public function editcom($id)
    {
        $data = $this->userModel->getUser()->getRowArray();
        $data['committee'] = $this->masterModel->where(['id' => $id])->get()->getRowArray();
        $data['title'] = 'Ubah Data';

        if ($this->request->getMethod() == 'post') {
            $rules = [
                'committee' => 'required|trim',
                'desc'      => 'required|trim'
            ];

            if (!$this->validate($rules)) {
                $data['validation'] = $this->validator;
            } else {
                $updateData = [
                    'committee'    => $this->request->getVar('committee'),
                    'desc'         => $this->request->getVar('desc'),
                    'modifier_id'   => $data['id'],
                    'date_modified' => date('Y-m-d H:i:s')
                ];

                $this->masterModel->set($updateData)->where(['id' => $id])->update();
                session()->setFlashdata('success', 'Data komite telah diubah!');
                return redirect()->to(base_url('master/committee'));
            }
        }
        echo view('templates/header', $data);
        echo view('templates/sidebar', $data);
        echo view('templates/topbar', $data);
        echo view('committee/edit', $data);
        echo view('templates/footer');
    }

    public function deletecom($id)
    {
        $this->masterModel->delete($id);
        session()->setFlashdata('success', 'Data telah dihapus!');
        return redirect()->to(base_url('master/committee'));
    }
}
