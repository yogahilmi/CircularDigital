<?php

namespace App\Controllers;

class Menu extends BaseController
{
    public function index()
    {
        // HELPER START

        $role_id = session()->get('role_id');
        $menu =  $this->request->uri->getSegment(1);

        // QUERY TABLE USER_MENU
        $queryMenu = $this->menuModel->where(['menu' => $menu])->get()->getRowArray();
        $menu_id = $queryMenu['id'];

        // QUERY TABLE USER_ACCESS_MENU
        $userAccess = $this->accessModel->where(['role_id' => $role_id, 'menu_id' => $menu_id])->get()->getRowArray();

        if ($userAccess == null) {
            return redirect()->to(site_url('auth/error'));
        }

        // HELPER BELUM SIAP
        // is_logged_in();

        // END OF HELPER

        $data = $this->userModel->getUser()->getRowArray();
        $data['menu'] = $this->menuModel->get()->getResultArray();
        $data['title'] = 'Menu Management';

        if ($this->request->getMethod() == 'post') {
            $rules = [
                'menu'      => 'required|trim|max_length[24]',
                'position'  => 'required'
            ];

            if (!$this->validate($rules)) {
                $data['validation'] = $this->validator;
            } else {
                $newData = [
                    'menu'         => $this->request->getVar('menu'),
                    'position'     => $this->request->getVar('position'),
                    'creator_id'   => $data['id'],
                    'date_created' => date('Y-m-d H:i:s')
                ];
                $this->menuModel->save($newData);
                $session = session();
                $session->setFlashdata('success', 'New menu added!');
                return redirect()->to('menu');
            }
        }
        echo view('templates/header', $data);
        echo view('templates/sidebar', $data);
        echo view('templates/topbar', $data);
        echo view('menu/index', $data);
        echo view('templates/footer');
    }

    public function update($id)
    {
        $data = $this->userModel->getUser()->getRowArray();
        $data['menu'] = $this->menuModel->where(['id' => $id])->get()->getRowArray();
        $data['title'] = 'Edit Menu';

        if ($this->request->getMethod() == 'post') {
            $rules = [
                'menu'      => 'required|trim|max_length[24]',
                'position'  => 'required|trim|max_length[3]'
            ];

            if (!$this->validate($rules)) {
                $data['validation'] = $this->validator;
            } else {
                $update = [
                    'menu'     => $this->request->getVar('menu'),
                    'position' => $this->request->getVar('position'),
                    'modifier_id'   => $data['id'],
                    'date_modified' => date('Y-m-d H:i:s')
                ];
                $this->menuModel->set($update)->where(['id' => $id])->update();
                session()->setFlashdata('success', 'Menu has been changed!');
                return redirect()->to(site_url('menu'));
            }
        }
        echo view('templates/header', $data);
        echo view('templates/sidebar', $data);
        echo view('templates/topbar', $data);
        echo view('menu/update', $data);
        echo view('templates/footer');
    }

    public function delete($id)
    {
        $this->menuModel->delete($id);
        session()->setFlashdata('success', 'Delete success!');
        return redirect()->to(site_url('menu'));
    }

    public function subMenu()
    {
        $data = $this->userModel->getUser()->getRowArray();
        $data['subMenu'] = $this->submenuModel->getSubMenu()->getResultArray();
        $data['deleteSubmenu'] = $this->submenuModel->getData();
        $data['menu'] = $this->menuModel->get()->getResultArray();
        $data['title'] = 'Submenu Management';

        if ($this->request->getMethod() == 'post') {
            $rules = [
                'title'    => 'required|trim|max_length[30]',
                'menu_id'  => 'required|trim|max_length[24]',
                'url'      => 'required|trim|max_length[24]',
                'icon'     => 'required|trim'
            ];

            if (!$this->validate($rules)) {
                $data['validation'] = $this->validator;
            } else {
                $newData = [
                    'title'     => $this->request->getVar('title'),
                    'menu_id'   => $this->request->getVar('menu_id'),
                    'url'       => $this->request->getVar('url'),
                    'icon'      => $this->request->getVar('icon'),
                    'sub_menu_des' => $this->request->getVar('desc'),
                    'is_active'    => $this->request->getVar('is_active'),
                    'creator_id'   => $data['id'],
                    'date_created' => date('Y-m-d H:i:s')
                ];
                $this->submenuModel->save($newData);
                session()->setFlashdata('success', 'New submenu added!');
                return redirect()->to('submenu');
            }
        }
        echo view('templates/header', $data);
        echo view('templates/sidebar', $data);
        echo view('templates/topbar', $data);
        echo view('menu/submenu', $data);
        echo view('templates/footer');
    }
    public function detailSubmenu($id)
    {
        $data = $this->userModel->getUser()->getRowArray();
        $data['submenu'] = $this->submenuModel->getDetailSubmenu($id)->getRowArray();
        $data['title'] = 'Detail Submenu';

        echo view('templates/header', $data);
        echo view('templates/sidebar', $data);
        echo view('templates/topbar', $data);
        echo view('menu/detailsubmenu', $data);
        echo view('templates/footer');
    }

    public function updateSubmenu($id)
    {
        $data = $this->userModel->getUser()->getRowArray();
        $data['submenu'] = $this->submenuModel->where(['id' => $id])->get()->getRowArray();
        $data['menu'] = $this->menuModel->get()->getResultArray();
        $data['title'] = 'Edit Submenu';

        if ($this->request->getMethod() == 'post') {
            $rules = [
                'title'    => 'required|trim|max_length[30]',
                'menu_id'  => 'required|trim|max_length[24]',
                'url'      => 'required|trim|max_length[24]',
                'icon'     => 'required|trim'
            ];

            if (!$this->validate($rules)) {
                $data['validation'] = $this->validator;
            } else {
                $update = [
                    'title'     => $this->request->getVar('title'),
                    'menu_id'   => $this->request->getVar('menu_id'),
                    'url'       => $this->request->getVar('url'),
                    'icon'      => $this->request->getVar('icon'),
                    'sub_menu_desc' => $this->request->getVar('desc'),
                    'is_active'     => $this->request->getVar('is_active'),
                    'modifier_id'   => $data['id'],
                    'date_modified' => date('Y-m-d H:i:s')
                ];
                $this->submenuModel->set($update)->where(['id' => $id])->update();
                session()->setFlashdata('success', 'Submenu has been changed!');
                return redirect()->to(site_url('menu/submenu'));
            }
        }
        echo view('templates/header', $data);
        echo view('templates/sidebar', $data);
        echo view('templates/topbar', $data);
        echo view('menu/updatesubmenu', $data);
        echo view('templates/footer');
    }

    public function deleteSubmenu($id)
    {
        $this->submenuModel->delete($id);
        session()->setFlashdata('success', 'Delete success!');
        return redirect()->to(site_url('menu/submenu'));
    }
}
