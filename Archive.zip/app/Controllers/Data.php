<?php

namespace App\Controllers;

use RuntimeException;

class Data extends BaseController
{
    public function index()
    {
        // HELPER START
        $role_id = session()->get('role_id');
        $menu =  $this->request->uri->getSegment(1);

        // QUERY TABLE USER_MENU
        $queryMenu = $this->menuModel->where(['menu' => $menu])->get()->getRowArray();
        $menu_id = $queryMenu['id'];

        // QUERY TABLE USER_ACCESS_MENU
        $userAccess = $this->accessModel->where(['role_id' => $role_id, 'menu_id' => $menu_id])->get()->getRowArray();

        if ($userAccess == null) {
            return redirect()->to(site_url('auth/error'));
        }
        // END OF HELPER

    }

    public function arsip()
    {
        is_logged_in();
        $data = $this->userModel->getUser()->getRowArray();
        $data['detail'] = $this->dataModel->getDocumentDetail()->get()->getResultArray();
        // $data['detail'] = $this->dataModel->getDocumentDetail()->paginate(10);
        // $data['pager'] = $this->dataModel->getDocumentDetail()->pager;
        // var_dump($data);
        // die;
        // $data['pager'] = $this->dataModel->pager;
        if ($this->request->getVar('pencarian')) {
            $data['detail'] = $this->dataModel->searchDocumentDetail();
        }
        if ($this->request->getVar('retensi')) {
            $data['detail'] = $this->dataModel->searchDocumentByRetention();
        } else if ($this->request->getVar('destroy')) {
            $data['detail'] = $this->dataModel->searchDocumentByDestroy();
        }
        $data['title'] = 'Data Arsip';


        echo view('templates/header', $data);
        echo view('templates/sidebar', $data);
        echo view('templates/topbar', $data);
        echo view('data/arsip/index', $data);
        echo view('templates/footer');
    }

    public function detailArsip($id)
    {
        $data = $this->userModel->getUser()->getRowArray();
        $data['detail'] = $this->dataModel->getDetail($id)->get()->getRowArray();
        $data['title'] = 'Data Arsip';


        echo view('templates/header', $data);
        echo view('templates/sidebar', $data);
        echo view('templates/topbar', $data);
        echo view('data/arsip/detail', $data);
        echo view('templates/footer');
    }

    // Menampilkan list pemindahan yang harus disetujui oleh Corporate Secretary
    public function pemindahan()
    {
        // HELPER START
        $role_id = session()->get('role_id');
        if ($role_id <= 3 || $role_id == 7) {
            $data = $this->userModel->getUser()->getRowArray();
            if ($role_id <= 2) {
                $data['pemindahan'] = $this->documentModel->getApprovalCorsec()->get()->getResultArray();
            } elseif ($role_id == 3) {
                $data['pemindahan'] = $this->documentModel->getApprovalCorsec2()->where('document_feeding.is_active = 5')->get()->getResultArray();
            } elseif ($role_id == 7) {
                $data['pemindahan'] = $this->documentModel->getApprovalCorsec2()->where('document_feeding.is_active = 4')->get()->getResultArray();
            }
            $data['recordcenter'] = $this->documentModel->getRecordCenter()->getResultArray();
            $data['title'] = 'Persetujuan Pemindahan';

            echo view('templates/header', $data);
            echo view('templates/sidebar', $data);
            echo view('templates/topbar', $data);
            echo view('data/persetujuan/index', $data);
            echo view('templates/footer');
        } else {
            return redirect()->to(site_url('auth/error'));
        }
    }

    // Untuk setujui pemindahan oleh Corporate Secretary
    public function detPersetujuan($id)
    {
        $db = db_connect();
        $role_id = session()->get('role_id');
        if ($role_id <= 3 || $role_id == 7) {
            $data = $this->userModel->getUser()->getRowArray();
            $data['pemindahan'] = $this->documentModel->getPemindahanLokasi()->get()->getResultArray();
            $data['dpdi'] = $this->documentModel->getPemindahanId($id)->getRowArray();
            $data['detail'] = $this->documentModel->getDocumentDetail($id)->get()->getResultArray();
            $data['klasifikasi'] = $db->table('document_classification')->get()->getResultArray();
            $data['referensi'] = $this->masterModel->getReference()->getResultArray();
            $data['recordcenter'] = $this->documentModel->getRecordCenter()->getResultArray();
            $data['title'] = 'Detail Pemindahan';

            echo view('templates/header', $data);
            echo view('templates/sidebar', $data);
            echo view('templates/topbar', $data);
            echo view('data/persetujuan/detail', $data);
            echo view('templates/footer');
        } else {
            return redirect()->to(site_url('auth/error'));
        }
    }

    // Persetujuan pemindahan oleh Corporate Secretary
    public function approve($id)
    {
        $db = db_connect();
        $role_id = session()->get('role_id');
        if ($role_id <= 3 || $role_id == 7) {
            $data = $this->userModel->getUser()->getRowArray();
            $data['dpdi'] = $this->documentModel->getPemindahanId($id)->getRowArray();
            $data['detail'] = $this->documentModel->getDocumentDetail($id)->get()->getResultArray();

            $update = [
                // Kolom DB
                'is_active' => 5
            ];
            $db->table('document_feeding')->where('id', $id)->set($update)->update();
            session()->setFlashdata('success', 'Daftar dokumen pemindahan telah direview.');
            return redirect()->to(site_url('data/pemindahan'));
        } else {
            return redirect()->to(site_url('auth/error'));
        }
    }

    // Revisi pemindahan oleh Corporate Secretary ke Cabang
    public function revisi($id)
    {
        $db = db_connect();
        $role_id = session()->get('role_id');
        if ($role_id <= 3 || $role_id == 7) {
            $data = $this->userModel->getUser()->getRowArray();
            $data['dpdi'] = $this->documentModel->getPemindahanId($id)->getRowArray();
            $data['detail'] = $this->documentModel->getDocumentDetail($id)->get()->getResultArray();

            if ($this->request->getMethod() == 'post') {
                $rules = [
                    'note'           => 'required'
                ];

                if (!$this->validate($rules)) {
                    $data['validation'] = $this->validator;
                } else {
                    $update = [
                        // Kolom DB
                        'is_active' => 2,
                        'note' => $this->request->getVar('revisi')
                    ];
                    $db->table('document_feeding')->where('id', $id)->set($update)->update();
                    session()->setFlashdata('success', 'Permintaan revisi berhasil.');
                    return redirect()->to(site_url('data/pemindahan'));
                }
            }
        } else {
            return redirect()->to(site_url('auth/error'));
        }
    }

    // Persetujuan pemindahan oleh SPV Inaktif Corporate Secretary
    public function approve1($id)
    {
        $db = db_connect();
        $role_id = session()->get('role_id');
        if ($role_id <= 3) {
            $data = $this->userModel->getUser()->getRowArray();
            $data['dpdi'] = $this->documentModel->getPemindahanId($id)->getRowArray();
            $data['detail'] = $this->documentModel->getDocumentDetail($id)->get()->getResultArray();

            $update = [
                // Kolom DB
                'is_active' => 6
            ];
            $updateDoc = [
                // Kolom DB
                'destroy_ddum' => 1
            ];
            $db->table('document_feeding')->where('id', $id)->set($update)->update();
            $this->documentModel->getDocumentDetail($id)->set($updateDoc)->update();
            session()->setFlashdata('success', 'Daftar dokumen pemindahan telah disetujui.');
            return redirect()->to(site_url('data/pemindahan'));
        } else {
            return redirect()->to(site_url('auth/error'));
        }
    }

    // Menampilkan list pemindahan yang harus disetujui oleh Corporate Secretary
    public function verify()
    {
        // HELPER START
        $role_id = session()->get('role_id');
        if ($role_id <= 3 || $role_id == 7) {
            $data = $this->userModel->getUser()->getRowArray();
            $data['pemindahan'] = $this->documentModel->getVerifyCorsec()->get()->getResultArray();
            $data['recordcenter'] = $this->documentModel->getRecordCenter()->getResultArray();
            $data['title'] = 'Verifikasi DPDI';
            $data['desc'] = 'Pada halaman ini terdapat DPDI yang harus diverifikasi oleh Corporate Secretary.';

            echo view('templates/header', $data);
            echo view('templates/sidebar', $data);
            echo view('templates/topbar', $data);
            echo view('data/verifikasi/index', $data);
            echo view('templates/footer');
        } else {
            return redirect()->to(site_url('auth/error'));
        }
    }

    // Persetujuan pemindahan oleh Corporate Secretary untuk dikirim ke RC
    public function verified($id)
    {
        $db = db_connect();
        $role_id = session()->get('role_id');
        if ($role_id <= 3 || $role_id == 7) {
            $data = $this->userModel->getUser()->getRowArray();
            $data['dpdi'] = $this->documentModel->getPemindahanId($id)->getRowArray();
            $data['detail'] = $this->documentModel->getDocumentDetail($id)->get()->getResultArray();
            if ($this->request->getMethod() == 'post') {
                $rules = [
                    'note' => 'required'
                ];
                if (!$this->validate($rules)) {
                    $data['validation'] = $this->validator;
                } else {
                    $update = [
                        // Kolom DB
                        'note' => $this->request->getVar('note'),
                        'is_active' => 8
                    ];
                    $db->table('document_feeding')->where('id', $id)->set($update)->update();
                    session()->setFlashdata('success', 'Dokumen pemindahan telah diverifikasi.');
                    return redirect()->to(site_url('data/verify'));
                }
            }
        } else {
            return redirect()->to(site_url('auth/error'));
        }
    }

    // Untuk setujui pemindahan oleh Corporate Secretary
    public function verifyDetail($id)
    {
        $db = db_connect();
        $role_id = session()->get('role_id');
        if ($role_id <= 3 || $role_id == 7) {
            $data = $this->userModel->getUser()->getRowArray();
            $data['pemindahan'] = $this->documentModel->getPemindahanLokasi()->get()->getResultArray();
            $data['dpdi'] = $this->documentModel->getPemindahanId($id)->getRowArray();
            $data['detail'] = $this->documentModel->getDocumentDetail($id)->get()->getResultArray();
            $data['klasifikasi'] = $db->table('document_classification')->get()->getResultArray();
            $data['referensi'] = $this->masterModel->getReference()->getResultArray();
            $data['recordcenter'] = $this->documentModel->getRecordCenter()->getResultArray();
            $data['title'] = 'Verifikasi DPDI';

            echo view('templates/header', $data);
            echo view('templates/sidebar', $data);
            echo view('templates/topbar', $data);
            echo view('data/verifikasi/detail', $data);
            echo view('templates/footer');
        } else {
            return redirect()->to(site_url('auth/error'));
        }
    }

    public function verifyRevisi($id)
    {
        $db = db_connect();
        $role_id = session()->get('role_id');
        if ($role_id <= 3) {
            $data = $this->userModel->getUser()->getRowArray();
            $data['dpdi'] = $this->documentModel->getPemindahanId($id)->getRowArray();
            $data['detail'] = $this->documentModel->getDocumentDetail($id)->get()->getResultArray();
            if ($this->request->getMethod() == 'post') {
                $rules = [
                    'revisi' => 'required'
                ];
                if (!$this->validate($rules)) {
                    $data['validation'] = $this->validator;
                } else {
                    $update = [
                        // Kolom DB
                        'is_active' => 6,
                        'note' => $this->request->getVar('revisi')
                    ];
                    $db->table('document_feeding')->where('id', $id)->set($update)->update();
                    session()->setFlashdata('success', 'Permintaan revisi berhasil.');
                    return redirect()->to(site_url('data/verify'));
                }
            }
        } else {
            return redirect()->to(site_url('auth/error'));
        }
    }

    public function pemusnahan()
    {
        $role_id = session()->get('role_id');
        if ($role_id <= 3 || $role_id == 7) {
            $data = $this->userModel->getUser()->getRowArray();
            $data['musnah'] = $this->documentModel->getMusnah()->get()->getResultArray();
            if ($this->request->getVar('pencarian')) {
                $data['musnah'] = $this->documentModel->searchMusnah()->get()->getResultArray();
                $data['row'] = $this->documentModel->searchMusnah()->countAllResults();
            }
            $data['row'] = $this->documentModel->getMusnah()->countAllResults();
            $data['title'] = 'Pemusnahan';
        } else {
            return redirect()->to(site_url('auth/error'));
        }
        echo view('templates/header', $data);
        echo view('templates/sidebar', $data);
        echo view('templates/topbar', $data);
        echo view('data/pemusnahan/index', $data);
        echo view('templates/footer');
    }

    public function ddum($id)
    {
        $data = $this->userModel->getUser()->getRowArray();
        $data['ddum'] = $this->documentModel->getMusnahById($id)->get()->getRowArray();
        $data['detail'] = $this->documentModel->getDocumentMusnah($id)->get()->getResultArray();
        if ($this->request->getVar('pencarian')) {
            $data['detail'] = $this->documentModel->searchDetailDdum($id)->get()->getResultArray();
        }
        $data['title'] = 'Detail DDUM';

        echo view('templates/header', $data);
        echo view('templates/sidebar', $data);
        echo view('templates/topbar', $data);
        echo view('data/pemusnahan/ddum', $data);
        echo view('templates/footer');
    }

    public function editddum($id)
    {
        $role_id = session()->get('role_id');
        $db = db_connect();
        if ($role_id <= 3 || $role_id == 7) {
            $data = $this->userModel->getUser()->getRowArray();
            $data['doc']   = $this->documentModel->getDocumentById($id)->get()->getRowArray();
            $data['status'] = $db->table('document_ddum_status')->get()->getResultArray();
            $data['title'] = 'Status Musnah';

            if ($this->request->getMethod() == 'post') {
                $rules = [
                    'status'           => 'required'
                ];

                if (!$this->validate($rules)) {
                    $data['validation'] = $this->validator;
                } else {
                    $pending = [
                        // Coloumn DB
                        'destroy_ddum' => $this->request->getVar('status'),
                        'destroy_schedule'  => (date('Y') + 1),
                        'documentstatus_id' => 4,
                        'pending_period'    => 1
                    ];
                    $this->documentModel->getDocumentById($id)->update($pending);
                    session()->setFlashdata('success', 'Berhasil. Status dokumen telah ditunda hingga pemusnahan berikutnya.');
                    return redirect()->to(site_url('data/ddum/' . $data['doc']['working_unit_id']));
                }
            }
        } else {
            return redirect()->to(site_url('auth/error'));
        }
        echo view('templates/header', $data);
        echo view('templates/sidebar', $data);
        echo view('templates/topbar', $data);
        echo view('data/pemusnahan/edit', $data);
        echo view('templates/footer');
    }

    public function nomorddum($id)
    {
        $role_id = session()->get('role_id');
        if ($role_id <= 3 || $role_id == 7) {
            $data = $this->userModel->getUser()->getRowArray();
            $data['ddum'] = $this->documentModel->getMusnahById($id)->get()->getRowArray();
            $session = session();

            // Prefix DDUM
            $prefix = 'No.' . 'DDUM.' . date('Y') . '.';
            $lastBox = $this->documentModel->getDestroyNumberMax($prefix)->get()->getRowArray();
            // Get last 5 number
            $destroyNumber = (int) substr($lastBox['destroy_number'], -3, 3);
            // Add new box number
            $destroyNumber++;
            $newdestroyNumber = $prefix .  sprintf('%03s', $destroyNumber);

            // Prefix DDM
            $prefix = 'No.' . 'DDM.' . date('Y') . '.';
            $lastBox = $this->documentModel->getDDMNumberMax($prefix)->get()->getRowArray();
            // Get last 5 number
            $DDMNumber = (int) substr($lastBox['destroyed_number'], -3, 3);
            // Add new box number
            $DDMNumber++;
            $newDDMNumber = $prefix .  sprintf('%03s', $DDMNumber);

            $newData = [
                'destroy_number'    => $newdestroyNumber,
                'destroyed_number'  => $newDDMNumber,
                'working_unit_id'   => $data['ddum']['wu_id'],
                'creator_id'        => $data['id'],
                'date_created'      => date('Y-m-d H:i:s')
            ];

            $db = db_connect();
            $db->table('document_destroy')->set($newData)->insert();
            $session->setFlashdata('success', 'Nomor DDUM telah dibuat.');
            return redirect()->to(site_url('data/ddum/' . $data['ddum']['wu_id']));
        } else {
            return redirect()->to(site_url('auth/error'));
        }
    }

    public function prosesmusnah($id)
    {
        // HELPER START
        $role_id = session()->get('role_id');
        if ($role_id <= 3 || $role_id == 7) {
            $data = $this->userModel->getUser()->getRowArray();
            $data['ddum'] = $this->documentModel->getMusnahById($id)->get()->getRowArray();
            $data['detail'] = $this->documentModel->prosesMusnah($id)->get()->getResultArray();
            $data['title'] = 'Proses Musnah';
            $session = session();

            if ($this->request->getMethod() == 'post') {
                $rules = ([
                    'memo' => [
                        'label' => 'Memo',
                        'rules' => 'ext_in[memo,pdf]|max_size[memo,2048]'
                    ]
                ]);
                if (!$this->validate($rules)) {
                    $data['validation'] = $this->validator;
                } else {
                    // Upload Image
                    $memo = $this->request->getFile('memo');
                    // Untuk mengetahui nama
                    $file = $memo->getName();
                    if (!$memo->isValid()) {
                        throw new RuntimeException($memo->getErrorString() . '(' . $memo->getError() . ')');
                    } else {
                        // Pindah ke folder
                        $memo->move('./assets/files/memo/');
                    }

                    $update = [
                        // Coloumn DB
                        'file_memo'         => $file,
                        'destroy_date'      => date('Y-m-d H:i:s'),
                        'destroy_period'    => date('Y'),
                        'documentstatus_id' => 2,
                        'destroy_id'        => $data['ddum']['id']
                    ];
                    $this->documentModel->prosesMusnah($id)->set($update)->update();
                    $session->setFlashdata('success', 'Dokumen telah dimusnahkan.');
                    return redirect()->to(site_url('data/pemusnahan'));
                }
            }
        } else {
            return redirect()->to(site_url('auth/error'));
        }
        echo view('templates/header', $data);
        echo view('templates/sidebar', $data);
        echo view('templates/topbar', $data);
        echo view('data/pemusnahan/prosesddum', $data);
        echo view('templates/footer');
    }

    // Daftar Dokumen Musnah
    public function ddm()
    {
        $role_id = session()->get('role_id');
        if ($role_id <= 3 || $role_id == 7) {
            $data = $this->userModel->getUser()->getRowArray();
            $data['destroyed'] = $this->documentModel->getDestroyed()->get()->getResultArray();
            if ($this->request->getVar('pencarian')) {
                $data['destroyed'] = $this->documentModel->searchDDM()->get()->getResultArray();
            }
            $data['row'] = $this->documentModel->getDestroyed()->countAllResults();
            $data['title'] = 'Daftar Dokumen Musnah';
        } else {
            return redirect()->to(site_url('auth/error'));
        }
        echo view('templates/header', $data);
        echo view('templates/sidebar', $data);
        echo view('templates/topbar', $data);
        echo view('data/ddm/index', $data);
        echo view('templates/footer');
    }

    public function detailddm($id)
    {
        $data = $this->userModel->getUser()->getRowArray();
        $data['destroyed'] = $this->documentModel->getDestroyedById($id)->get()->getRowArray();
        $data['detail'] = $this->documentModel->getDestroyedData($id)->get()->getResultArray();
        if ($this->request->getVar('pencarian')) {
            $data['detail'] = $this->documentModel->searchDestroyedData($id)->get()->getResultArray();
        }
        $data['title'] = 'Detail DDM';

        echo view('templates/header', $data);
        echo view('templates/sidebar', $data);
        echo view('templates/topbar', $data);
        echo view('data/ddm/ddm', $data);
        echo view('templates/footer');
    }
}
