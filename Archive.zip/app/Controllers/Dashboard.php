<?php

namespace App\Controllers;

class Dashboard extends BaseController
{
    public function index()
    {
        $data = $this->userModel->getUser()->getRowArray();
        $data['title'] = 'Dashboard';

        $user = session()->get('role_id');

        if ($user <= 2) {
            return redirect()->to(site_url('admin'));
        } else if ($user == 3) {
            return redirect()->to(site_url('home'));
        } else if ($user == 4) {
            return redirect()->to(site_url('home/recordcenter'));
        } else {
            return redirect()->to(site_url('user'));
        }

        echo view('templates/header', $data);
        echo view('templates/sidebar', $data);
        echo view('templates/topbar', $data);
        echo view('dashboard/index', $data);
        echo view('templates/footer');
    }

    public function referensi()
    {
        $db = db_connect();
        $data = $this->userModel->getUser()->getRowArray();
        $data['referensi'] = $this->masterModel->getReference()->getResultArray();
        if ($this->request->getVar('pencarian')) {
            $data['referensi'] = $this->masterModel->searchReference();
        }
        $data['klasifikasi'] = $db->table('document_classification')->get()->getResultArray();
        $data['title'] = 'Data Referensi';

        if ($this->request->getMethod() == 'post') {
            $rules = [
                'klasifikasi' => 'required|trim|max_length[10]',
                'code'        => 'required|trim|max_length[10]',
                'jenis'       => 'required|trim|max_length[256]',
                'aktif'       => 'required|trim|numeric|max_length[10]',
                'inaktif'     => 'required|trim|numeric|max_length[10]',
                'status'      => 'required'
            ];

            if (!$this->validate($rules)) {
                $data['validation'] = $this->validator;
            } else {
                $newData = [
                    // Kolom DB
                    'classification_id'  => $this->request->getVar('klasifikasi'),
                    'dr_code'            => $this->request->getVar('code'),
                    'dr_name'            => $this->request->getVar('jenis'),
                    'active_retention'   => $this->request->getVar('aktif'),
                    'inactive_retention' => $this->request->getVar('inaktif'),
                    'total_retention' => ($this->request->getVar('aktif') + $this->request->getVar('inaktif')),
                    'is_active'     => $this->request->getVar('status'),
                    'creator_id'    => $data['id'],
                    'date_created'  => date('Y-m-d H:i:s')
                ];
                $db->table('document_reference')->set($newData)->insert();
                $session = session();
                $session->setFlashdata('success', 'Referensi telah ditambahkan!');
                return redirect()->to(site_url('dashboard/referensi'));
            }
        }

        echo view('templates/header', $data);
        echo view('templates/sidebar', $data);
        echo view('templates/topbar', $data);
        if ($data['role_id'] <= 3) {
            echo view('dashboard/referensi/admin/index', $data);
        } else {
            echo view('dashboard/referensi/index', $data);
        }
        echo view('templates/footer');
    }

    public function updateRef($id)
    {
        $db = db_connect();
        $data = $this->userModel->getUser()->getRowArray();
        $data['referensi'] = $this->masterModel->setTable('document_reference')->where(['id' => $id])->get()->getRowArray();
        $data['klasifikasi'] = $db->table('document_classification')->get()->getResultArray();
        $data['title'] = 'Edit Data';

        if ($this->request->getMethod() == 'post') {
            $rules = [
                'klasifikasi' => 'required|trim|max_length[10]',
                'code'      => 'required|trim|max_length[10]',
                'jenis'     => 'required|trim|max_length[256]',
                'aktif'     => 'required|trim|max_length[10]',
                'inaktif'   => 'required|trim|max_length[10]',
                'status'    => 'required'
            ];

            if (!$this->validate($rules)) {
                $data['validation'] = $this->validator;
            } else {
                $update = [
                    // Kolom DB
                    'classification_id'  => $this->request->getVar('klasifikasi'),
                    'dr_code'            => $this->request->getVar('code'),
                    'dr_name'            => $this->request->getVar('jenis'),
                    'active_retention'   => $this->request->getVar('aktif'),
                    'inactive_retention' => $this->request->getVar('inaktif'),
                    'total_retention' => ($this->request->getVar('aktif') + $this->request->getVar('inaktif')),
                    'is_active'      => $this->request->getVar('status'),
                    'modifier_id'    => $data['id'],
                    'date_modified'  => date('Y-m-d H:i:s')
                ];
                $db->table('document_reference')->set($update)->where(['id' => $id])->update();
                session()->setFlashdata('success', 'Referensi dokumen has been changed!');
                return redirect()->to(site_url('dashboard/referensi'));
            }
        }
        echo view('templates/header', $data);
        echo view('templates/sidebar', $data);
        echo view('templates/topbar', $data);
        echo view('dashboard/referensi/admin/update', $data);
        echo view('templates/footer');
    }

    public function detailRef($id)
    {
        $data = $this->userModel->getUser()->getRowArray();
        $data['referensi'] = $this->masterModel->getReferenceDetail($id)->getRowArray();
        $data['title'] = 'Data Referensi';

        echo view('templates/header', $data);
        echo view('templates/sidebar', $data);
        echo view('templates/topbar', $data);
        echo view('dashboard/referensi/admin/detail', $data);
        echo view('templates/footer');
    }

    public function deleteRef($id)
    {
        $db = db_connect();
        $db->table('document_reference')->delete(['id' => $id]);
        session()->setFlashdata('success', 'Delete success!');
        return redirect()->to(site_url('dashboard/referensi'));
    }
    // END OF REFERENSI

    public function setLokasi()
    {
        // HELPER START
        $role_id = session()->get('role_id');
        if ($role_id <= 4) {
            $data = $this->userModel->getUser()->getRowArray();
            $data['pemindahan'] = $this->documentModel->getPemindahanLokasi()->get()->getResultArray();
            $data['recordcenter'] = $this->documentModel->getRecordCenter()->getResultArray();
            $data['title'] = 'Atur Lokasi Simpan';

            echo view('templates/header', $data);
            echo view('templates/sidebar', $data);
            echo view('templates/topbar', $data);
            echo view('dashboard/recordcenter/setlokasi/index', $data);
            echo view('templates/footer');
        } else {
            return redirect()->to(site_url('auth/error'));
        }
    }

    public function lokasiDokumen($id)
    {
        $db = db_connect();
        $role_id = session()->get('role_id');
        if ($role_id <= 4) {
            $data = $this->userModel->getUser()->getRowArray();
            $data['pemindahan'] = $this->documentModel->getPemindahanLokasi()->get()->getResultArray();
            $data['dpdi'] = $this->documentModel->getPemindahanId($id)->getRowArray();
            $data['detail'] = $this->documentModel->getDocumentDetail($id)->get()->getResultArray();
            $data['klasifikasi'] = $db->table('document_classification')->get()->getResultArray();
            $data['referensi'] = $this->masterModel->getReference()->getResultArray();
            $data['recordcenter'] = $this->documentModel->getRecordCenter()->getResultArray();
            $data['title'] = 'Detail Lokasi Simpan';

            echo view('templates/header', $data);
            echo view('templates/sidebar', $data);
            echo view('templates/topbar', $data);
            echo view('dashboard/recordcenter/setlokasi/lokasidokumen', $data);
            echo view('templates/footer');
        } else {
            return redirect()->to(site_url('auth/error'));
        }
    }

    public function setSimpan($id)
    {
        $db = db_connect();
        $role_id = session()->get('role_id');
        $data = $this->userModel->getUser()->getRowArray();
        $data['title'] = 'Atur Lokasi Simpan';
        if ($role_id <= 4) {
            $data['detail'] = $this->documentModel->getDocumentById($id)->get()->getRowArray();

            if ($this->request->getMethod() == 'post') {
                $rules = [
                    'lokasi'      => 'required|trim|max_length[24]'
                ];

                if (!$this->validate($rules)) {
                    $data['validation'] = $this->validator;
                } else {
                    $newData = [
                        'location_id'   => $this->request->getVar('lokasi'),
                        'modifier_id'   => $data['id'],
                        'date_modified' => date('Y-m-d H:i:s')
                    ];
                    $db->table('document_detail')->where('doc_id', $id)->set($newData)->update();
                    $session = session();
                    $session->setFlashdata('success', 'Lokasi telah ditambahkan.');
                    return redirect()->to(site_url('dashboard/lokasidokumen/' . $data['detail']['feeding_id']));
                }
            }
            echo view('templates/header', $data);
            echo view('templates/sidebar', $data);
            echo view('templates/topbar', $data);
            echo view('dashboard/recordcenter/setlokasi/setsimpan', $data);
            echo view('templates/footer');
        } else {
            return redirect()->to(site_url('auth/error'));
        }
    }

    public function editSimpan($id)
    {
        $db = db_connect();
        $role_id = session()->get('role_id');
        $data = $this->userModel->getUser()->getRowArray();
        $data['title'] = 'Edit Lokasi Simpan';
        if ($role_id <= 4) {
            $data['detail'] = $this->documentModel->getDocumentById($id)->get()->getRowArray();

            if ($this->request->getMethod() == 'post') {
                $rules = [
                    'lokasi'      => 'required|trim|max_length[24]'
                ];

                if (!$this->validate($rules)) {
                    $data['validation'] = $this->validator;
                } else {
                    $newData = [
                        'location_id'   => $this->request->getVar('lokasi'),
                        'modifier_id'   => $data['id'],
                        'date_modified' => date('Y-m-d H:i:s')
                    ];
                    $db->table('document_detail')->where('doc_id', $id)->set($newData)->update();
                    $session = session();
                    $session->setFlashdata('success', 'Lokasi telah ditambahkan.');
                    return redirect()->to(site_url('dashboard/lokasidokumen/' . $data['detail']['feeding_id']));
                }
            }
            echo view('templates/header', $data);
            echo view('templates/sidebar', $data);
            echo view('templates/topbar', $data);
            echo view('dashboard/recordcenter/setlokasi/editsimpan', $data);
            echo view('templates/footer');
        } else {
            return redirect()->to(site_url('auth/error'));
        }
    }

    public function submitDpdi($id)
    {
        $db = db_connect();
        $data = $this->userModel->getUser()->getRowArray();
        $data['dpdi'] = $this->documentModel->getPemindahanId($id)->getRowArray();
        $data['pemindahan'] = $this->documentModel->getPemindahan()->get()->getResultArray();
        $data['klasifikasi'] = $db->table('document_classification')->get()->getResultArray();
        $data['referensi'] = $this->masterModel->getReference()->getResultArray();
        $data['detail'] = $this->documentModel->getDocumentDetail($id)->get()->getResultArray();

        $update = [
            // Kolom DB
            'modifier_id'    => $data['id'],
            'date_modified'  => date('Y-m-d H:i:s'),
            'is_active' => 7
        ];
        $db = db_connect();
        $db->table('document_feeding')->where('id', $id)->set($update)->update();
        session()->setFlashdata('success', 'Berhasil disimpan. Menunggu verifikasi Corporate Secretary.');
        return redirect()->to(site_url('dashboard/setlokasi'));
    }

    public function terima()
    {
        // HELPER START
        $role_id = session()->get('role_id');
        if ($role_id <= 4) {
            $data = $this->userModel->getUser()->getRowArray();
            $data['pemindahan'] = $this->documentModel->getPenerimaan()->get()->getResultArray();
            $data['title'] = 'Penerimaan Dokumen';

            echo view('templates/header', $data);
            echo view('templates/sidebar', $data);
            echo view('templates/topbar', $data);
            echo view('dashboard/recordcenter/penerimaan/index', $data);
            echo view('templates/footer');
        } else {
            return redirect()->to(site_url('auth/error'));
        }
    }

    public function detailTerima($id)
    {
        $db = db_connect();
        $data = $this->userModel->getUser()->getRowArray();
        $data['dpdi'] = $this->documentModel->getPemindahanId($id)->getRowArray();
        $data['pemindahan'] = $this->documentModel->getPemindahan()->get()->getResultArray();
        $data['klasifikasi'] = $db->table('document_classification')->get()->getResultArray();
        $data['referensi'] = $this->masterModel->getReference()->getResultArray();
        $data['detail'] = $this->documentModel->getDocumentDetail($id)->get()->getResultArray();
        $data['title'] = 'Detail';

        echo view('templates/header', $data);
        echo view('templates/sidebar', $data);
        echo view('templates/topbar', $data);
        echo view('dashboard/recordcenter/penerimaan/detail', $data);
        echo view('templates/footer');
    }
    // Konfirmasi penerimaan dokumen oleh Record Center
    public function konfirmasi($id)
    {
        $db = db_connect();
        $role_id = session()->get('role_id');
        if ($role_id <= 4) {
            $data = $this->userModel->getUser()->getRowArray();
            $data['dpdi'] = $this->documentModel->getPemindahanId($id)->getRowArray();
            $data['detail'] = $this->documentModel->getDocumentDetail($id)->get()->getResultArray();

            $update = [
                // Kolom DB
                'is_active' => 11
            ];
            $updateDoc = [
                // Kolom DB
                'documentstatus_id' => 3
            ];
            $db = db_connect();
            $db->table('document_feeding')->where('id', $id)->set($update)->update();
            $this->documentModel->getDocumentDetail($id)->set($updateDoc)->update();
            session()->setFlashdata('success', 'Proses pengiriman dokumen telah selesai.');
            return redirect()->to(site_url('dashboard/terima'));
        } else {
            return redirect()->to(site_url('auth/error'));
        }
    }

    // Konfirmasi penerimaan dokumen oleh Record Center
    public function terimaSebagian($id)
    {
        $db = db_connect();
        $role_id = session()->get('role_id');
        if ($role_id <= 4) {
            $data = $this->userModel->getUser()->getRowArray();
            $data['dpdi'] = $this->documentModel->getPemindahanId($id)->getRowArray();
            $data['detail'] = $this->documentModel->getDocumentDetail($id)->get()->getResultArray();
            if ($this->request->getMethod() == 'post') {
                $rules = [
                    'note' => 'required'
                ];
                if (!$this->validate($rules)) {
                    $data['validation'] = $this->validator;
                } else {
                    $update = [
                        // Kolom DB
                        'note'      => $this->request->getVar('note'),
                        'is_active' => 10
                    ];
                    $db = db_connect();
                    $db->table('document_feeding')->where('id', $id)->set($update)->update();
                    session()->setFlashdata('success', 'Telah dierima sebagian.');
                    return redirect()->to(site_url('dashboard/terima'));
                }
            }
        } else {
            return redirect()->to(site_url('auth/error'));
        }
    }
}
