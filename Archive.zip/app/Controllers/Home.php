<?php

namespace App\Controllers;

use App\Models\UserModel;

class Home extends BaseController
{
	public function index()
	{
		$data = $this->userModel->getUser()->getRowArray();
		$data['title'] = 'Dashboard';

		echo view('templates/header', $data);
		echo view('templates/sidebar', $data);
		echo view('templates/topbar', $data);
		echo view('dashboard/admin/index', $data);
		echo view('templates/footer');
	}
	//--------------------------------------------------------------------

	public function recordcenter()
	{
		$data = $this->userModel->getUser()->getRowArray();
		$data['title'] = 'Dashboard';

		echo view('templates/header', $data);
		echo view('templates/sidebar', $data);
		echo view('templates/topbar', $data);
		echo view('dashboard/recordcenter/index', $data);
		echo view('templates/footer');
	}
	//--------------------------------------------------------------------

}
