<?php

namespace App\Controllers;

class Auth extends BaseController
{
    function __construct()
    {
        helper('form');
    }
    public function index()
    {
        // Redirect
        if (session()->get('email')) {
            return redirect()->to(site_url('/'));
        }

        $data = ['title' => 'Login Page | RMS'];
        echo view('templates/auth_header', $data);
        echo view('auth/login');
        echo view('templates/auth_footer');
    }

    public function login()
    {
        $data = ['title' => 'Login Page | RMS'];
        $emails = $this->request->getVar('email');
        $user = $this->userModel->where('email', $emails)->first();
        // If user available
        if ($user) {
            if ($this->request->getMethod() == 'post') {
                $rules = [
                    'email'    => 'required|min_length[3]|max_length[30]|valid_email',
                    'password' => 'required|min_length[3]|max_length[255]|validateUser[email,password]'
                ];

                $errors = [
                    'password' => [
                        'validateUser' => 'Wrong email or password. Please try again.',
                    ],
                ];

                if (!$this->validate($rules, $errors)) {
                    $data['validation'] = $this->validator;
                } else if ($user['is_active'] == 1) {
                    $this->setUserSession($user);
                    return redirect()->to(base_url('dashboard'));
                } else if ($user['is_active'] == 0) {
                    session()->setFlashdata('failed', 'Your account is not activated!');
                    return redirect()->to(site_url('auth'));
                }
            }
        } else {
            session()->setFlashdata('failed', 'Email is not registered.');
            return redirect()->to(site_url('auth'));
        }

        echo view('templates/auth_header', $data);
        echo view('auth/login');
        echo view('templates/auth_footer');
    }

    private function setUserSession($user)
    {
        $data = [
            'name'       => $user['name'],
            'email'      => $user['email'],
            'role_id'    => $user['role_id'],
            'workingunit_name' => $user['workingunit_name'],
            'uri'        => $this->request->uri->getSegment(2),
            'isLoggedIn' => true,
        ];
        session()->set($data);
        return true;
    }

    public function registration()
    {
        // Redirect
        if (session()->get('email')) {
            return redirect()->to(site_url('/'));
        }

        $data = ['title' => 'Registration | RMS'];

        if ($this->request->getMethod() == 'post') {
            $rules = [
                'name'      => 'required|trim|max_length[24]',
                'email'     => 'required|trim|is_unique[user.email]',
                'password1' => 'required|trim|min_length[3]|matches[password2]',
                'password2' => 'required|min_length[3]matches[password1]'
            ];

            if (!$this->validate($rules)) {
                $data['validation'] = $this->validator;
            } else {
                $newData = [
                    'name' => $this->request->getVar('name'),
                    'email' => $this->request->getVar('email'),
                    'image' => 'default.png',
                    'password' => $this->request->getVar('password1'),
                    'role_id' => '1',
                    'is_active' => '1',
                    'date_created' => date('Y-m-d H:i:s')
                ];
                $this->userModel->save($newData);
                $session = session();
                $session->setFlashdata('success', 'Congratulation! Your account has been created. Please Login');
                return redirect()->to('index');
            }
        }

        echo view('templates/auth_header', $data);
        echo view('auth/registration');
        echo view('templates/auth_footer');
    }

    public function logout()
    {
        $array_items = ['name', 'email', 'role_id', 'workingunit_name', 'isLoggedIn'];
        session()->remove($array_items);
        session()->setFlashdata('success', 'You have been logged out!');
        return redirect()->to('index');
    }

    public function error()
    {
        $data = ['title' => 'Page Not Found'];
        echo view('templates/header', $data);
        echo view('auth/error');
    }
}
