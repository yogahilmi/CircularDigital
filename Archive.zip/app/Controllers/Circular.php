<?php

namespace App\Controllers;

class Circular extends BaseController
{
    public function index()
    {
        echo 'Hello Committee';
    }

    public function bod()
    {
        is_logged_in();
        $data = $this->userModel->getUser()->getRowArray();
        $data['circular'] = $this->circularModel->getBodCircular()->getResultArray();
        $data['title'] = 'Resolution BOD';

        if ($this->request->getMethod() == 'post') {
            $rules = [
                'number'      => 'required|trim|is_unique[tb_circular.number]',
                'subject'     => 'required|trim|max_length[128]',
                'description' => 'required|trim|max_length[128]',
                'workingunit' => 'required',
                'pic'         => 'required',
                'date'        => 'required',
                'attachment'  => 'required'
            ];

            if (!$this->validate($rules)) {
                $data['validation'] = $this->validator;
            } else {
                $newData = [
                    'number'        => $this->request->getVar('number'),
                    'circular_date' => date('Y-m-d', strtotime($this->request->getVar('date'))),
                    'subject'       => $this->request->getVar('subject'),
                    'workingunit_name'   => $this->request->getVar('workingunit'),
                    'pic_name'      => $this->request->getVar('pic'),
                    'description'   => $this->request->getVar('description'),
                    'attachment'    => $this->request->getVar('attachment'),
                    'category_id'   => 3,
                    'creator_id'    => $data['id'],
                    'date_created'  => date('Y-m-d H:i:s')
                ];
                $db = db_connect();
                $db->table('tb_circular')->set($newData)->insert();
                $session = session();
                $session->setFlashdata('success', 'Data berhasil ditambahkan!');
                return redirect()->to('bod');
            }
        }

        echo view('templates/header', $data);
        echo view('templates/sidebar', $data);
        echo view('templates/topbar', $data);
        echo view('circular/circular_bod', $data);
        echo view('templates/footer');
    }

    public function boc()
    {
        is_logged_in();
        $data = $this->userModel->getUser()->getRowArray();
        $data['circular'] = $this->circularModel->getBocCircular()->getResultArray();
        $data['title'] = 'Resolution BOC';

        if ($this->request->getMethod() == 'post') {
            $rules = [
                'number'      => 'required|trim|is_unique[tb_circular.number]',
                'subject'     => 'required|trim|max_length[128]',
                'description' => 'required|trim|max_length[128]',
                'workingunit' => 'required',
                'pic'         => 'required',
                'date'        => 'required',
                'attachment'  => 'required'
            ];

            if (!$this->validate($rules)) {
                $data['validation'] = $this->validator;
            } else {
                $newData = [
                    'number'        => $this->request->getVar('number'),
                    'circular_date' => date('Y-m-d', strtotime($this->request->getVar('date'))),
                    'subject'       => $this->request->getVar('subject'),
                    'workingunit_name'   => $this->request->getVar('workingunit'),
                    'pic_name'      => $this->request->getVar('pic'),
                    'description'   => $this->request->getVar('description'),
                    'attachment'    => $this->request->getVar('attachment'),
                    'category_id'   => 4,
                    'creator_id'    => $data['id'],
                    'date_created'  => date('Y-m-d H:i:s')
                ];
                $db = db_connect();
                $db->table('tb_circular')->set($newData)->insert();
                $session = session();
                $session->setFlashdata('success', 'Data berhasil ditambahkan!');
                return redirect()->to('boc');
            }
        }

        echo view('templates/header', $data);
        echo view('templates/sidebar', $data);
        echo view('templates/topbar', $data);
        echo view('circular/circular_boc', $data);
        echo view('templates/footer');
    }

    public function committee()
    {
        is_logged_in();
        $data = $this->userModel->getUser()->getRowArray();
        $data['circular'] = $this->circularModel->getComCircular()->getResultArray();
        $data['committee'] = $this->circularModel->getCommittee()->getResultArray();
        $data['title'] = 'Resolution Committee';

        if ($this->request->getMethod() == 'post') {
            $rules = [
                'number'      => 'required|trim|is_unique[tb_circular.number]',
                'subject'     => 'required|trim|max_length[128]',
                'description' => 'required|trim|max_length[128]',
                'committee'   => 'required',
                'workingunit' => 'required',
                'pic'         => 'required',
                'date'        => 'required',
                'attachment'  => 'required'
            ];

            if (!$this->validate($rules)) {
                $data['validation'] = $this->validator;
            } else {
                $newData = [
                    'number'        => $this->request->getVar('number'),
                    'circular_date' => date('Y-m-d', strtotime($this->request->getVar('date'))),
                    'committee_id'  => $this->request->getVar('committee'),
                    'subject'       => $this->request->getVar('subject'),
                    'workingunit_name'   => $this->request->getVar('workingunit'),
                    'pic_name'      => $this->request->getVar('pic'),
                    'description'   => $this->request->getVar('description'),
                    'attachment'    => $this->request->getVar('attachment'),
                    'category_id'   => 5,
                    'creator_id'    => $data['id'],
                    'date_created'  => date('Y-m-d H:i:s')
                ];
                $db = db_connect();
                $db->table('tb_circular')->set($newData)->insert();
                $session = session();
                $session->setFlashdata('success', 'Data berhasil ditambahkan!');
                return redirect()->to('committee');
            }
        }

        echo view('templates/header', $data);
        echo view('templates/sidebar', $data);
        echo view('templates/topbar', $data);
        echo view('circular/circular_committee', $data);
        echo view('templates/footer');
    }

    public function detail($id)
    {
        is_logged_in();
        $data = $this->userModel->getUser()->getRowArray();
        $data['circular'] = $this->circularModel->getDetail($id)->getRowArray();
        $data['title'] = 'Detail Circular Resolution';

        echo view('templates/header', $data);
        echo view('templates/sidebar', $data);
        echo view('templates/topbar', $data);
        echo view('circular/circular_detail', $data);
        echo view('templates/footer');
    }

    public function editbod($id)
    {
        is_logged_in();
        $data = $this->userModel->getUser()->getRowArray();
        $data['circular'] = $this->circularModel->getDetail($id)->getRowArray();
        $data['title'] = 'Ubah Data';

        if ($this->request->getMethod() == 'post') {
            $rules = [
                'subject'     => 'required|trim|max_length[128]',
                'description' => 'required|trim|max_length[128]',
                'workingunit' => 'required',
                'pic'         => 'required',
                'date'        => 'required',
                'attachment'  => 'required'
            ];

            if (!$this->validate($rules)) {
                $data['validation'] = $this->validator;
            } else {
                $updateData = [
                    'circular_date' => date('Y-m-d', strtotime($this->request->getVar('date'))),
                    'subject'       => $this->request->getVar('subject'),
                    'workingunit_name'   => $this->request->getVar('workingunit'),
                    'pic_name'      => $this->request->getVar('pic'),
                    'description'   => $this->request->getVar('description'),
                    'attachment'    => $this->request->getVar('attachment'),
                    'category_id'   => 3,
                    'modifier_id'   => $data['id'],
                    'date_modified' => date('Y-m-d H:i:s')
                ];
                $db = db_connect();
                $db->table('tb_circular')->where('id', $id)->set($updateData)->update();
                $session = session();
                $session->setFlashdata('success', 'Data berhasil diperbarui!');
                return redirect()->to(site_url('circular/bod'));
            }
        }
        echo view('templates/header', $data);
        echo view('templates/sidebar', $data);
        echo view('templates/topbar', $data);
        echo view('circular/circular_edit', $data);
        echo view('templates/footer');
    }

    public function editboc($id)
    {
        is_logged_in();
        $data = $this->userModel->getUser()->getRowArray();
        $data['circular'] = $this->circularModel->getDetail($id)->getRowArray();
        $data['title'] = 'Ubah Data';

        if ($this->request->getMethod() == 'post') {
            $rules = [
                'subject'     => 'required|trim|max_length[128]',
                'description' => 'required|trim|max_length[128]',
                'workingunit' => 'required',
                'pic'         => 'required',
                'date'        => 'required',
                'attachment'  => 'required'
            ];

            if (!$this->validate($rules)) {
                $data['validation'] = $this->validator;
            } else {
                $updateData = [
                    'circular_date' => date('Y-m-d', strtotime($this->request->getVar('date'))),
                    'subject'       => $this->request->getVar('subject'),
                    'workingunit_name'   => $this->request->getVar('workingunit'),
                    'pic_name'      => $this->request->getVar('pic'),
                    'description'   => $this->request->getVar('description'),
                    'attachment'    => $this->request->getVar('attachment'),
                    'category_id'   => 4,
                    'modifier_id'   => $data['id'],
                    'date_modified' => date('Y-m-d H:i:s')
                ];
                $db = db_connect();
                $db->table('tb_circular')->where('id', $id)->set($updateData)->update();
                $session = session();
                $session->setFlashdata('success', 'Data berhasil diperbarui!');
                return redirect()->to(site_url('circular/boc'));
            }
        }
        echo view('templates/header', $data);
        echo view('templates/sidebar', $data);
        echo view('templates/topbar', $data);
        echo view('circular/circular_edit', $data);
        echo view('templates/footer');
    }

    public function editcom($id)
    {
        is_logged_in();
        $data = $this->userModel->getUser()->getRowArray();
        $data['circular'] = $this->circularModel->getDetail($id)->getRowArray();
        $data['committee'] = $this->circularModel->getCommittee()->getResultArray();
        $data['title'] = 'Ubah Data';

        if ($this->request->getMethod() == 'post') {
            $rules = [
                'subject'     => 'required|trim|max_length[128]',
                'description' => 'required|trim|max_length[128]',
                'workingunit' => 'required',
                'committee'   => 'required',
                'pic'         => 'required',
                'date'        => 'required',
                'attachment'  => 'required'
            ];

            if (!$this->validate($rules)) {
                $data['validation'] = $this->validator;
            } else {
                $updateData = [
                    'circular_date' => date('Y-m-d', strtotime($this->request->getVar('date'))),
                    'subject'       => $this->request->getVar('subject'),
                    'workingunit_name'   => $this->request->getVar('workingunit'),
                    'pic_name'      => $this->request->getVar('pic'),
                    'committee_id'  => $this->request->getVar('committee'),
                    'description'   => $this->request->getVar('description'),
                    'attachment'    => $this->request->getVar('attachment'),
                    'category_id'   => 5,
                    'modifier_id'   => $data['id'],
                    'date_modified' => date('Y-m-d H:i:s')
                ];
                $db = db_connect();
                $db->table('tb_circular')->where('id', $id)->set($updateData)->update();
                $session = session();
                $session->setFlashdata('success', 'Data berhasil diperbarui!');
                return redirect()->to(site_url('circular/committee'));
            }
        }
        echo view('templates/header', $data);
        echo view('templates/sidebar', $data);
        echo view('templates/topbar', $data);
        echo view('circular/circular_edit', $data);
        echo view('templates/footer');
    }

    public function deletebod($id)
    {
        $this->circularModel->getCircular()->where('id', $id)->delete();
        session()->setFlashdata('success', 'Delete success!');
        return redirect()->to(site_url('circular/bod'));
    }

    public function deleteboc($id)
    {
        $this->circularModel->getCircular()->where('id', $id)->delete();
        session()->setFlashdata('success', 'Delete success!');
        return redirect()->to(site_url('circular/boc'));
    }

    public function deletecom($id)
    {
        $this->circularModel->getCircular()->where('id', $id)->delete();
        session()->setFlashdata('success', 'Delete success!');
        return redirect()->to(site_url('circular/committee'));
    }
}
