<?php

namespace App\Controllers;

class User extends BaseController
{
	public function index()
	{
		$data = $this->userModel->getUser()->getRowArray();
		$data['title'] = 'Dashboard';

		echo view('templates/header', $data);
		echo view('templates/sidebar', $data);
		echo view('templates/topbar', $data);
		echo view('dashboard/user/index', $data);
		echo view('templates/footer');
	}

	public function profile()
	{
		$data = $this->userModel->getUser()->getRowArray();
		$data['user'] = $this->userModel->getUser()->getRowArray();
		$data['title'] = 'My Profile';

		echo view('templates/header', $data);
		echo view('templates/sidebar', $data);
		echo view('templates/topbar', $data);
		echo view('user/index', $data);
		echo view('templates/footer');
	}

	public function edit()
	{
		$data = $this->userModel->getUser()->getRowArray();
		$data['title'] = 'Edit Profile';

		if ($this->request->getMethod() == 'post') {
			$rules = [
				'name'   => 'required|trim|max_length[30]',
				'image'  => 'max_size[image,1024]'
			];

			if (!$this->validate($rules)) {
				$data['validation'] = $this->validator;
			} else {
				$email = $this->request->getPost('email');
				$name = $this->request->getPost('name');
				// Upload Image
				$upload_image = $this->request->getFile('image');
				// Untuk mengetahui nama
				$imageName = $upload_image->getName();

				if ($upload_image->isValid() && !$upload_image->hasMoved()) {
					$old_image = $data['image'];
					if ($old_image != 'default.png') {
						unlink(FCPATH . 'assets/img/profile/' . $old_image);
					}
					// Pindah ke folder
					$upload_image->move('./assets/img/profile/');
				}

				$updateData = [
					'name'  => $name,
					'image' => $imageName
				];

				$this->userModel->set($updateData)->where('email', $email)->update();
				session()->setFlashdata('success', 'Your profile has been updated!');
				return redirect()->to(site_url('user'));
			}
		}
		echo view('templates/header', $data);
		echo view('templates/sidebar', $data);
		echo view('templates/topbar', $data);
		echo view('user/edit', $data);
		echo view('templates/footer');
	}

	public function changePassword()
	{
		$data = $this->userModel->getUser()->getRowArray();
		$data['title'] = 'Change Password';

		if ($this->request->getMethod() == 'post') {
			$rules = [
				'current_password' => [
					'label'  => 'Current password',
					'rules'  => 'required',
					'errors' => [
						'required' => '{field} is required.'
					]
				],
				'new_password1' => [
					'label'  => 'New password',
					'rules'  => 'required|min_length[3]|matches[new_password2]',
					'errors' => [
						'required' => '{field} is required.'
					]
				],
				'new_password2' => [
					'label'  => 'Confirmation password',
					'rules'  => 'required|min_length[3]|matches[new_password2]',
					'errors' => [
						'required' => '{field} is required.'
					]
				]
			];

			if (!$this->validate($rules)) {
				$data['validation'] = $this->validator;
			} else {
				$password = [
					'current_password' => $this->request->getVar('current_password'),
					'new_password'	   => $this->request->getVar('new_password1')
				];
				if (!password_verify($password['current_password'], $data['password'])) {
					session()->setFlashdata('failed', 'Wrong current password.');
					return redirect()->to('changepassword');
				} else {
					if ($password['current_password'] == $password['new_password']) {
						session()->setFlashdata('failed', 'New password cannot be the same as current password.');
						return redirect()->to('changepassword');
					} else {
						// PASSWORD VALID
						$this->userModel->set('password', $password['new_password'])->where('email', session()->get('email'))->update();
						session()->setFlashdata('success', 'Password changed.');
						return redirect()->to('changepassword');
					}
				}
			}
		}
		echo view('templates/header', $data);
		echo view('templates/sidebar', $data);
		echo view('templates/topbar', $data);
		echo view('user/changepassword', $data);
		echo view('templates/footer');
	}
}
