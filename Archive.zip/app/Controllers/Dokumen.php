<?php

namespace App\Controllers;

class Dokumen extends BaseController
{
    public function pemindahan()
    {
        // HELPER START
        $role_id = session()->get('role_id');
        $menu =  $this->request->uri->getSegment(1);
        // QUERY TABLE USER_MENU
        $queryMenu = $this->menuModel->where(['menu' => $menu])->get()->getRowArray();
        $menu_id = $queryMenu['id'];
        // QUERY TABLE USER_ACCESS_MENU
        $userAccess = $this->accessModel->where(['role_id' => $role_id, 'menu_id' => $menu_id])->get()->getRowArray();

        if ($userAccess == null) {
            return redirect()->to(site_url('auth/error'));
        }
        // END OF HELPER

        // START PEMINDAHAN
        $data = $this->userModel->getUser()->getRowArray();
        if ($data['role_id'] <= 3) {
            $data['pemindahan'] = $this->documentModel->getListPemindahan()->get()->getResultArray();
        } else {
            $data['pemindahan'] = $this->documentModel->getListPemindahan()->where('working_unit_id', session()->get('working_unit_id'))->get()->getResultArray();
        }
        $data['recordcenter'] = $this->documentModel->getRecordCenter()->getResultArray();
        $data['title'] = 'Pemindahan';

        if ($this->request->getMethod() == 'post') {
            $rules = [
                'desc'         => 'required|trim|max_length[128]',
                'recordcenter' => 'required'
            ];

            if (!$this->validate($rules)) {
                $data['validation'] = $this->validator;
            } else {
                $prefix = 'No.' . 'DPDI.' . date('Y') . '.';
                $lastBox = $this->documentModel->getFeedingNumberMax($prefix)->get()->getRowArray();
                // Get last 5 number
                $feedingNumber = (int) substr($lastBox['feeding_number'], -3, 3);
                // Add new box number
                $feedingNumber++;
                $newfeedingNumber = $prefix .  sprintf('%03s', $feedingNumber);

                $newData = [
                    'feeding_desc' => $this->request->getVar('desc'),
                    'feeding_date' => date('Y-m-d H:i:s'),
                    'creator_id'   => $data['id'],
                    'is_active'    => 1,
                    'recordcenter_id' => $this->request->getVar('recordcenter'),
                    'working_unit_id' => $data['working_unit_id'],
                    'feeding_number'  => $newfeedingNumber
                ];
                $db = db_connect();
                $db->table('document_feeding')->set($newData)->insert();
                $session = session();
                $session->setFlashdata('success', 'DPDI berhasil dibuat.');
                return redirect()->to('pemindahan');
            }
        }

        echo view('templates/header', $data);
        echo view('templates/sidebar', $data);
        echo view('templates/topbar', $data);
        echo view('dokumen/pemindahan/index', $data);
        echo view('templates/footer');
    }

    public function detailPemindahan($id)
    {
        $db = db_connect();
        $data = $this->userModel->getUser()->getRowArray();
        $data['dpdi'] = $this->documentModel->getPemindahanId($id)->getRowArray();
        $data['pemindahan'] = $this->documentModel->getPemindahan()->get()->getResultArray();
        $data['klasifikasi'] = $db->table('document_classification')->get()->getResultArray();
        $data['referensi'] = $this->masterModel->getReference()->getResultArray();
        $data['detail'] = $this->documentModel->getDocumentDetail($id)->get()->getResultArray();
        $data['title'] = 'Detail DPDI';


        echo view('templates/header', $data);
        echo view('templates/sidebar', $data);
        echo view('templates/topbar', $data);
        echo view('dokumen/pemindahan/detailpemindahan', $data);
        echo view('templates/footer');
    }

    public function editpemindahan($id)
    {
        $data = $this->userModel->getUser()->getRowArray();
        $data['pemindahan'] = $this->documentModel->updatePemindahan($id)->get()->getRowArray();
        $data['recordcenter'] = $this->documentModel->getRecordCenter()->getResultArray();
        $data['title'] = 'Edit Pemindahan';

        if ($this->request->getMethod() == 'post') {
            $rules = [
                'desc'         => 'required|trim|max_length[128]'
            ];

            if (!$this->validate($rules)) {
                $data['validation'] = $this->validator;
            } else {
                $update = [
                    'feeding_desc'  => $this->request->getVar('desc'),
                    'date_modified' => date('Y-m-d H:i:s'),
                    'modifier_id'   => $data['id']
                ];
                $db = db_connect();
                $db->table('document_feeding')->where('id', $id)->set($update)->update();
                $session = session();
                $session->setFlashdata('success', 'DPDI berhasil diperbarui.');
                return redirect()->to(site_url('dokumen/pemindahan'));
            }
        }
        echo view('templates/header', $data);
        echo view('templates/sidebar', $data);
        echo view('templates/topbar', $data);
        echo view('dokumen/pemindahan/editpemindahan', $data);
        echo view('templates/footer');
    }

    public function deletePemindahan($id)
    {
        $this->documentModel->deletePemindahan()->where('id', $id)->delete();
        session()->setFlashdata('success', 'Delete success!');
        return redirect()->to(site_url('dokumen/pemindahan'));
    }

    public function dpdi($id)
    {
        is_logged_in();
        $data = $this->userModel->getUser()->getRowArray();
        $data['dpdi'] = $this->documentModel->getPemindahanId($id)->getRowArray();
        $data['pemindahan'] = $this->documentModel->getPemindahan()->get()->getResultArray();
        $data['klasifikasi'] = $this->documentModel->getClassification()->get()->getResultArray();
        $data['detail'] = $this->documentModel->getDocumentDetail($id)->get()->getResultArray();
        // Get Total Retention
        $total = $this->request->getVar('retention_name');
        $data['total'] = $this->documentModel->getClassificationSchedule($total)->get()->getRowArray();

        if ($this->request->getVar('pencarian')) {
            $data['detail'] = $this->documentModel->searchDetailDpdi($id)->get()->getResultArray();
        }
        $data['title'] = 'Detail DPDI';

        if ($this->request->getMethod() == 'post') {
            $rules = [
                'klasifikasi'     => 'required|trim|max_length[256]',
                'retention_id'    => 'required|trim|max_length[256]',
                'retention_name'  => 'required|trim|max_length[256]',
                'deskripsi'       => 'required|trim|max_length[256]',
                'awal'            => 'required',
                'akhir'           => 'required'
            ];

            if (!$this->validate($rules)) {
                $data['validation'] = $this->validator;
            } else {

                // AUTO DOC ID
                $prefixId = sprintf('%03s', $data['dpdi']['recordcenter_id']) . '-' . date('Ym') . '-';
                $lastDocId = $this->documentModel->getDocumentIdMax($prefixId)->get()->getRowArray();
                // Get last 5 number
                $documentNumber = (int) substr($lastDocId['doc_id'], -7, 11);
                // Add new DOC ID
                $documentNumber++;
                // $newdocumentNumber = sprintf('%03s', $recordCenter) . '-' . $prefixId .  sprintf('%07s', $documentNumber);
                $newdocumentNumber = $prefixId .  sprintf('%07s', $documentNumber);
                // END AUTO DOC ID

                // AUTO BOX NUMBER
                $prefix = date('Y') . '-';
                $lastBox = $this->documentModel->getBoxNumberMax($prefix)->where('document_detail.working_unit_id', $data['dpdi']['working_unit_id'])->get()->getRowArray();
                // Get last 5 number
                $nomorBox = (int) substr($lastBox['box_number'], -5, 5);
                // Add new box number
                $nomorBox++;
                $newNomorBox = $prefix .  sprintf('%05s', $nomorBox);
                // END AUTO BOX NUMBER

                $newData = [
                    // Kolom DB
                    'doc_id'            => $newdocumentNumber,
                    'classification_id'  => $this->request->getVar('klasifikasi'),
                    'retention_id'       => $this->request->getVar('retention_id'),
                    'retention_name'     => $this->request->getVar('retention_name'),
                    'document_desc'      => $this->request->getVar('deskripsi'),
                    'begin_period'       => date('Y-m-d', strtotime($this->request->getVar('awal'))),
                    'end_period'         => date('Y-m-d', strtotime($this->request->getVar('akhir'))),
                    'start_retention'    => date('Y', strtotime($this->request->getVar('akhir'))),
                    'retention_schedule' => $data['total']['total_retention'],
                    'destroy_schedule'   => (date('Y', strtotime($this->request->getVar('akhir'))) + $data['total']['total_retention'] + 1), // Ditambah 1 Tahun
                    'total_folder'       => $this->request->getVar('folder'),
                    'total_map'          => $this->request->getVar('map'),
                    'total_bundle'       => $this->request->getVar('bundle'),
                    'total_other'        => $this->request->getVar('other'),
                    'recordcenter_id'    => $data['dpdi']['recordcenter_id'],
                    'working_unit_id'    => $data['dpdi']['working_unit_id'],
                    'box_number'    => $newNomorBox,
                    'feeding_id'    => $data['dpdi']['id'],
                    'pic_id'        => $data['id'],
                    'creator_id'    => $data['id'],
                    'feeding_date'  => date('Y-m-d H:i:s'),
                    'documentstatus_id' => 1
                ];
                $this->documentModel->insertDocument()->insert($newData);
                session()->setFlashdata('success', 'Berhasil menambahkan data.');
                return redirect()->to(site_url('dokumen/dpdi/' . $data['dpdi']['id']));
            }
        }
        echo view('templates/header', $data);
        echo view('templates/sidebar', $data);
        echo view('templates/topbar', $data);
        echo view('dokumen/pemindahan/dpdi', $data);
        echo view('templates/footer');
    }
    // Chain Dropdown Retention Code
    public function get_retention_code()
    {
        $code = $this->request->getVar('id');
        $data = $this->documentModel->getClassificationCode($code)->get()->getResultArray();
        echo json_encode($data);
    }
    // Chain Dropdown Retention Name
    public function get_retention_name()
    {
        $name = $this->request->getVar('id');
        $data = $this->documentModel->getClassificationName($name)->get()->getResultArray();
        echo json_encode($data);
    }

    public function detailDpdi($id)
    {
        is_logged_in();
        $data = $this->userModel->getUser()->getRowArray();
        $data['detail'] = $this->dataModel->getDetail($id)->get()->getRowArray();
        $data['title'] = 'Data Dokumen';

        echo view('templates/header', $data);
        echo view('templates/sidebar', $data);
        echo view('templates/topbar', $data);
        echo view('dokumen/pemindahan/detail', $data);
        echo view('templates/footer');
    }

    public function editdpdi($id)
    {
        is_logged_in();
        $data = $this->userModel->getUser()->getRowArray();
        $data['dpdi'] = $this->documentModel->updateDocument($id)->getRowArray();
        $data['pemindahan'] = $this->documentModel->getPemindahanId($id)->getRowArray();
        $data['klasifikasi'] = $this->documentModel->getClassification()->get()->getResultArray();
        $data['detail'] = $this->documentModel->getDocumentDetail($id)->get()->getResultArray();
        // Get Total Retention
        $total = $this->request->getVar('retention_name');
        $data['total'] = $this->documentModel->getClassificationSchedule($total)->get()->getRowArray();
        $data['title'] = 'Edit DPDI';

        if ($this->request->getMethod() == 'post') {
            $rules = [
                'klasifikasi'     => 'required|trim|max_length[256]',
                'retention_id'    => 'required|trim|max_length[256]',
                'retention_name'  => 'required|trim|max_length[256]',
                'deskripsi'       => 'required|trim|max_length[256]',
                'awal'            => 'required',
                'akhir'           => 'required'
            ];

            if (!$this->validate($rules)) {
                $data['validation'] = $this->validator;
            } else {

                $updateData = [
                    // Kolom DB
                    'classification_id'  => $this->request->getVar('klasifikasi'),
                    'retention_id'       => $this->request->getVar('retention_id'),
                    'retention_name'     => $this->request->getVar('retention_name'),
                    'document_desc'      => $this->request->getVar('deskripsi'),
                    'begin_period'       => date('Y-m-d', strtotime($this->request->getVar('awal'))),
                    'end_period'         => date('Y-m-d', strtotime($this->request->getVar('akhir'))),
                    'start_retention'    => date('Y', strtotime($this->request->getVar('akhir'))),
                    'retention_schedule' => $data['total']['total_retention'],
                    'destroy_schedule'   => (date('Y', strtotime($this->request->getVar('akhir'))) + $data['total']['total_retention'] + 1), // Ditambah 1 Tahun
                    'total_folder'       => $this->request->getVar('folder'),
                    'total_map'          => $this->request->getVar('map'),
                    'total_bundle'       => $this->request->getVar('bundle'),
                    'total_other'        => $this->request->getVar('other'),
                    'recordcenter_id'    => $data['dpdi']['recordcenter_id'],
                    'working_unit_id'    => $data['dpdi']['working_unit_id'],
                    'pic_id'        => $data['id'],
                    'modifier_id'   => $data['id'],
                    'date_modified' => date('Y-m-d H:i:s')
                ];
                $db = db_connect();
                $db->table('document_detail')->where('doc_id', $id)->set($updateData)->update();
                session()->setFlashdata('success', 'Berhasil memperbarui data.');
                return redirect()->to(site_url('dokumen/dpdi/' . $data['dpdi']['feeding_id']));
            }
        }
        echo view('templates/header', $data);
        echo view('templates/sidebar', $data);
        echo view('templates/topbar', $data);
        echo view('dokumen/pemindahan/editdpdi', $data);
        echo view('templates/footer');
    }

    public function submitDpdi($id)
    {
        $db = db_connect();
        $data = $this->userModel->getUser()->getRowArray();
        $data['dpdi'] = $this->documentModel->getPemindahanId($id)->getRowArray();
        $data['pemindahan'] = $this->documentModel->getPemindahan()->get()->getResultArray();
        $data['klasifikasi'] = $db->table('document_classification')->get()->getResultArray();
        $data['referensi'] = $this->masterModel->getReference()->getResultArray();
        $data['detail'] = $this->documentModel->getDocumentDetail($id)->get()->getResultArray();
        $data['title'] = 'Detail';

        $update = [
            // Kolom DB
            'modifier_id'    => $data['id'],
            'date_modified'  => date('Y-m-d H:i:s'),
            'is_active' => 3
        ];
        $db = db_connect();
        $db->table('document_feeding')->where('id', $id)->set($update)->update();
        session()->setFlashdata('success', 'Berhasil disimpan. Menunggu persetujuan atasan.');
        return redirect()->to(site_url('dokumen/pemindahan'));
    }

    public function persetujuan()
    {
        // HELPER START
        $role_id = session()->get('role_id');
        if ($role_id <= 5) {
            $data = $this->userModel->getUser()->getRowArray();
            if ($data['role_id'] <= 3) {
                $data['pemindahan'] = $this->documentModel->getPersetujuan()->get()->getResultArray();
            } else {
                $data['pemindahan'] = $this->documentModel->getPersetujuan()->where('working_unit_id', session()->get('working_unit_id'))->get()->getResultArray();
            }
            $data['recordcenter'] = $this->documentModel->getRecordCenter()->getResultArray();
            $data['title'] = 'Persetujuan';

            if ($this->request->getMethod() == 'post') {
                $rules = [
                    'desc'         => 'required|trim|max_length[128]',
                    'recordcenter' => 'required'
                ];

                if (!$this->validate($rules)) {
                    $data['validation'] = $this->validator;
                } else {
                    $newData = [
                        'feeding_desc' => $this->request->getVar('desc'),
                        'feeding_date' => date('Y-m-d H:i:s'),
                        'creator_id'   => $data['id'],
                        'is_active'    => 1,
                        'recordcenter_id' => $this->request->getVar('recordcenter'),
                        'working_unit_id' => $data['working_unit_id'],
                    ];
                    $db = db_connect();
                    $db->table('document_feeding')->set($newData)->insert();
                    $session = session();
                    $session->setFlashdata('success', 'DPDI berhasil dibuat.');
                    return redirect()->to('pemindahan');
                }
            }

            echo view('templates/header', $data);
            echo view('templates/sidebar', $data);
            echo view('templates/topbar', $data);
            echo view('dokumen/pemindahan/persetujuan/index', $data);
            echo view('templates/footer');
        } else {
            return redirect()->to(site_url('auth/error'));
        }
    }

    public function approveDpdi($id)
    {
        // HELPER START
        $role_id = session()->get('role_id');
        if ($role_id <= 5) {
            $data = $this->userModel->getUser()->getRowArray();
            $data['pemindahan'] = $this->documentModel->getPemindahan()->where('document_feeding.id', $id)->get()->getRowArray();
            $update = [
                'approver_id'  => $data['id'],
                'is_active'    => 4
            ];
            $db = db_connect();
            $db->table('document_feeding')->set($update)->where('id', $id)->update();
            $session = session();
            $session->setFlashdata('success', 'DPDI telah disetujui.');
            return redirect()->to(site_url('dokumen/persetujuan'));
        } else {
            return redirect()->to(site_url('auth/error'));
        }
    }

    public function revisiDpdi($id)
    {
        // HELPER START
        $role_id = session()->get('role_id');
        if ($role_id <= 5) {
            $data = $this->userModel->getUser()->getRowArray();
            $data['dpdi'] = $this->documentModel->getPemindahanId($id)->getRowArray();
            $data['pemindahan'] = $this->documentModel->getPemindahan()->get()->getResultArray();
            $update = [
                'modifier_id'  => $data['id'],
                'is_active'    => 2
            ];
            $db = db_connect();
            $db->table('document_feeding')->set($update)->where('id', $id)->update();
            $session = session();
            $session->setFlashdata('warning', 'Permintaan revisi DPDI berhasil.');
            return redirect()->to(site_url('dokumen/persetujuan'));
        } else {
            return redirect()->to(site_url('auth/error'));
        }
    }

    public function prosesPemindahan($id)
    {
        $data = $this->userModel->getUser()->getRowArray();
        $data['dpdi'] = $this->documentModel->getPemindahanId($id)->getRowArray();
        $data['pemindahan'] = $this->documentModel->getPemindahan()->get()->getResultArray();
        $data['title'] = 'Proses Pemindahan';
        $session = session();

        if ($this->request->getMethod() == 'post') {
            $rules = ([
                'fpdi' => [
                    'label' => 'FPDI',
                    'rules' => 'ext_in[fpdi,pdf]|max_size[fpdi,2048]'
                ]
            ]);
            if (!$this->validate($rules)) {
                $data['validation'] = $this->validator;
            } else {
                // Upload Image
                $fpdi = $this->request->getFile('fpdi');
                // Untuk mengetahui nama
                $file = $fpdi->getName();
                if (!$fpdi->isValid()) {
                    throw new RuntimeException($fpdi->getErrorString() . '(' . $fpdi->getError() . ')');
                } else {
                    // Pindah ke folder
                    $fpdi->move('./assets/files/fpdi/');
                }

                $update = [
                    // Coloumn DB
                    'attachment' => $file,
                    'is_active'  => 9
                ];
                $db = db_connect();
                $db->table('document_feeding')->where('id', $id)->set($update)->update();
                $session->setFlashdata('success', 'Silahkan kirimkan dokumen yang telah anda input.');
                return redirect()->to(site_url('dokumen/pemindahan'));
            }
        }
        echo view('templates/header', $data);
        echo view('templates/sidebar', $data);
        echo view('templates/topbar', $data);
        echo view('dokumen/pemindahan/prosesdpdi', $data);
        echo view('templates/footer');
    }

    public function FeedingReport($id)
    {
    }
}
