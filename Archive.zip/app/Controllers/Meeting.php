<?php

namespace App\Controllers;

class Meeting extends BaseController
{
    public function index()
    {
        echo 'Hello Meeting';
    }

    public function bod()
    {
        is_logged_in();
        $data = $this->userModel->getUser()->getRowArray();
        // $data['meeting'] = $this->meetingModel->getBodMeeting()->get()->getResultArray();
        $data['year'] = $this->meetingModel->getYearBod()->get()->getResultArray();
        $data['session'] = ['uri' => $this->request->uri->getSegment(2)];
        $data['title'] = 'Minutes of Meeting BOD';
        // $data['pager'] = $this->meetingModel->pager;
        session()->set($data['session']);

        if ($this->request->getMethod() == 'post') {
            $rules = [
                'number'     => 'required|trim|is_unique[tb_meeting.number]',
                'agenda'     => 'required|trim|max_length[128]',
                'date'       => 'required',
                'attachment' => 'required'
            ];

            if (!$this->validate($rules)) {
                $data['validation'] = $this->validator;
            } else {
                $newData = [
                    'number'       => $this->request->getVar('number'),
                    'agenda'       => $this->request->getVar('agenda'),
                    'meeting_date' => date('Y-m-d', strtotime($this->request->getVar('date'))),
                    'year'         => date('Y', strtotime($this->request->getVar('date'))),
                    'attachment'   => $this->request->getVar('attachment'),
                    'category_id'  => 1,
                    'creator_id'   => $data['id'],
                    'date_created' => date('Y-m-d H:i:s')
                ];
                $db = db_connect();
                $db->table('tb_meeting')->set($newData)->insert();
                $session = session();
                $session->setFlashdata('success', 'Data berhasil ditambahkan!');
                return redirect()->to('bod');
            }
        }

        echo view('templates/header', $data);
        echo view('templates/sidebar', $data);
        echo view('templates/topbar', $data);
        echo view('meeting/mom_bod', $data);
        echo view('templates/footer');
    }

    public function boc()
    {
        is_logged_in();
        $data = $this->userModel->getUser()->getRowArray();
        // $data['meeting'] = $this->meetingModel->getBocMeeting()->get()->getResultArray();
        $data['year'] = $this->meetingModel->getYearBoc()->get()->getResultArray();
        $data['session'] = ['uri' => $this->request->uri->getSegment(2)];
        $data['title'] = 'Minutes of Meeting BOC';
        session()->set($data['session']);

        if ($this->request->getMethod() == 'post') {
            $rules = [
                'number'     => 'required|trim|is_unique[tb_meeting.number]',
                'agenda'     => 'required|trim|max_length[128]',
                'date'       => 'required',
                'attachment' => 'required'
            ];

            if (!$this->validate($rules)) {
                $data['validation'] = $this->validator;
            } else {
                $newData = [
                    'number'       => $this->request->getVar('number'),
                    'agenda'       => $this->request->getVar('agenda'),
                    'meeting_date' => date('Y-m-d', strtotime($this->request->getVar('date'))),
                    'year'         => date('Y', strtotime($this->request->getVar('date'))),
                    'attachment'   => $this->request->getVar('attachment'),
                    'category_id'  => 2,
                    'creator_id'   => $data['id'],
                    'date_created' => date('Y-m-d H:i:s')
                ];
                $db = db_connect();
                $db->table('tb_meeting')->set($newData)->insert();
                $session = session();
                $session->setFlashdata('success', 'Data berhasil ditambahkan!');
                return redirect()->to('boc');
            }
        }

        echo view('templates/header', $data);
        echo view('templates/sidebar', $data);
        echo view('templates/topbar', $data);
        echo view('meeting/mom_boc', $data);
        echo view('templates/footer');
    }

    public function detail($id)
    {
        is_logged_in();
        $data = $this->userModel->getUser()->getRowArray();
        $data['meeting'] = $this->meetingModel->getDetail($id)->getRowArray();
        $data['title'] = 'Detail Minutes of Meeting';

        echo view('templates/header', $data);
        echo view('templates/sidebar', $data);
        echo view('templates/topbar', $data);
        echo view('meeting/mom_detail', $data);
        echo view('templates/footer');
    }

    public function editbod($id)
    {
        is_logged_in();
        $data = $this->userModel->getUser()->getRowArray();
        $data['meeting'] = $this->meetingModel->getDetail($id)->getRowArray();
        $data['title'] = 'Ubah Data';

        if ($this->request->getMethod() == 'post') {
            $rules = [
                'number'     => 'required|trim',
                'agenda'     => 'required|trim|max_length[128]',
                'date'       => 'required',
                'attachment' => 'required'
            ];

            if (!$this->validate($rules)) {
                $data['validation'] = $this->validator;
            } else {
                $updateData = [
                    'number'       => $this->request->getVar('number'),
                    'agenda'       => $this->request->getVar('agenda'),
                    'meeting_date' => date('Y-m-d', strtotime($this->request->getVar('date'))),
                    'year'         => date('Y', strtotime($this->request->getVar('date'))),
                    'attachment'   => $this->request->getVar('attachment'),
                    'modifier_id'   => $data['id'],
                    'date_modified' => date('Y-m-d H:i:s')
                ];
                $db = db_connect();
                $db->table('tb_meeting')->where('id', $id)->set($updateData)->update();
                $session = session();
                $session->setFlashdata('success', 'Data berhasil diperbarui!');
                return redirect()->to(site_url('meeting/bod'));
            }
        }

        echo view('templates/header', $data);
        echo view('templates/sidebar', $data);
        echo view('templates/topbar', $data);
        echo view('meeting/mom_edit', $data);
        echo view('templates/footer');
    }

    public function editboc($id)
    {
        is_logged_in();
        $data = $this->userModel->getUser()->getRowArray();
        $data['meeting'] = $this->meetingModel->getDetail($id)->getRowArray();
        $data['title'] = 'Ubah Data';

        if ($this->request->getMethod() == 'post') {
            $rules = [
                'number'     => 'required|trim',
                'agenda'     => 'required|trim|max_length[128]',
                'date'       => 'required',
                'attachment' => 'required'
            ];

            if (!$this->validate($rules)) {
                $data['validation'] = $this->validator;
            } else {
                $updateData = [
                    'number'       => $this->request->getVar('number'),
                    'agenda'       => $this->request->getVar('agenda'),
                    'meeting_date' => date('Y-m-d', strtotime($this->request->getVar('date'))),
                    'year'         => date('Y', strtotime($this->request->getVar('date'))),
                    'attachment'   => $this->request->getVar('attachment'),
                    'modifier_id'   => $data['id'],
                    'date_modified' => date('Y-m-d H:i:s')
                ];
                $db = db_connect();
                $db->table('tb_meeting')->where('id', $id)->set($updateData)->update();
                $session = session();
                $session->setFlashdata('success', 'Data berhasil diperbarui!');
                return redirect()->to(site_url('meeting/boc'));
            }
        }
        echo view('templates/header', $data);
        echo view('templates/sidebar', $data);
        echo view('templates/topbar', $data);
        echo view('meeting/mom_edit', $data);
        echo view('templates/footer');
    }

    public function deletebod($id)
    {
        $this->meetingModel->getMeeting()->where('id', $id)->delete();
        session()->setFlashdata('success', 'Delete success!');
        return redirect()->to(site_url('meeting/bod'));
    }

    public function deleteboc($id)
    {
        $this->meetingModel->getMeeting()->where('id', $id)->delete();
        session()->setFlashdata('success', 'Delete success!');
        return redirect()->to(site_url('meeting/boc'));
    }

    public function pagination()
    {
        $data['pager'] = $this->meetingModel->pager;
        $data['pager']->links();
    }

    public function filterTable()
    {
        $data = $this->userModel->getUser()->getRowArray();
        $year = $this->request->getVar('year');
        $uri = session()->get('uri');
        if ($year == 0) {
            if ($uri == 'bod') {
                // $data['meeting'] = $this->meetingModel->getBodMeeting()->get()->getResultArray();
                $data['meeting'] = $this->meetingModel->asArray()
                    ->join('tb_category', 'tb_category.id = tb_meeting.category_id')
                    ->where('category_id = 1')->paginate(10);
                // $data['pager'] = $this->meetingModel->pager;
                // dd($data['pager']);
            } else {
                $data['meeting'] = $this->meetingModel->getBocMeeting()->get()->getResultArray();
            }
        } else {
            if ($uri == 'bod') {
                $data['meeting'] = $this->meetingModel->getBodMeeting()->where('year', $year)->get()->getResultArray();
            } else {
                $data['meeting'] = $this->meetingModel->getBocMeeting()->where('year', $year)->get()->getResultArray();
            }
        }
        if (!empty($data['meeting'])) {
            $i = 1;
            foreach ($data['meeting'] as $m) : ?>
                <tr>
                    <td scope="row"><?= $i++ ?></td>
                    <td style="text-align: center;"><?= $m['number']; ?></td>
                    <td style="text-align: center;"><?= $m['agenda']; ?></td>
                    <td style="text-align: center;"><?= $m['meeting_date']; ?></td>
                    <td style="text-align: center;">
                        <?php if ($data['role_id'] <= 3) : ?>
                            <a href="<?= site_url('meeting/editbod/'); ?><?= $m['id'] ?>" class="badge badge-warning">edit</a>
                            <a href="<?= site_url('meeting/detail/'); ?><?= $m['id'] ?>" class="badge badge-info">detail</a>
                            <a href="<?= site_url('meeting/deletebod/'); ?><?= $m['id'] ?>" class="badge badge-danger" onclick="return confirm('Data akan dihapus. Apakah anda yakin?')">delete</a>
                        <?php else : ?>
                            <a href="<?= site_url('meeting/detail/'); ?><?= $m['id'] ?>" class="badge badge-info">detail</a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?> <?php
                                } else { ?>
            <tr>
                <td colspan="5" class="alert-danger" align="center">Data tidak ditemukan</td>
            </tr>
<?php
                                }
                            }
                        }
