<!-- Begin Page Content -->
<div class="container-fluid">

    <h1 class="h3 mb-4 text-gray-800"><?= $title ?></h1>

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= base_url('dashboard') ?>">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="<?= base_url('circular') ?>">Circular</a></li>
            <li class="breadcrumb-item active" aria-current="page"><?= $title ?></li>
        </ol>
    </nav>
    <!-- Page Heading -->

    <?php if (session()->get('success')) : ?>
        <div class="alert alert-success col-md-6" role="alert">
            <?= session()->get('success') ?>
        </div>
    <?php endif; ?>

    <?php if (isset($validation)) : ?>
        <div class="alert alert-danger" role="alert">
            <?= $validation->listErrors() ?>
        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header">
            Edit Circular Resolution
        </div>
        <div class="card-body">
            <form action="" method="post">
                <input type="hidden" name="id" value="<?= $circular['id'] ?>">
                <?php if ($circular['category_id'] == 5) : ?>
                    <div class="row">
                        <div class="col-xs-12 col-sm-4">
                            <div class="form-group">
                                <label for="number">Nomor</label>
                                <input type="text" class="form-control" name="number" id="number" value="<?= $circular['number'] ?>" readonly>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-4">
                            <div class="form-group">
                                <label for="committee">Komite</label>
                                <select name="committee" id="committee" class="form-control font-weight-lighter">
                                    <?php foreach ($committee as $c)
                                        if ($circular['committee_id'] == $c['id']) {
                                            echo "<option selected ='selected' value=" . $c['id'] . ">" . $c['committee'] . "</option>";
                                        } else {
                                            echo "<option value=" . $c['id'] . ">" . $c['committee'] . "</option>";
                                        }
                                    ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-4">
                            <div class="form-group">
                                <label for="date">Tanggal Circular</label>
                                <input type="text" class="form-control" name="date" id="date" data-toggle="datepicker" value="<?= $circular['circular_date'] ?>" readonly>
                            </div>
                        </div>
                    </div>
                <?php else : ?>
                    <div class="row">
                        <div class="col-xs-12 col-sm-6">
                            <div class="form-group">
                                <label for="number">Nomor</label>
                                <input type="text" class="form-control" name="number" id="number" value="<?= $circular['number'] ?>" readonly>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-6">
                            <div class="form-group">
                                <label for="date">Tanggal Circular</label>
                                <input type="text" class="form-control" name="date" id="date" data-toggle="datepicker" value="<?= $circular['circular_date'] ?>" readonly>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                <div class="form-group">
                    <label for="subject">Perihal</label>
                    <textarea class="form-control" id="subject" name="subject" rows="3"><?= $circular['subject'] ?></textarea>
                </div>
                <div class="row">
                    <div class="col-xs-12 col-sm-6">
                        <div class="form-group">
                            <label for="workingunit">Unit Kerja</label>
                            <input type="text" class="form-control" name="workingunit" id="workingunit" value="<?= $circular['workingunit_name'] ?>">
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-6">
                        <div class="form-group">
                            <label for="pic">Nama PIC</label>
                            <input type="text" class="form-control" name="pic" id="pic" value="<?= $circular['pic_name'] ?>">
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label for="description">Keterangan Lainnya</label>
                    <textarea class="form-control" id="description" name="description" rows="3"><?= $circular['description'] ?></textarea>
                </div>
                <div class="form-group">
                    <label for="attachment">Lampiran</label>
                    <input type="text" class="form-control" name="attachment" id="attachment" value="<?= $circular['attachment'] ?>">
                </div>
        </div>
        <div class="form-group ml-3">
            <button type="submit" class="btn btn-dark col-lg-2">Simpan</button>
            <button type="button" class="btn btn-danger col-lg-2" onclick="history.go(-1);">Kembali</button>
        </div>
        </form>
    </div>