<!-- Begin Page Content -->
<div class="container-fluid">

    <h1 class="h3 mb-4 text-gray-800"><?= $title ?></h1>

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= base_url('dashboard') ?>">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="<?= base_url('circular') ?>">Circular</a></li>
            <li class="breadcrumb-item active" aria-current="page"><?= $title ?></li>
        </ol>
    </nav>
    <!-- Page Heading -->

    <table class="table table-striped">
        <tbody>
            <tr>
                <th scope="row">Tanggal Sirkuler</th>
                <td><?= $circular['circular_date'] ?></td>
            </tr>
            <tr>
                <th scope="row">Kategori</th>
                <td><?= $circular['category'] ?></td>
            </tr>
            <?php if ($circular['category_id'] == 5) : ?>
                <tr>
                    <th scope="row">Komite</th>
                    <td><?= $circular['committee'] ?></td>
                </tr>
            <?php endif; ?>
            <tr>
                <th scope="row">Nomor Keputusan Resolusi</th>
                <td><?= $circular['number'] ?></td>
            </tr>
            <tr>
                <th scope="row">Perihal</th>
                <td><?= $circular['subject'] ?></td>
            </tr>
            <tr>
                <th scope="row">Unit Kerja Pengaju</th>
                <td><?= $circular['workingunit_name'] ?></td>
            </tr>
            <tr>
                <th scope="row">Nama PIC</th>
                <td><?= $circular['pic_name'] ?></td>
            </tr>
            <tr>
                <th scope="row">Keterangan Lainnya</th>
                <td><?= $circular['description'] ?></td>
            </tr>
            <tr>
                <th scope="row">Lampiran</th>
                <td><?= $circular['attachment'] ?></td>
            </tr>
        </tbody>
    </table>
    <button type="button" class="btn btn-dark col-lg-2" onclick="history.go(-1);">Kembali</button>

</div>
<!-- /.container-fluid -->