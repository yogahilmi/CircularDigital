<!-- Begin Page Content -->
<div class="container-fluid">

    <h1 class="h3 mb-4 text-gray-800">Circular <?= $title ?></h1>

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= base_url('dashboard') ?>">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="<?= base_url('dashboard') ?>">Circular</a></li>
            <li class="breadcrumb-item active" aria-current="page"><?= $title ?></li>
        </ol>
    </nav>

    <!-- Page Heading -->

    <?php if (session()->get('success')) : ?>
        <div class="alert alert-success col-md-6" role="alert">
            <?= session()->get('success') ?>
        </div>
    <?php endif; ?>

    <?php if (isset($validation)) : ?>
        <div class="alert alert-danger" role="alert">
            <?= $validation->listErrors() ?>
        </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-lg">

            <form>
                <?php if ($role_id <= 3) : ?>
                    <a href="" class="btn btn-dark" data-toggle="modal" data-target="#addModal">Tambah Data</a>
                <?php endif; ?>

                <!-- PENCARIAN DATA -->
                <div class="row float-right">
                    <div class="col-lg">
                        <div class="input-group mb-3">
                            <input type="text" class="form-control" name="pencarian" placeholder="Pencarian . . .">
                            <div class="input-group-append">
                                <button class="btn btn-dark" type="submit">
                                    <i class="fas fa-search"></i>
                                </button>
                            </div>
                        </div>
            </form>
        </div>
    </div>
    <!-- PENCARIAN DATA -->
    </form>
    <font size="2">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th style="text-align: center;" scope="col">Nomor Keputusan Resolusi</th>
                    <th style="text-align: center;" scope="col">Komite</th>
                    <th style="text-align: center;" scope="col">Perihal</th>
                    <th style="text-align: center;" scope="col">Unit Kerja & PIC</th>
                    <th style="text-align: center;" scope="col">Keterangan Lainnya</th>
                    <th style="text-align: center;" scope="col">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $i = 1 ?>
                <?php foreach ($circular as $c) : ?>
                    <tr>
                        <td scope="row"><?= $i ?></td>
                        <td style="text-align: center;"><?= $c['number']; ?></td>
                        <td style="text-align: center;"><?= $c['committee']; ?></td>
                        <td style="text-align: center;"><?= $c['subject']; ?></td>
                        <td style="text-align: center;">
                            <b><?= $c['workingunit_name']; ?></b></br><?= $c['pic_name']; ?>
                        </td>
                        <td style="text-align: center;"><?= $c['description']; ?></td>
                        <td style="text-align: center;">
                            <?php if ($role_id <= 3) : ?>
                                <a href="<?= site_url('circular/editcom/'); ?><?= $c['id'] ?>" class="badge badge-warning">edit</a>
                                <a href="<?= site_url('circular/detail/'); ?><?= $c['id'] ?>" class="badge badge-info">detail</a>
                                <a href="<?= site_url('circular/deletecom/'); ?><?= $c['id'] ?>" class="badge badge-danger" onclick="return confirm('Data akan dihapus. Apakah anda yakin?')">delete</a>
                            <?php else : ?>
                                <a href="<?= site_url('circular/detail/'); ?><?= $c['id'] ?>" class="badge badge-info">detail</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php $i++ ?>
                <?php endforeach ?>
            </tbody>
    </font>
    </table>
    <?php if (empty($circular)) : ?>
        <div class="alert alert-danger text-center" role="alert">
            Data tidak ditemukan.
        </div>
    <?php endif ?>
</div>
</div>

</div>
<!-- /.container-fluid -->


<!-- Tambah Data Modal -->
<div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="addModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="newSubmenuModalLabel">Tambah Data</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="<?= basename('circular/committee') ?>" method="POST">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-xs-12 col-sm-4">
                            <div class="form-group">
                                <label for="number">Nomor</label>
                                <input type="text" class="form-control font-weight-lighter" name="number" id="number" placeholder="Nomor sirkuler">
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-4">
                            <div class="form-group">
                                <label for="committee">Komite</label>
                                <select name="committee" id="committee" class="form-control font-weight-lighter">
                                    <option value="">Pilih Komite</option>
                                    <?php foreach ($committee as $c) : ?>
                                        <option value="<?= $c['id'] ?>"><?= $c['committee'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-4">
                            <div class="form-group">
                                <label for="date">Tanggal Circular</label>
                                <input type="text" class="form-control" name="date" id="date" data-toggle="datepicker" readonly>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="subject">Perihal</label>
                        <textarea class="form-control font-weight-lighter" id="subject" name="subject" rows="3" placeholder="Isi dengan perihal dari keputusan sirkuler."></textarea>
                    </div>
                    <div class="row">
                        <div class="col-xs-12 col-sm-6">
                            <div class="form-group">
                                <label for="workingunit">Unit Kerja</label>
                                <input type="text" class="form-control font-weight-lighter" name="workingunit" id="workingunit" placeholder="Unit Kerja Pengaju">
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-6">
                            <div class="form-group">
                                <label for="pic">Nama PIC</label>
                                <input type="text" class="form-control font-weight-lighter" name="pic" id="pic" placeholder="Nama PIC">
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="description">Keterangan Lainnya</label>
                        <textarea class="form-control font-weight-lighter" id="description" name="description" rows="3" placeholder="Isi dengan keterangan lainnya dari keputusan sirkuler."></textarea>
                    </div>
                    <div class="form-group">
                        <label for="attachment">Lampiran</label>
                        <input type="text" class="form-control" name="attachment" id="attachment" placeholder="Silahkan upload lampiran">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-dark">Simpan</button>
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
                </div>
            </form>
        </div>
    </div>
</div>