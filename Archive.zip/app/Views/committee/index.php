<!-- Begin Page Content -->
<div class="container-fluid">

    <h1 class="h3 mb-4 text-gray-800"><?= $title ?></h1>

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= base_url('dashboard') ?>">Dashboard</a></li>
            <li class="breadcrumb-item active" aria-current="page"><?= $title ?></li>
        </ol>
    </nav>
    <!-- Page Heading -->

    <?php if (session()->get('success')) : ?>
        <div class="alert alert-success col-md-6" role="alert">
            <?= session()->get('success') ?>
        </div>
    <?php endif; ?>

    <?php if (isset($validation)) : ?>
        <div class="alert alert-danger" role="alert">
            <?= $validation->listErrors() ?>
        </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-lg">

            <form>
                <?php if ($role_id <= 3) : ?>
                    <a href="" class="btn btn-dark" data-toggle="modal" data-target="#addModal">Tambah Data</a>
                <?php endif; ?>

                <!-- PENCARIAN DATA -->
                <div class="row float-right">
                    <div class="col-lg">
                        <div class="input-group mb-3">
                            <input type="text" class="form-control" name="pencarian" placeholder="Pencarian . . .">
                            <div class="input-group-append">
                                <button class="btn btn-dark" type="submit">
                                    <i class="fas fa-search"></i>
                                </button>
                            </div>
                        </div>
            </form>
        </div>
    </div>
    <!-- PENCARIAN DATA -->
    </form>

    <table class="table table-striped">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th style="text-align: center;" scope="col">Nama Komite</th>
                <th style="text-align: center;" scope="col">Deskripsi</th>
                <th style="text-align: center;" scope="col">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $i = 1 ?>
            <?php foreach ($committee as $c) : ?>
                <tr>
                    <td scope="row"><?= $i ?></td>
                    <td style="text-align: center;"><?= $c['committee']; ?></td>
                    <td style="text-align: center;"><?= $c['desc']; ?></td>
                    <td style="text-align: center;">
                        <a href="<?= site_url('master/editcom/'); ?><?= $c['id'] ?>" class="badge badge-warning">edit</a>
                        <a href="<?= site_url('master/deletecom/'); ?><?= $c['id'] ?>" class="badge badge-danger" onclick="return confirm('Data akan dihapus. Apakah anda yakin?')">delete</a>
                    </td>
                </tr>
                <?php $i++ ?>
            <?php endforeach ?>
        </tbody>
    </table>
    <?php if (empty($committee)) : ?>
        <div class="alert alert-danger text-center" role="alert">
            Data tidak ditemukan.
        </div>
    <?php endif ?>
</div>
</div>

</div>
<!-- /.container-fluid -->


<!-- Tambah Data Modal -->
<div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="addModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="newSubmenuModalLabel">Tambah Data</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="<?= basename('master/committee/') ?>" method="POST">
                <div class="modal-body">
                    <div class="form-group">
                        <label for="committee">Nama Komite</label>
                        <input type="text" class="form-control" name="committee" id="committee" placeholder="Masukan nama komite">
                    </div>
                    <div class="form-group">
                        <label for="desc">Deskripsi</label>
                        <input type="text" class="form-control" name="desc" id="desc" placeholder="Deskripsi">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-dark">Simpan</button>
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
                </div>
            </form>
        </div>
    </div>
</div>