<!-- Begin Page Content -->
<div class="container-fluid">

    <h1 class="h3 mb-4 text-gray-800"><?= $title ?></h1>

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= base_url('dashboard') ?>">Dashboard</a></li>
            <li class="breadcrumb-item active" aria-current="page"><?= $title ?></li>
        </ol>
    </nav>
    <!-- Page Heading -->

    <?php if (session()->get('success')) : ?>
        <div class="alert alert-success col-md-6" role="alert">
            <?= session()->get('success') ?>
        </div>
    <?php endif; ?>

    <?php if (isset($validation)) : ?>
        <div class="alert alert-danger" role="alert">
            <?= $validation->listErrors() ?>
        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header">
            Edit Komite
        </div>
        <div class="card-body">
            <form action="" method="post">
                <input type="hidden" name="id" value="<?= $committee['id'] ?>">
                <div class="form-group">
                    <label for="committee">Nama Komite</label>
                    <input type="text" class="form-control" name="committee" id="committee" value="<?= $committee['committee'] ?>">
                </div>
                <div class="form-group">
                    <label for="desc">Deskripsi</label>
                    <input type="text" class="form-control" name="desc" id="desc" value="<?= $committee['desc'] ?>">
                </div>
        </div>
        <div class="form-group ml-3">
            <button type="submit" class="btn btn-dark col-lg-2">Simpan</button>
            <button type="button" class="btn btn-danger col-lg-2" onclick="history.go(-1);">Kembali</button>
        </div>
        </form>
    </div>