<!-- Footer -->
<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span> &copy; <?= date('Y') ?> Corporate Secretary - Maybank Indonesia</span>
        </div>
    </div>
</footer>
<!-- End of Footer -->

</div>
<!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<!-- Logout Modal-->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
            <div class="modal-footer">
                <button class="btn btn-danger" type="button" data-dismiss="modal">Cancel</button>
                <a class="btn btn-dark" href="<?= site_url('auth/logout') ?>">Logout</a>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap core JavaScript-->
<script src="<?= site_url('assets/') ?>vendor/jquery/jquery.min.js"></script>
<script src="<?= site_url('assets/') ?>vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- Core plugin JavaScript-->
<script src="<?= site_url('assets/') ?>vendor/jquery-easing/jquery.easing.min.js"></script>

<!-- Custom scripts for all pages-->
<script src="<?= site_url('assets/') ?>js/datepicker.js"></script>

<!-- Custom scripts for all pages-->
<script src="<?= site_url('assets/') ?>js/sb-admin-2.min.js"></script>

<script>
    // Script Rename Form File Upload
    $('.custom-file-input').on('change', function() {
        let filename = $(this).val().split('\\').pop();
        $(this).next('.custom-file-label').addClass("selected").html(filename);
    });

    // Script Checklist Role Access
    $('.form-check-input-role').on('click', function() {
        const menuId = $(this).data('menu');
        const roleId = $(this).data('role');

        $.ajax({
            url: "<?= site_url('admin/changeaccess'); ?>",
            type: 'post',
            data: {
                menuId: menuId,
                roleId: roleId
            },
            success: function() {
                document.location.href = "<?= site_url('admin/roleaccess/'); ?>" + roleId;
            }
        })
    });

    // Datetime Picker
    $(function() {
        $('[data-toggle="datepicker"]').datepicker({
            autoHide: true,
            zIndex: 2048,
        });
    });
    // For refresh Modal Bootstrap
    $('.modal').on('hidden.bs.modal', function() {
        $(this).find('form')[0].reset();
    });

    // Filter Year Meeting BOD
    $(document).ready(function() {
        // Jika data sudah siap
        meeting();
        pagination();
        $("#year").change(function() {
            // Jika ada event dari combobox
            meeting();
            pagination();
        });
    });

    function meeting() {
        var year = $("#year").val();
        $.ajax({
            url: "<?= base_url('meeting/filterTable') ?>",
            data: "year=" + year,
            success: function(data) {
                $("#meeting tbody").html(data);
            }
        });
    }

    function pagination() {
        var year = $("#page").val();
        $.ajax({
            url: "<?= base_url('meeting/pagination') ?>",
            data: "page=" + year,
            success: function(data) {
                $("#pagination div").html(data);
            }
        });
    }
</script>

</body>

</html>