<!-- Begin Page Content -->
<div class="container-fluid">

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= base_url('dashboard') ?>">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="<?= base_url('dashboard/referensi') ?>"><?= $title ?></a></li>
            <li class="breadcrumb-item active" aria-current="page">Detail</li>
        </ol>
    </nav>

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title ?></h1>

    <table class="table table-striped">
        <tbody>
            <tr>
                <th scope="row">Klasifikasi</th>
                <td><?= $referensi['classification_name']; ?></td>
            </tr>
            <tr>
                <th scope="row">Kode</th>
                <td><?= $referensi['dr_code'] ?></td>
            </tr>
            <tr>
                <th scope="row">Jenis Dokumen</th>
                <td><?= $referensi['dr_name'] ?></td>
            </tr>
            <tr>
                <th scope="row">Retensi Aktif</th>
                <td><?= $referensi['active_retention'] . '  Tahun' ?></td>
            </tr>
            </tr>
            <tr>
                <th scope="row">Retensi Inaktif</th>
                <td><?= $referensi['inactive_retention'] . '  Tahun' ?></td>
            </tr>
            </tr>
            <tr>
                <th scope="row">Total Retensi</th>
                <td><?= $referensi['total_retention'] . '  Tahun'  ?></td>
            </tr>
        </tbody>
    </table>
    <button type="button" class="btn btn-dark ml-2" onclick="history.go(-1);">Back</button>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->