<!-- Begin Page Content -->
<div class="container-fluid">

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= base_url('dashboard') ?>">Dashboard</a></li>
            <li class="breadcrumb-item active" aria-current="page"><?= $title ?></li>
        </ol>
    </nav>

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title ?></h1>

    <?php if (session()->get('success')) : ?>
        <div class="alert alert-success" role="alert">
            <?= session()->get('success') ?>
        </div>
    <?php endif; ?>

    <?php if (isset($validation)) : ?>
        <div class="alert alert-danger" role="alert">
            <?= $validation->listErrors() ?>
        </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-lg">

            <form>
                <a href="" class="btn btn-dark" data-toggle="modal" data-target="#newModal">Tambah Referensi</a>

                <!-- PENCARIAN DATA -->
                <div class="row float-right">
                    <div class="col-lg">
                        <form action="" method="POST">
                            <div class="input-group mb-3">
                                <input type="text" class="form-control" name="pencarian" placeholder="Cari dokumen referensi">
                                <div class="input-group-append">
                                    <button class="btn btn-dark" type="submit">
                                        <i class="fas fa-search"></i>
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <!-- PENCARIAN DATA -->
            </form>

            <table class="table table-sm">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Klasifikasi</th>
                        <th scope="col">Kode</th>
                        <th scope="col">Jenis Dokumen</th>
                        <th scope="col">Retensi</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 1 ?>
                    <?php foreach ($referensi as $r) : ?>
                        <tr>
                            <td scope="row"><?= $i ?></th>
                            <td><?= $r['classification_name']; ?></td>
                            <td><?= $r['dr_code']; ?></td>
                            <td><?= $r['dr_name']; ?></td>
                            <td><?= $r['total_retention'] . '  Tahun'; ?></td>
                            <td>
                                <a href="<?= site_url('dashboard/detailref/'); ?><?= $r['id'] ?>" class="badge badge-info">detail</a>
                                <a href="<?= site_url('dashboard/updateref/'); ?><?= $r['id'] ?>" class="badge badge-secondary">edit</a>
                                <a href="<?= site_url('dashboard/deleteref/'); ?><?= $r['id'] ?>" class="badge badge-danger" onclick="return confirm('Delete this referensi?')">delete</a>
                            </td>
                        </tr>
                        <?php $i++ ?>
                    <?php endforeach ?>
                </tbody>
            </table>
            <?php if (empty($referensi)) : ?>
                <div class="alert alert-danger text-center" role="alert">
                    Data tidak ditemukan.
                </div>
            <?php endif ?>
        </div>
    </div>



</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

<!-- Add Menu Modal -->
<div class="modal fade" id="newModal" tabindex="-1" role="dialog" aria-labelledby="newModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="newModalLabel">Tambah Referensi</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="<?= basename('dashboard/referensi') ?>" method="POST">
                <div class="modal-body">
                    <label>Klasifikasi</label>
                    <div class="form-group">
                        <select name="klasifikasi" id="klasifikasi" class="form-control">
                            <option value="">Pilih Klasifikasi</option>
                            <?php foreach ($klasifikasi as $k) : ?>
                                <option value="<?= $k['id'] ?>"><?= $k['classification_name'] . ' ( ' . $k['classification_code'] . ' ) ' ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Kode</label>
                        <input type="text" class="form-control" id="code" name="code" placeholder="Kode Klasifikasi">
                    </div>
                    <div class="form-group">
                        <label>Jenis Dokumen</label>
                        <input type="text" class="form-control" id="jenis" name="jenis" placeholder="Jenis Dokumen">
                    </div>
                    <div class="form-group">
                        <label>Retentsi Aktif</label>
                        <input type="text" class="form-control" id="aktif" name="aktif" placeholder="Retensi Aktif (Tahun)">
                    </div>
                    <div class="form-group">
                        <label>Retensi Inaktif</label>
                        <input type="text" class="form-control" id="inaktif" name="inaktif" placeholder="Retensi Inaktif (Tahun)">
                    </div>
                    <!-- <div class="form-group">
                        <label>Total Retensi</label>
                        <input type="text" class="form-control" id="total" name="total" readonly>
                    </div> -->
                    <div class="form-check el">
                        <input type="checkbox" value="1" name="status" class="form-check-input" id="status" checked>
                        <label class="form-check-label" for="status">Status</label>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-dark">Tambah</button>
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
                </div>
            </form>
        </div>
    </div>
</div>