<!-- Begin Page Content -->
<div class="container-fluid">

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= base_url('dashboard') ?>">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="<?= base_url('dashboard/referensi') ?>">Data Referensi</a></li>
            <li class="breadcrumb-item active" aria-current="page">Edit Data</li>
        </ol>
    </nav>

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title ?></h1>

    <?php if (session()->get('success')) : ?>
        <div class="alert alert-success" role="alert">
            <?= session()->get('success') ?>
        </div>
    <?php endif; ?>

    <?php if (isset($validation)) : ?>
        <div class="alert alert-danger" role="alert">
            <?= $validation->listErrors() ?>
        </div>
    <?php endif; ?>

    <div class="card col-lg-6">
        <div class="card-header">
            Edit Data
        </div>
        <div class="card-body">
            <form action="" method="post">
                <input type="hidden" name="id" value="<?= $referensi['id'] ?>">
                <form action="<?= basename('dashboard/referensi') ?>" method="POST">
                    <div class="form-group">
                        <select name="klasifikasi" id="klasifikasi" class="form-control">
                            <option value="">Pilih klasifikasi</option>
                            <?php foreach ($klasifikasi as $k) : ?>
                                <option value="<?= $k['id'] ?>"><?= $k['classification_name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" id="code" name="code" value="<?= $referensi['dr_code'] ?>">
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" id="jenis" name="jenis" value="<?= $referensi['dr_name'] ?>">
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" id="aktif" name="aktif" value="<?= $referensi['active_retention'] ?>">
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" id="inaktif" name="inaktif" value="<?= $referensi['inactive_retention'] ?>">
                    </div>
                    <div class="form-check el">
                        <input type="checkbox" value="1" name="status" class="form-check-input" id="status" checked>
                        <label class="form-check-label" for="status">Status</label>
                    </div>
                    <div class="form-group mt-3">
                        <button type="submit" class="btn btn-dark">Update</button>
                        <button type="button" class="btn btn-danger" onclick="history.go(-1);">Back</button>
                    </div>
                </form>
        </div>
    </div>



</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->