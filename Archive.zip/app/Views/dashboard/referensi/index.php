<!-- Begin Page Content -->
<div class="container-fluid">

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= base_url('dashboard') ?>">Dashboard</a></li>
            <li class="breadcrumb-item active" aria-current="page"><?= $title ?></li>
        </ol>
    </nav>

    <!-- Page Heading -->
    <h1 class="h3 text-gray-800"><?= $title ?></h1>

    <?php if (session()->get('success')) : ?>
        <div class="alert alert-success" role="alert">
            <?= session()->get('success') ?>
        </div>
    <?php endif; ?>

    <?php if (isset($validation)) : ?>
        <div class="alert alert-danger" role="alert">
            <?= $validation->listErrors() ?>
        </div>
    <?php endif; ?>



    <div class="row">
        <div class="col-lg">

            <!-- PENCARIAN DATA -->
            <form>
                <div class="row">
                    <div class="col-md-6">
                        <form action="" method="POST">
                            <div class="input-group mb-3">
                                <input type="text" class="form-control" name="pencarian" placeholder="Cari dokumen referensi">
                                <div class="input-group-append">
                                    <button class="btn btn-dark" type="submit">
                                        <i class="fas fa-search"></i>
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </form>
            <!-- PENCARIAN DATA -->

            <table class="table table-sm">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Klasifikasi</th>
                        <th scope="col">Kode</th>
                        <th scope="col">Jenis Dokumen</th>
                        <th scope="col">Retensi</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 1 ?>
                    <?php foreach ($referensi as $r) : ?>
                        <tr>
                            <td scope="row"><?= $i ?></th>
                            <td><?= $r['classification_name']; ?></td>
                            <td><?= $r['dr_code']; ?></td>
                            <td><?= $r['dr_name']; ?></td>
                            <td><?= $r['total_retention'] . '  Tahun'; ?></td>
                            <td>
                                <a href="<?= site_url('dashboard/detailref/'); ?><?= $r['id'] ?>" class="badge badge-info">detail</a>
                            </td>
                        </tr>
                        <?php $i++ ?>
                    <?php endforeach ?>
                </tbody>
            </table>
            <?php if (empty($referensi)) : ?>
                <div class="alert alert-danger text-center" role="alert">
                    Data tidak ditemukan.
                </div>
            <?php endif ?>
        </div>
    </div>



</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->