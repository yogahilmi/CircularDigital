<!-- Begin Page Content -->
<div class="container-fluid">

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= base_url('dashboard') ?>">Dashboard</a></li>
            <li class="breadcrumb-item active" aria-current="page"><?= $title ?></li>
        </ol>
    </nav>

    <!-- Page Heading -->
    <div class="row">
        <div class="col-lg-6">
            <h1 class="h3 mb-4 text-gray-800"><?= $title ?></h1>
        </div>
    </div>

    <?php if (session()->get('success')) : ?>
        <div class="alert alert-success" role="alert">
            <?= session()->get('success') ?>
        </div>
    <?php endif; ?>

    <?php if (isset($validation)) : ?>
        <div class="alert alert-danger" role="alert">
            <?= $validation->listErrors() ?>
        </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-lg">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Deskripsi</th>
                        <th scope="col">Unit Kerja</th>
                        <th style="text-align: center;" scope="col">DPDI</th>
                        <th style="text-align: center;" scope="col">Tanggal</th>
                        <th style="text-align: center;" scope="col">Lokasi Simpan</th>
                        <th style="text-align: center;" scope="col">Data</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 1 ?>
                    <?php foreach ($pemindahan as $p) : ?>
                        <tr>
                            <td scope="row"><?= $i ?></t>
                            <td><?= $p['feeding_desc']; ?></td>
                            <td><?= $p['wu_name']; ?></td>
                            <td style="text-align: center;"><?= $p['feeding_number']; ?></td>
                            <td style="text-align: center;"><?= $p['feeding_date']; ?></td>
                            <td style="text-align: center;">
                                <a href="<?= site_url('dashboard/lokasidokumen/') ?><?= $p['id'] ?>" class="badge badge-warning">
                                    Atur lokasi simpan
                                </a>
                            </td>
                            <td style="text-align: center;">
                                <a href="<?= site_url('dokumen/detailpemindahan/') ?><?= $p['id'] ?>" class="badge badge-info"><i class="fas fa-fw fa-info"></i> Detail</a>
                            </td>
                        </tr>
                        <?php $i++ ?>
                    <?php endforeach ?>
                </tbody>
            </table>
            <?php if (empty($pemindahan)) : ?>
                <div class="alert alert-danger text-center" role="alert">
                    Tidak ada data.
                </div>
            <?php endif ?>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->