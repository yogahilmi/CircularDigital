<!-- Begin Page Content -->
<div class="container-fluid">

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= base_url('dashboard') ?>">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="<?= base_url('dashboard/setlokasi') ?>">Atur Lokasi Simpan</a></li>
            <li class="breadcrumb-item active" aria-current="page"><?= $title ?></li>
        </ol>
    </nav>

    <div class="row">
        <form class="col-lg-4">
            <!-- Page Heading -->
            <h1 class="h3 mb-4 text-gray-800"><?= $title ?></h1>
            <a class="btn btn-dark btn-lg" href="" data-toggle="modal" data-target="#submitdpdiModal">Simpan dan Lanjutkan</a>
            <p class="font-italic text-gray-600 mt-2 ml-1 small">Verifikasi Corporate Secretary.</p>
        </form>
        <div class="card-body float-right col-lg-8">
            <table class="table table-sm small">
                <tbody>
                    <tr>
                        <th scope="row">Unit Kerja</th>
                        <td><?= strtoupper($dpdi['wu_name']) ?></td>
                    </tr>
                    <tr>
                        <th scope="row">RC</th>
                        <td><?= strtoupper($dpdi['rc_number']) ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Nomor</th>
                        <td><?= $dpdi['feeding_number'] ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Record Center Tujuan</th>
                        <td><?= $dpdi['rc_name'] ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Tanggal dibuat</th>
                        <td><?= date($dpdi['feeding_date']) ?></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

    <?php if (session()->get('success')) : ?>
        <div class="alert alert-success col-md-6" role="alert">
            <?= session()->get('success') ?>
        </div>
    <?php endif; ?>

    <?php if (isset($validation)) : ?>
        <div class="alert alert-danger" role="alert">
            <?= $validation->listErrors() ?>
        </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-lg">

            <table class="table table-sm small">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Nama</th>
                        <th scope="col">Deskripsi</th>
                        <th scope="col">Awal</th>
                        <th scope="col">Akhir</th>
                        <th scope="col">Lokasi Simpan</th>
                        <th scope="col">Tindakan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 1 ?>
                    <?php foreach ($detail as $d) : ?>
                        <tr>
                            <td scope="row"><?= $i ?></td>
                            <td><?= $d['retention_name']; ?></td>
                            <td><?= $d['document_desc']; ?></td>
                            <td><?= $d['begin_period']; ?></td>
                            <td><?= $d['end_period']; ?></td>
                            <td><?= $d['location_id']; ?></td>
                            <?php if ($d['location_id'] == null) : ?>
                                <td>
                                    <a href="<?= site_url('dashboard/setsimpan/'); ?><?= $d['doc_id'] ?>" class="badge badge-info">
                                        <i class="fas fa-fw fa-edit"></i> Atur</a>
                                </td>
                            <?php else : ?>
                                <td>
                                    <a href="<?= site_url('dashboard/editsimpan/'); ?><?= $d['doc_id'] ?>" class="badge badge-secondary">
                                        <i class="fas fa-fw fa-edit"></i> Edit</a>
                                </td>
                            <?php endif; ?>
                        </tr>
                        <?php $i++ ?>
                    <?php endforeach ?>
                </tbody>
            </table>
            <?php if (empty($detail)) : ?>
                <div class="alert alert-danger text-center" role="alert">
                    Data tidak ditemukan.
                </div>
            <?php endif ?>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

<!-- SAVE Modal-->
<div class="modal fade" id="submitdpdiModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Apakah data sudah lengkap?</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">Apabila data sudah lengkap, silahkan klik tombol "SIMPAN" untuk melanjutkan ke tahap berikutnya.</div>
            <div class="modal-footer">
                <a class="btn btn-dark" href="<?= site_url('dashboard/submitdpdi/') ?><?= $dpdi['id'] ?>">Simpan</a>
                <button class="btn btn-danger" type="button" data-dismiss="modal">Cancel</button>
            </div>
        </div>
    </div>
</div>

<!-- Lokasi Simpan  Modal -->
<div class="modal fade" id="setLokasiModal" tabindex="-1" role="dialog" aria-labelledby="setLokasiModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="setLokasiModalLabel">Atur Lokasi Simpan</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="" method="POST">
                <div class="modal-body">
                    <div class="form-group">
                        <input type="text" class="form-control" id="lokasi" name="lokasi" placeholder="Lokasi">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-dark">Tambah</button>
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Lokasi Simpan  Modal -->
<div class="modal fade" id="editLokasiModal" tabindex="-1" role="dialog" aria-labelledby="editLokasiModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editLokasiModalLabel">Edit Lokasi Simpan</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="" method="POST">
                <div class="modal-body">
                    <div class="form-group">
                        <input type="text" class="form-control" id="menu" name="menu" placeholder="Lokasi">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-dark">Tambah</button>
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
                </div>
            </form>
        </div>
    </div>
</div>