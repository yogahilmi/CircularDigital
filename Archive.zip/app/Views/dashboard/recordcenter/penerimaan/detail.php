<!-- Begin Page Content -->
<div class="container-fluid">

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= base_url('dashboard') ?>">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="<?= base_url('dashboard/terima') ?>">Penerimaan Dokumen</a></li>
            <li class="breadcrumb-item active" aria-current="page"><?= $title ?></li>
        </ol>
    </nav>

    <div class="row">
        <form class="col-lg-3">
            <!-- Page Heading -->
            <h1 class="h3 mb-3 text-gray-800"><?= $title ?></h1>
            <div class="row">
                <div class="col-lg">
                    <a class="btn btn-dark btn-lg mb-2 col-lg" href="" data-toggle="modal" data-target="#konfirmasiModal">Konfirmasi Terima</a>
                </div>
            </div>
            <div class="row">
                <div class="col-lg">
                    <a class="btn btn-danger col-lg" href="" data-toggle="modal" data-target="#sebagianModal">Terima Sebagian</a>
                    <p class="font-italic text-gray-600 mt-2 ml-1 small">Pastikan daftar dokumen sudah sesuai.</p>
                </div>
            </div>
        </form>
        <div class="card-body float-right col-lg-9">
            <table class="table table-sm small">
                <tbody>
                    <tr>
                        <th scope="row">Unit Kerja</th>
                        <td><?= strtoupper($dpdi['wu_name']) ?></td>
                    </tr>
                    <tr>
                        <th scope="row">RC</th>
                        <td><?= strtoupper($dpdi['rc_number']) ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Nomor</th>
                        <td><?= $dpdi['feeding_number'] ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Record Center Tujuan</th>
                        <td><?= $dpdi['rc_name'] ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Tanggal dibuat</th>
                        <td><?= date($dpdi['feeding_date']) ?></td>
                    </tr>
                    <?php if ($dpdi['is_active'] == 10) : ?>
                        <tr>
                            <th scope="row">Status Penerimaan</th>
                            <td class="btn-secondary active"><?= $dpdi['note'] ?></td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <?php if (session()->get('success')) : ?>
        <div class="alert alert-success col-md-6" role="alert">
            <?= session()->get('success') ?>
        </div>
    <?php endif; ?>

    <?php if (isset($validation)) : ?>
        <div class="alert alert-danger" role="alert">
            <?= $validation->listErrors() ?>
        </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-lg">

            <table class="table table-sm small">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Nama</th>
                        <th scope="col">Deskripsi</th>
                        <th scope="col">Awal</th>
                        <th scope="col">Akhir</th>
                        <th scope="col">Musnah</th>
                        <th scope="col">Lokasi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 1 ?>
                    <?php foreach ($detail as $d) : ?>
                        <tr>
                            <td scope="row"><?= $i ?></td>
                            <td><?= $d['retention_name']; ?></td>
                            <td><?= $d['document_desc']; ?></td>
                            <td><?= $d['begin_period']; ?></td>
                            <td><?= $d['end_period']; ?></td>
                            <td><?= $d['destroy_schedule']; ?></td>
                            <td><?= $d['location_id']; ?></td>
                        </tr>
                        <?php $i++ ?>
                    <?php endforeach ?>
                </tbody>
            </table>
            <?php if (empty($detail)) : ?>
                <div class="alert alert-danger text-center" role="alert">
                    Data tidak ditemukan.
                </div>
            <?php endif ?>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

<!-- KONFIRMASI Modal-->
<div class="modal fade" id="konfirmasiModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Apakah dokumen sudah diterima?</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">Apabila dokumen telah diterima semua, silahkan klik tombol "KONFIRMASI".</div>
            <div class="modal-footer">
                <a class="btn btn-dark" href="<?= site_url('dashboard/konfirmasi/') ?><?= $dpdi['id'] ?>">Konfirmasi</a>
                <button class="btn btn-danger" type="button" data-dismiss="modal">Batal</button>
            </div>
        </div>
    </div>
</div>

<!-- SEBAGIAN Modal-->
<div class="modal fade" id="sebagianModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Apakah dokumen hanya diterima sebagian?</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <form action="<?= site_url('dashboard/terimaSebagian/') ?><?= $dpdi['id'] ?>" method="POST">
                <div class="modal-body">
                    <div class="form-group">
                        <label for="note">Keterangan</label>
                        <textarea class="form-control font-weight-lighter" id="note" name="note" rows="3" placeholder="Isi dengan keterangan revisi dari dokumen yang akan dipindahkan."></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-dark">Terima Sebagian</button>
                    <button class="btn btn-danger" type="button" data-dismiss="modal">Batal</button>
                </div>
            </form>
        </div>
    </div>
</div>