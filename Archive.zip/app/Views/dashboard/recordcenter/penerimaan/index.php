<!-- Begin Page Content -->
<div class="container-fluid">

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= base_url('dashboard') ?>">Dashboard</a></li>
            <li class="breadcrumb-item active" aria-current="page"><?= $title ?></li>
        </ol>
    </nav>

    <!-- Page Heading -->
    <div class="row">
        <div class="col-lg-6">
            <h1 class="h3 mb-4 text-gray-800"><?= $title ?></h1>
        </div>
    </div>

    <?php if (session()->get('success')) : ?>
        <div class="alert alert-success" role="alert">
            <?= session()->get('success') ?>
        </div>
    <?php endif; ?>

    <?php if (isset($validation)) : ?>
        <div class="alert alert-danger" role="alert">
            <?= $validation->listErrors() ?>
        </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-lg">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Deskripsi</th>
                        <th style="text-align: center;" scope="col">DPDI</th>
                        <th style="text-align: center;" scope="col">Tanggal</th>
                        <th style="text-align: center;" scope="col">Status</th>
                        <th style="text-align: center;" scope="col">Tindakan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 1 ?>
                    <?php foreach ($pemindahan as $p) : ?>
                        <tr>
                            <td scope="row"><?= $i ?></t>
                            <td><?= $p['feeding_desc']; ?></td>
                            <td style="text-align: center;"><?= $p['feeding_number']; ?></td>
                            <td style="text-align: center;"><?= $p['feeding_date']; ?></td>
                            <td style="text-align: center;"><?= $p['status']; ?></td>
                            <td style="text-align: center;">
                                <a href="<?= site_url('dashboard/detailterima/') ?><?= $p['id'] ?>" class="badge badge-info">
                                    Lihat daftar dokumen
                                </a>
                            </td>
                        </tr>
                        <?php $i++ ?>
                    <?php endforeach ?>
                </tbody>
            </table>
            <?php if (empty($pemindahan)) : ?>
                <div class="alert alert-danger text-center" role="alert">
                    Tidak ada data.
                </div>
            <?php endif ?>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->