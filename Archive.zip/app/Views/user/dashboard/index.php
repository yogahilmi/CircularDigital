<!-- Begin Page Content -->
<div class="container-fluid">

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
        </ol>
    </nav>

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title ?></h1>

    <div class="row">
        <div class="col-sm-6">
            <div class="card">
                <div class="row no-gutters">
                    <div class="col-md-4 mt-2">
                        <img src="..." class="card-img">
                    </div>
                    <div class="col-md-8">
                        <div class="card-body">
                            <h5 class="card-title">Pemindahan Dokumen</h5>
                            <p class="card-text">Pemindahan dokumen dari unit kerja atau cabang ke Records Center</p>
                            <a href="#" class="btn btn-dark">Halaman pemindahan</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-sm-6">
            <div class="card">
                <div class="row no-gutters">
                    <div class="col-md-4 mt-2">
                        <img src="..." class="card-img">
                    </div>
                    <div class="col-md-8">
                        <div class="card-body">
                            <h5 class="card-title">Peminjaman Dokumen</h5>
                            <p class="card-text">Peminjaman dokumen inaktif yang telah disimpan pada Records Center</p>
                            <a href="#" class="btn btn-dark">Halaman peminjaman</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->