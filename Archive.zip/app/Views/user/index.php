<!-- Begin Page Content -->
<div class="container-fluid">

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= base_url('dashboard') ?>">Dashboard</a></li>
            <li class="breadcrumb-item active" aria-current="page"><?= $title ?></li>
        </ol>
    </nav>
    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title ?></h1>

    <div class="card">
        <div class="row no-gutters">
            <div class="col-md-4">
                <img src="<?= site_url('assets/img/profile/') . $user['image'] ?>" class="card-img col-lg mt-3">
                <!-- <button type="button" class="btn btn-dark col-lg ml-3 mb-3 mt-3" onclick="history.go(-1);">Kembali</button> -->
            </div>
            <div class="col-md-8">

                <div class="card-body">
                    <table class="table table-striped">
                        <tbody>
                            <tr>
                                <th scope="row">Nama</th>
                                <td><?= strtoupper($user['name']) ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Unit Kerja</th>
                                <td><?= $user['workingunit_name'] ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Email</th>
                                <td><?= $user['email'] ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Role</th>
                                <td><?= $user['role'] ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Status</th>
                                <td><?= $user['status'] ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Aktif sejak</th>
                                <td><?= date($user['date_created']) ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->