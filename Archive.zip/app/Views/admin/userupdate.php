<!-- Begin Page Content -->
<div class="container-fluid">

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= base_url('dashboard') ?>">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="<?= base_url('admin/userman') ?>">User Management</a></li>
            <li class="breadcrumb-item active" aria-current="page"><?= $title ?></li>
        </ol>
    </nav>

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title ?></h1>

    <?php if (session()->get('success')) : ?>
        <div class="alert alert-success" role="alert">
            <?= session()->get('success') ?>
        </div>
    <?php endif; ?>

    <?php if (isset($validation)) : ?>
        <div class="alert alert-danger" role="alert">
            <?= $validation->listErrors() ?>
        </div>
    <?php endif; ?>

    <div class="card col-lg-6">
        <div class="card-header">
            Edit User
        </div>
        <div class="card-body">
            <form action="" method="post">
                <input type="hidden" name="id" value="<?= $user['id'] ?>">
                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" name="name" class="form-control" id="name" value="<?= $user['name'] ?>">
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="text" name="email" class="form-control" id="email" value="<?= $user['email'] ?>">
                </div>
                <div class="form-group">
                    <label for="workingunit">Unit Kerja</label>
                    <input type="workingunit" class=" form-control" id="workingunit" name="workinguni" value="<?= $user['workingunit_name'] ?>">
                </div>
                <div class="form-group">
                    <label for="role">Role</label>
                    <select name="role" id="role" class="form-control">
                        <?php foreach ($role as $r)
                            if ($user['role_id'] == $r['id']) {
                                echo "<option selected ='selected' value=" . $r['id'] . ">" . $r['role'] . "</option>";
                            } else {
                                echo "<option value=" . $r['id'] . ">" . $r['role'] . "</option>";
                            }
                        ?>
                    </select>
                </div>
                <div class="form-check">
                    <input type="checkbox" value="1" name="status" class="form-check-input" id="status" checked>
                    <label class="form-check-label" for="status">Status</label>
                </div>
                <div class="form-group mt-4">
                    <button type="submit" class="btn btn-dark">Update</button>
                    <button type="button" class="btn btn-danger" onclick="history.go(-1);">Back</button>
                </div>
            </form>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->