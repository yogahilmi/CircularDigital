<!-- Begin Page Content -->
<div class="container-fluid">

    <h1 class="h3 mb-4 text-gray-800"><?= $title ?></h1>

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= base_url('dashboard') ?>">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="<?= base_url('meeting') ?>">Meeting</a></li>
            <li class="breadcrumb-item active" aria-current="page" id="title" name="title"><?= $title ?></li>
        </ol>
    </nav>
    <!-- Page Heading -->

    <?php if (session()->get('success')) : ?>
        <div class="alert alert-success col-md-6" role="alert">
            <?= session()->get('success') ?>
        </div>
    <?php endif; ?>

    <?php if (isset($validation)) : ?>
        <div class="alert alert-danger" role="alert">
            <?= $validation->listErrors() ?>
        </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-lg">

            <form>
                <?php if ($role_id <= 3) : ?>
                    <div class="row">
                        <div class="col-lg mb-3">
                            <a href="" class="btn btn-dark" data-toggle="modal" data-target="#addModal">Tambah Data</a>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="row d-flex justify-content-between">
                    <div class="col-lg-2">
                        <div class="form-group">
                            <select name="year" id="year" class="form-control font-weight-lighter">
                                <option value="">Show All</option>
                                <?php foreach ($year as $y) : ?>
                                    <option value="<?= $y['year'] ?>"><?= $y['year'] ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <!-- PENCARIAN DATA -->
                    <div class="col-lg-4">
                        <div class="input-group mb-3">
                            <input type="text" class="form-control font-weight-lighter" name="pencarian" placeholder="Pencarian . . .">
                            <div class="input-group-append">
                                <button class="btn btn-dark" type="submit">
                                    <i class="fas fa-search"></i>
                                </button>
                            </div>
                        </div>
            </form>
        </div>
    </div>
    <!-- PENCARIAN DATA -->
    </form>

    <font size="2">
        <table class="table table-striped" id="meeting">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th style="text-align: center;" scope="col">Nomor</th>
                    <th style="text-align: center;" scope="col">Agenda</th>
                    <th style="text-align: center;" scope="col">Tanggal</th>
                    <th style="text-align: center;" scope="col">Aksi</th>
                </tr>
            </thead>
            <tbody></tbody>
        </table>
        <div id="pagination"></div>
    </font>
</div>
</div>

</div>
<!-- /.container-fluid -->


<!-- Tambah Data Modal -->
<div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="addModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="newSubmenuModalLabel">Tambah Data</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="<?= basename('meeting/bod') ?>" method="POST">
                <div class="modal-body">
                    <div class="form-group">
                        <label for="number">Nomor</label>
                        <input type="text" class="form-control" name="number" id="number" placeholder="Masukan nomor . . .">
                    </div>
                    <div class="form-group">
                        <label for="agenda">Agenda</label>
                        <textarea class="form-control font-weight-lighter" id="agenda" name="agenda" rows="3" placeholder="Isi dengan agenda dari meeting yang telah dilaksanakan."></textarea>
                    </div>
                    <div class="form-group">
                        <label for="date">Tanggal Meeting</label>
                        <input type="text" class="form-control" name="date" id="date" data-toggle="datepicker" readonly>
                    </div>
                    <div class="form-group">
                        <label for="attachment">Lampiran</label>
                        <input type="text" class="form-control" name="attachment" id="attachment" placeholder="Silahkan upload lampiran">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-dark">Simpan</button>
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
                </div>
            </form>
        </div>
    </div>
</div>