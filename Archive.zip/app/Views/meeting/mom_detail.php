<!-- Begin Page Content -->
<div class="container-fluid">

    <h1 class="h3 mb-4 text-gray-800"><?= $title ?></h1>

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= base_url('dashboard') ?>">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="<?= base_url('meeting') ?>">Meeting</a></li>
            <li class="breadcrumb-item active" aria-current="page"><?= $title ?></li>
        </ol>
    </nav>
    <!-- Page Heading -->

    <table class="table table-striped">
        <tbody>
            <tr>
                <th scope="row">Kategori</th>
                <td><?= $meeting['category'] ?></td>
            </tr>
            <tr>
                <th scope="row">Nomor</th>
                <td><?= $meeting['number'] ?></td>
            </tr>
            <tr>
                <th scope="row">Agenda</th>
                <td><?= $meeting['agenda'] ?></td>
            </tr>
            <tr>
                <th scope="row">Tanggal Meeting</th>
                <td><?= $meeting['meeting_date'] ?></td>
            </tr>
            <tr>
                <th scope="row">Lampiran</th>
                <td><?= $meeting['attachment'] ?></td>
            </tr>
        </tbody>
    </table>
    <button type="button" class="btn btn-dark col-lg-2" onclick="history.go(-1);">Kembali</button>

</div>
<!-- /.container-fluid -->