<!-- Begin Page Content -->
<div class="container-fluid">

    <h1 class="h3 mb-4 text-gray-800"><?= $title ?></h1>

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= base_url('dashboard') ?>">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="<?= base_url('meeting') ?>">Meeting</a></li>
            <li class="breadcrumb-item active" aria-current="page"><?= $title ?></li>
        </ol>
    </nav>
    <!-- Page Heading -->

    <?php if (session()->get('success')) : ?>
        <div class="alert alert-success col-md-6" role="alert">
            <?= session()->get('success') ?>
        </div>
    <?php endif; ?>

    <?php if (isset($validation)) : ?>
        <div class="alert alert-danger" role="alert">
            <?= $validation->listErrors() ?>
        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header">
            Edit Minutes of Meeting
        </div>
        <div class="card-body">
            <form action="" method="post">
                <input type="hidden" name="id" value="<?= $meeting['id'] ?>">
                <div class="form-group">
                    <label for="category">Kategori</label>
                    <input type="text" class="form-control" name="category" id="category" value="<?= $meeting['category'] ?>" readonly>
                </div>
                <div class="form-group">
                    <label for="number">Nomor</label>
                    <input type="text" class="form-control" name="number" id="number" value="<?= $meeting['number'] ?>" readonly>
                </div>
                <div class="form-group">
                    <label for="agenda">Agenda</label>
                    <textarea type="text" class="form-control" name="agenda" id="agenda"><?= $meeting['agenda'] ?></textarea>
                </div>
                <div class="form-group">
                    <label for="date">Tanggal Meeting</label>
                    <input type="text" class="form-control" name="date" id="date" value="<?= $meeting['meeting_date'] ?>" data-toggle="datepicker" readonly>
                </div>
                <div class="form-group">
                    <label for="attachment">Lampiran</label>
                    <input type="text" class="form-control" name="attachment" id="attachment" value="<?= $meeting['attachment'] ?>">
                </div>
        </div>
        <div class="form-group ml-3">
            <button type="submit" class="btn btn-dark col-lg-2">Simpan</button>
            <button type="button" class="btn btn-danger col-lg-2" onclick="history.go(-1);">Kembali</button>
        </div>
        </form>
    </div>