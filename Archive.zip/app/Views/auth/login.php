    <div class="container">

        <!-- Outer Row -->
        <div class="row justify-content-center">

            <div class="col-lg-6">
                <div class="card o-hidden border-0 shadow-lg my-5">
                    <div class="card-body p-0">
                        <!-- Nested Row within Card Body -->
                        <div class="row">
                            <div class="col-lg">
                                <div class="p-5">
                                    <div class="text-center">
                                        <h1 class="h4 text-gray-900 mb-3">Circular Digital Application</h1>
                                    </div>
                                    <hr>
                                    <div class="text-center">
                                        <h1 class="h5 text-gray-900 mb-4">Login Information</h1>
                                    </div>

                                    <?php if (session()->get('success')) : ?>
                                        <div class="alert alert-success" role="alert">
                                            <?= session()->get('success') ?>
                                        </div>
                                    <?php endif; ?>

                                    <?php if (session()->get('failed')) : ?>
                                        <div class="alert alert-danger" role="alert">
                                            <?= session()->get('failed') ?>
                                        </div>
                                    <?php endif; ?>

                                    <?php if (isset($validation)) : ?>
                                        <div class="alert alert-danger" role="alert">
                                            <?= $validation->listErrors() ?>
                                        </div>
                                    <?php endif; ?>
                                    <form class="user" method="POST" action="<?= site_url('auth/login') ?>">
                                        <?php csrf_token(); ?>
                                        <div class="form-group">
                                            <input type="text" class="form-control form-control-user" id="email" name="email" placeholder="Enter Email Address..." value="<?= set_value('email') ?>">
                                        </div>
                                        <div class="form-group">
                                            <input type="password" class="form-control form-control-user" id="password" name="password" placeholder="Password">
                                        </div>
                                        <button type="submit" class="btn btn-dark btn-user btn-block">
                                            LOGIN
                                        </button>
                                    </form>
                                    <hr>
                                    <div class="container my-auto">
                                        <div class="copyright text-center my-auto">
                                            <span> &copy; <?= date('Y') ?> Corporate Secretary - Maybank Indonesia</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </div>

    </div>