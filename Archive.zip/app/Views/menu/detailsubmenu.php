<!-- Begin Page Content -->
<div class="container-fluid">

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= base_url('dashboard') ?>">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="<?= base_url('menu/submenu') ?>">Submenu Management</a></li>
            <li class="breadcrumb-item active" aria-current="page"><?= $title ?></li>
        </ol>
    </nav>

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title ?></h1>

    <table class="table table-striped">
        <tbody>
            <tr>
                <th scope="row">Title</th>
                <td><?= $submenu['title']; ?></td>
            </tr>
            <tr>
                <th scope="row">Icon</th>
                <td><?= $submenu['icon'] ?></td>
            </tr>
            <tr>
                <th scope="row">Menu</th>
                <td><?= $submenu['menu'] ?></td>
            </tr>
            <tr>
                <th scope="row">URL</th>
                <td><?= $submenu['url'] ?></td>
            </tr>
            <tr>
                <th scope="row">Deskripsi</th>
                <td><?= $submenu['sub_menu_desc'] ?></td>
            </tr>
            <tr>
                <th scope="row">Status</th>
                <td><?= $submenu['status'] ?></td>
            </tr>
            </tr>
        </tbody>
    </table>
    <button type="button" class="btn btn-dark" onclick="history.go(-1);">Back</button>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->