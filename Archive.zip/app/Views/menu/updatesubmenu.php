<!-- Begin Page Content -->
<div class="container-fluid">

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= base_url('dashboard') ?>">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="<?= base_url('menu/submenu') ?>">Submenu Management</a></li>
            <li class="breadcrumb-item active" aria-current="page"><?= $title ?></li>
        </ol>
    </nav>

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title ?></h1>

    <?php if (session()->get('success')) : ?>
        <div class="alert alert-success" role="alert">
            <?= session()->get('success') ?>
        </div>
    <?php endif; ?>

    <?php if (isset($validation)) : ?>
        <div class="alert alert-danger" role="alert">
            <?= $validation->listErrors() ?>
        </div>
    <?php endif; ?>

    <div class="card col-lg-6">
        <div class="card-header">
            Edit Submenu
        </div>
        <div class="card-body">
            <form action="" method="post">
                <input type="hidden" name="id" value="<?= $submenu['id'] ?>">
                <div class="form-group">
                    <label for="menu">Title</label>
                    <input type="text" name="title" class="form-control" id="title" value="<?= $submenu['title'] ?>">
                </div>
                <div class="form-group">
                    <label for="menu">Menu</label>
                    <select name="menu_id" id="menu_id" class="form-control">
                        <?php foreach ($menu as $m)
                            if ($submenu['menu_id'] == $m['id']) {
                                echo "<option selected ='selected' value=" . $m['id'] . ">" . $m['menu'] . "</option>";
                            } else {
                                echo "<option value=" . $m['id'] . ">" . $m['menu'] . "</option>";
                            }

                        ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="menu">URL</label>
                    <input type="text" name="url" class="form-control" id="url" value="<?= $submenu['url'] ?>">
                </div>
                <div class="form-group">
                    <label for="menu">Icon</label>
                    <input type="text" name="icon" class="form-control" id="icon" value="<?= $submenu['icon'] ?>">
                </div>
                <div class="form-group">
                    <label for="menu">Deskripsi</label>
                    <input type="text" name="desc" class="form-control" id="desc" value="<?= $submenu['sub_menu_desc'] ?>">
                </div>
                <div class="form-check">
                    <input type="checkbox" value="1" name="is_active" class="form-check-input" id="is_active" checked>
                    <label class="form-check-label" for="is_active">Active</label>
                </div>
        </div>
        <div class="form-group ml-3">
            <button type="submit" class="btn btn-dark">Update</button>
            <button type="button" class="btn btn-danger" onclick="history.go(-1);">Back</button>
        </div>
        </form>
    </div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->