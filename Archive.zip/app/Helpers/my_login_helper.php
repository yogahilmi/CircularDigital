<?php

use App\Models\UserAccessModel;
use App\Models\MenuModel;

function is_logged_in()
{
    // $ci = get_instance();
    $uri = new \CodeIgniter\HTTP\URI();
    if (!session()->get('email')) {
        return redirect()->to('auth');
    } else {
        $role_id = session()->get('role_id');
        // $menu =  $this->request->uri->getSegment(1);
        // $menu =  $uri->getSegment(1);

        if ($menu = $uri->getSegment(1)) {
            return $uri;
        }

        // QUERY TABLE USER_MENU
        $menuModel = new MenuModel();
        $queryMenu = $menuModel->where(['menu' => $menu])->get()->getRowArray();
        $menu_id = $queryMenu['id'];

        // QUERY TABLE USER_ACCESS_MENU
        $accessModel = new UserAccessModel();
        $userAccess = $accessModel->where(['role_id' => $role_id, 'menu_id' => $menu_id])->get()->getRowArray();

        if ($userAccess == null) {
            return redirect()->to(site_url('auth/error'));
        }
    }
}

function check_access($role_id, $menu_id)
{
    $accessModel = new UserAccessModel();
    $userAccess = $accessModel->where(['role_id' => $role_id, 'menu_id' => $menu_id])->get()->getRowArray();

    if ($userAccess == !null) {
        return "checked='checked'";
    }
}
