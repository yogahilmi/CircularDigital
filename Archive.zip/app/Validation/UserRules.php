<?php

namespace App\Validation;

use App\Models\UserModel;

class UserRules
{

    public function validateUser(string $str, string $fields, array $data)
    {
        $userModel = new UserModel();
        $userz = $userModel->where('email', $data['email'])->first();

        if (!$userz)
            return false;


        return password_verify($data['password'], $userz['password']);
    }
}
