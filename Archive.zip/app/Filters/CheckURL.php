<?php

namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use App\Models\MenuModel;
use App\Models\UserAccessModel;

class CheckURL implements FilterInterface
{
    public function before(RequestInterface $request)
    {
        // Do something here
        // Bila segment 1 == users
        // Redirect request Segmen kedua

        $role_id = session()->get('role_id');
        $menu =  $this->request->uri->getSegment(1);

        // QUERY TABLE USER_MENU
        $menuModel = new MenuModel();
        $queryMenu = $this->menuModel->where(['menu' => $menu])->get()->getRowArray();
        $menu_id = $queryMenu['id'];

        // QUERY TABLE USER_ACCESS_MENU
        $accessModel = new UserAccessModel();
        $userAccess = $this->accessModel->where(['role_id' => $role_id, 'menu_id' => $menu_id])->get()->getRowArray();

        if ($userAccess == null) {
            return redirect()->to(site_url('auth/error'));
        }
    }

    //--------------------------------------------------------------------

    public function after(RequestInterface $request, ResponseInterface $response)
    {
        // Do something here
    }
}
